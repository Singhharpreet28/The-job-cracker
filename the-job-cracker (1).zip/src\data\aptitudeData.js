export const aptitudeSections = [
  {
    id: "quants",
    title: "Quantitative Aptitude",
    icon: "Calculator",
    color: "from-blue-500 to-indigo-600",
    description: "Arithmetic, algebra, percentages, speed-distance-time, probability, and speed math shortcuts.",
    notes: [
      {
        topic: "Percentages & Fractions Cheat Sheet",
        content: `• 1/2 = 50% | 1/3 = 33.33% | 1/4 = 25% | 1/5 = 20%
• 1/6 = 16.66% | 1/7 = 14.28% | 1/8 = 12.5% | 1/9 = 11.11%
• Net change formula: If A increases by x% and then decreases by y%, Net % Change = (x - y - (x*y)/100)%
• Successive discount: d1% and d2% equivalent single discount = (d1 + d2 - (d1 * d2) / 100)%`
      },
      {
        topic: "Profit & Loss Key Formulas",
        content: `• Profit % = (Profit / CP) * 100
• Loss % = (Loss / CP) * 100
• Selling Price (SP) = CP * (100 + Profit%) / 100
• Cost Price (CP) = SP * 100 / (100 + Profit%)
• False Weight: Gain % = [Error / (True Value - Error)] * 100
• When two items are sold at the same price, one at x% gain and other at x% loss, overall result is always a loss: Loss % = (x / 10)^2 %`
      },
      {
        topic: "Time, Speed & Distance",
        content: `• Speed = Distance / Time
• km/h to m/s: Multiply by 5/18 (e.g. 72 km/h = 72 * 5/18 = 20 m/s)
• m/s to km/h: Multiply by 18/5
• Average Speed for equal distances: 2xy / (x + y), where x and y are the respective speeds.
• Relative Speed:
  - Moving in opposite directions: S1 + S2
  - Moving in same direction: |S1 - S2|
• Train crossing a pole: Time = Length of train / Speed
• Train crossing a platform: Time = (Length of train + Length of platform) / Speed`
      },
      {
        topic: "Time & Work Shortcuts",
        content: `• If A can do a job in 'x' days and B in 'y' days, together they take (x*y) / (x + y) days.
• Efficiency Ratio: If A is twice as efficient as B, ratio of time taken is 1 : 2.
• Work = Rate * Time.
• Pipes & Cisterns: Inlet pipe fills in 'x' hours (+1/x work/hr), outlet empties in 'y' hours (-1/y work/hr). Net rate = (1/x - 1/y).`
      }
    ],
    questions: [
      {
        id: "q-1",
        category: "Quantitative",
        topic: "Profit & Loss",
        question: "A shopkeeper sells two laptops at ₹36,000 each. On one he gains 20% and on the other he loses 20%. What is his overall gain or loss percentage?",
        options: ["No gain, no loss", "4% Loss", "4% Gain", "2% Loss"],
        correctIndex: 1,
        explanation: "When two articles are sold at the same selling price with x% profit on one and x% loss on the other, there is ALWAYS an overall loss given by formula: Loss % = (x / 10)^2 % = (20 / 10)^2 % = 2^2 % = 4% Loss.",
        shortcutTip: "Always remember: equal selling prices with +x% and -x% yields (x/10)^2 % loss. Never calculate actual CP!"
      },
      {
        id: "q-2",
        category: "Quantitative",
        topic: "Time, Speed & Distance",
        question: "A train running at 54 km/hr takes 20 seconds to completely cross a platform 180 meters long. What is the length of the train?",
        options: ["100 meters", "120 meters", "140 meters", "150 meters"],
        correctIndex: 1,
        explanation: "First, convert speed from km/hr to m/s: 54 * (5/18) = 15 m/s. Distance covered in 20 seconds = Speed * Time = 15 * 20 = 300 meters. Total distance = Length of train (L) + Length of platform (180m). So, L + 180 = 300 => L = 120 meters.",
        shortcutTip: "Always convert speed to m/s first (multiply by 5/18) when distance is in meters and time is in seconds."
      },
      {
        id: "q-3",
        category: "Quantitative",
        topic: "Time & Work",
        question: "A can complete a piece of work in 12 days, and B can complete it in 18 days. If they work together for 4 days, what fraction of the work remains?",
        options: ["4/9", "5/9", "1/3", "7/18"],
        correctIndex: 0,
        explanation: "Take LCM of 12 and 18 = 36 units (Total Work). A's daily efficiency = 36/12 = 3 units/day. B's daily efficiency = 36/18 = 2 units/day. Combined efficiency = 3 + 2 = 5 units/day. In 4 days, work done = 4 * 5 = 20 units. Remaining work = 36 - 20 = 16 units. Fraction remaining = 16 / 36 = 4/9.",
        shortcutTip: "Use the LCM method for all time & work problems instead of working with fractions."
      },
      {
        id: "q-4",
        category: "Quantitative",
        topic: "Percentages",
        question: "The price of sugar rises by 25%. By what percentage must a household reduce its consumption so that its expenditure remains unchanged?",
        options: ["20%", "25%", "16.66%", "30%"],
        correctIndex: 0,
        explanation: "Formula for reduction in consumption: [r / (100 + r)] * 100. Here r = 25%. Reduction % = [25 / (100 + 25)] * 100 = (25 / 125) * 100 = 1/5 * 100 = 20%.",
        shortcutTip: "Fraction rule: If price increases by 1/4 (25%), consumption must decrease by 1/(4+1) = 1/5 = 20%."
      },
      {
        id: "q-5",
        category: "Quantitative",
        topic: "Probability",
        question: "Two fair dice are rolled simultaneously. What is the probability that the sum of the numbers appearing on the two dice is a prime number?",
        options: ["7/12", "5/12", "15/36", "17/36"],
        correctIndex: 1,
        explanation: "Total outcomes = 6 * 6 = 36. Possible prime sums between 2 and 12 are {2, 3, 5, 7, 11}. Sum 2: (1,1) -> 1 way. Sum 3: (1,2),(2,1) -> 2 ways. Sum 5: (1,4),(2,3),(3,2),(4,1) -> 4 ways. Sum 7: (1,6),(2,5),(3,4),(4,3),(5,2),(6,1) -> 6 ways. Sum 11: (5,6),(6,5) -> 2 ways. Total favorable ways = 1 + 2 + 4 + 6 + 2 = 15. Probability = 15 / 36 = 5 / 12.",
        shortcutTip: "Sum frequencies for two dice form a triangle: 2(1), 3(2), 4(3), 5(4), 6(5), 7(6), 8(5), 9(4), 10(3), 11(2), 12(1)."
      }
    ]
  },
  {
    id: "logical",
    title: "Logical Reasoning",
    icon: "Brain",
    color: "from-purple-500 to-pink-600",
    description: "Syllogisms, blood relations, seating arrangement, coding-decoding, and pattern recognition.",
    notes: [
      {
        topic: "Blood Relations Standard Rules",
        content: `• Father's father = Paternal grandfather | Mother's father = Maternal grandfather
• Father's brother = Paternal uncle | Mother's brother = Maternal uncle
• Brother's son / Sister's son = Nephew | Brother's daughter / Sister's daughter = Niece
• Spouse's mother = Mother-in-law | Son's wife = Daughter-in-law
• Always use family tree symbols: Circle for Female, Square/Plus for Male, Double line '=' for married couple, Vertical line for generations.`
      },
      {
        topic: "Syllogisms (Venn Diagram Method)",
        content: `• 'All A are B': A circle is completely inside B circle.
• 'Some A are B': A and B circles overlap.
• 'No A are B': A and B circles are strictly disjoint.
• 'Some A are not B': Part of A definitely lies outside B.
• Complementary Pairs (Either-Or conditions):
  1. Both conclusions must be independently doubtful.
  2. One must be positive and one negative ('Some' + 'No' OR 'All' + 'Some Not').
  3. Subject and predicate must be the same.`
      },
      {
        topic: "Direction Sense & Angles",
        content: `• Standard compass: North (Up), South (Down), East (Right), West (Left).
• Clockwise turns: North -> East (90°) -> South (180°) -> West (270°).
• Distance calculation: Always apply Pythagoras theorem (Distance = √(x² + y²)) for shortest displacement.`
      }
    ],
    questions: [
      {
        id: "q-6",
        category: "Logical",
        topic: "Blood Relations",
        question: "Pointing to a photograph of a woman, Rahul said, 'She is the mother of the only daughter of my father's only son.' How is Rahul related to the woman in the photograph?",
        options: ["Brother", "Husband", "Father", "Cousin"],
        correctIndex: 1,
        explanation: "'My father's only son' refers to Rahul himself (since Rahul is male and the only son). 'The only daughter of Rahul' is Rahul's daughter. 'The mother of Rahul's daughter' is Rahul's wife. Therefore, Rahul is the husband of the woman in the photograph.",
        shortcutTip: "Always break relations down backwards starting from the phrase containing 'my'."
      },
      {
        id: "q-7",
        category: "Logical",
        topic: "Direction Sense",
        question: "A man walks 6 km North, turns right and walks 8 km, then turns right again and walks 6 km. How far is he from his starting point and in which direction?",
        options: ["8 km East", "8 km West", "10 km North-East", "14 km East"],
        correctIndex: 0,
        explanation: "1) Walks 6 km North: (0, 6). 2) Turns right (East) and walks 8 km: (8, 6). 3) Turns right (South) and walks 6 km: (8, 0). He is now at coordinate (8, 0), which is exactly 8 km to the East of starting point (0, 0).",
        shortcutTip: "Equal opposite movements (6 km North followed by 6 km South) cancel out completely."
      },
      {
        id: "q-8",
        category: "Logical",
        topic: "Coding-Decoding",
        question: "In a certain code language, 'ROBOT' is written as 'TQDQV'. How will 'BRAIN' be coded in that same language?",
        options: ["DTCIK", "DTCLP", "DTCPK", "DTCKP"],
        correctIndex: 3,
        explanation: "Observe the letter shifts: R (+2) -> T, O (+2) -> Q, B (+2) -> D, O (+2) -> Q, T (+2) -> V. Every letter is shifted forward by +2 positions. Applying +2 to BRAIN: B (+2) = D, R (+2) = T, A (+2) = C, I (+2) = K, N (+2) = P. Code is DTCKP.",
        shortcutTip: "Write the alphabet with positions (A=1 ... Z=26) to instantly see the arithmetic delta."
      }
    ]
  },
  {
    id: "verbal",
    title: "Verbal Ability",
    icon: "BookOpen",
    color: "from-emerald-500 to-teal-600",
    description: "Grammar rules, sentence correction, reading comprehension, idioms, and vocabulary.",
    notes: [
      {
        topic: "Top 5 Subject-Verb Agreement Rules",
        content: `• When two singular subjects are connected by 'neither... nor' or 'either... or', the verb agrees with the subject closest to it.
• Collective nouns (team, committee, jury) take a singular verb when operating as a single unit, and a plural verb when members act individually.
• Phrases like 'along with', 'as well as', 'accompanied by', 'together with' do not change the number of the subject.
• 'Each of', 'One of', 'Neither of', 'Either of' are always followed by a plural noun but take a SINGULAR verb (e.g. 'One of the students IS missing').`
      },
      {
        topic: "Modifiers & Parallelism",
        content: `• Misplaced Modifiers: A descriptive modifier must be placed immediately adjacent to the noun it modifies.
• Parallelism: Items in a series or comparison must share the exact same grammatical structure (e.g., 'He loves swimming, running, and cycling' - all gerunds).`
      }
    ],
    questions: [
      {
        id: "q-9",
        category: "Verbal",
        topic: "Subject-Verb Agreement",
        question: "Identify the grammatically correct sentence:",
        options: [
          "Neither the manager nor the employees was aware of the policy change.",
          "Neither the manager nor the employees were aware of the policy change.",
          "Neither the manager nor the employees has been aware of the policy change.",
          "Neither the employees nor the manager were aware of the policy change."
        ],
        correctIndex: 1,
        explanation: "When subjects are joined by 'neither... nor', the verb must agree with the subject closest to it. In option B, 'employees' is plural and is closest to the verb, so the plural verb 'were' is correct.",
        shortcutTip: "In 'Neither A nor B', look ONLY at B to decide if the verb is singular or plural."
      },
      {
        id: "q-10",
        category: "Verbal",
        topic: "Idioms & Phrasal Verbs",
        question: "What is the meaning of the idiom 'To burn the candle at both ends'?",
        options: [
          "To waste money unnecessarily",
          "To work exhausting hours from early morning until late at night",
          "To cause a fire hazard",
          "To lose focus during an interview"
        ],
        correctIndex: 1,
        explanation: "'To burn the candle at both ends' means to be extremely busy or overworking oneself by waking up very early and going to bed very late.",
        shortcutTip: "Visual memory: burning both ends consumes the wax twice as fast - depleting energy!"
      }
    ]
  }
];
