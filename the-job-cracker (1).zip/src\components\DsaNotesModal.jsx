import React, { useState } from 'react';
import { X, FileText, Save, Check } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const DsaNotesModal = ({ problem, onClose }) => {
  const { dsaNotes, saveDsaProblemNote } = useApp();
  const currentNote = dsaNotes[problem?.id] || '';
  const [noteText, setNoteText] = useState(currentNote);
  const [savedNotice, setSavedNotice] = useState(false);

  if (!problem) return null;

  const handleSave = () => {
    saveDsaProblemNote(problem.id, noteText);
    setSavedNotice(true);
    setTimeout(() => {
      setSavedNotice(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-indigo-400" />
            <h3 className="font-semibold text-white text-sm">
              My Personal Notes: <span className="text-slate-300 font-normal">{problem.title}</span>
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          <p className="text-xs text-slate-400">
            Jot down tricky edge cases, your personal memory triggers, or mistakes you made when practicing this problem. Persisted locally in your browser.
          </p>

          <textarea
            rows={7}
            placeholder="e.g. Remember to handle negative numbers. The 2-pointer edge case when l == r needs special care..."
            value={noteText}
            onChange={(e) => setNoteText(e.target.value)}
            className="w-full p-3.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 resize-none font-sans"
          />

          <div className="flex items-center justify-between pt-2">
            <div>
              {savedNotice && (
                <span className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
                  <Check className="w-4 h-4" /> Note Saved!
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30"
              >
                <Save className="w-3.5 h-3.5" />
                Save Notes
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
