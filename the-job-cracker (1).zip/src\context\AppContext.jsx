import React, { createContext, useContext, useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { initialJobs, getSavedJobs, setSavedJobs, getAppliedJobs, setAppliedJobs } from '../data/jobsData';
import { dsaProblems, getDsaProgress, saveDsaProgress } from '../data/dsaSheetsData';

const AppContext = createContext();

export const AppProvider = ({ children }) => {
  // Jobs State
  const [jobs, setJobs] = useState(() => {
    try {
      const custom = localStorage.getItem('careerforge_custom_jobs');
      if (custom) {
        return [...JSON.parse(custom), ...initialJobs];
      }
    } catch (e) {
      console.error(e);
    }
    return initialJobs;
  });

  const [savedJobs, setSavedJobsState] = useState(getSavedJobs);
  const [appliedJobs, setAppliedJobsState] = useState(getAppliedJobs);

  // DSA State
  const initialDsa = getDsaProgress();
  const [solvedDsa, setSolvedDsa] = useState(initialDsa.solved);
  const [starredDsa, setStarredDsa] = useState(initialDsa.starred);
  const [dsaNotes, setDsaNotes] = useState(() => {
    try {
      const saved = localStorage.getItem('careerforge_dsa_notes');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Quiz History
  const [quizHistory, setQuizHistory] = useState(() => {
    try {
      const saved = localStorage.getItem('careerforge_quiz_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // HR Practice Answers
  const [hrNotes, setHrNotes] = useState(() => {
    try {
      const saved = localStorage.getItem('careerforge_hr_notes');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Theme State ('dark' | 'light')
  const [theme, setTheme] = useState(() => {
    try {
      const saved = localStorage.getItem('careerforge_theme');
      if (saved) return saved;
      return 'dark';
    } catch {
      return 'dark';
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('careerforge_theme', theme);
      if (theme === 'light') {
        document.documentElement.classList.add('light');
        document.documentElement.classList.remove('dark');
        document.body.classList.add('light');
        document.body.classList.remove('dark');
      } else {
        document.documentElement.classList.add('dark');
        document.documentElement.classList.remove('light');
        document.body.classList.add('dark');
        document.body.classList.remove('light');
      }
    } catch (e) {
      console.error(e);
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  // Save to LocalStorage on updates
  useEffect(() => {
    setSavedJobs(savedJobs);
  }, [savedJobs]);

  useEffect(() => {
    setAppliedJobs(appliedJobs);
  }, [appliedJobs]);

  useEffect(() => {
    saveDsaProgress(solvedDsa, starredDsa);
  }, [solvedDsa, starredDsa]);

  useEffect(() => {
    localStorage.setItem('careerforge_dsa_notes', JSON.stringify(dsaNotes));
  }, [dsaNotes]);

  useEffect(() => {
    localStorage.setItem('careerforge_quiz_history', JSON.stringify(quizHistory));
  }, [quizHistory]);

  useEffect(() => {
    localStorage.setItem('careerforge_hr_notes', JSON.stringify(hrNotes));
  }, [hrNotes]);

  // Helpers
  const triggerConfetti = () => {
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch (e) {
      // safe fallback
    }
  };

  const toggleSaveJob = (jobId) => {
    setSavedJobsState((prev) =>
      prev.includes(jobId) ? prev.filter((id) => id !== jobId) : [...prev, jobId]
    );
  };

  const applyToJob = ({ jobId, title, company, applicantName, applicantEmail, resumeUrl, notes }) => {
    const newApplication = {
      id: `app-${Date.now()}`,
      jobId,
      title,
      company,
      appliedDate: new Date().toISOString().split('T')[0],
      status: 'Applied',
      applicantName,
      applicantEmail,
      resumeUrl: resumeUrl || 'resume_uploaded.pdf',
      notes: notes || 'Applied through The Job Cracker Quick-Apply'
    };

    setAppliedJobsState((prev) => [newApplication, ...prev]);
    triggerConfetti();
    return newApplication;
  };

  const updateApplicationStatus = (appId, newStatus) => {
    setAppliedJobsState((prev) =>
      prev.map((app) => (app.id === appId ? { ...app, status: newStatus } : app))
    );
  };

  const addCustomJob = (newJob) => {
    const jobWithId = {
      ...newJob,
      id: `custom-job-${Date.now()}`,
      postedDate: 'Just now'
    };
    setJobs((prev) => [jobWithId, ...prev]);
    try {
      const custom = localStorage.getItem('careerforge_custom_jobs');
      const list = custom ? JSON.parse(custom) : [];
      localStorage.setItem('careerforge_custom_jobs', JSON.stringify([jobWithId, ...list]));
    } catch (e) {
      console.error(e);
    }
    triggerConfetti();
    return jobWithId;
  };

  const toggleSolvedDsa = (problemId) => {
    setSolvedDsa((prev) => {
      const isAlready = prev.includes(problemId);
      if (!isAlready) {
        triggerConfetti();
        return [...prev, problemId];
      }
      return prev.filter((id) => id !== problemId);
    });
  };

  const toggleStarredDsa = (problemId) => {
    setStarredDsa((prev) =>
      prev.includes(problemId) ? prev.filter((id) => id !== problemId) : [...prev, problemId]
    );
  };

  const saveDsaProblemNote = (problemId, noteText) => {
    setDsaNotes((prev) => ({
      ...prev,
      [problemId]: noteText
    }));
  };

  const recordQuizResult = (result) => {
    setQuizHistory((prev) => [{ ...result, id: Date.now() }, ...prev]);
    if (result.score >= (result.total * 0.7)) {
      triggerConfetti();
    }
  };

  const saveHrNote = (questionId, noteText) => {
    setHrNotes((prev) => ({
      ...prev,
      [questionId]: noteText
    }));
  };

  // Stats calculation
  const totalDsaCount = dsaProblems.length;
  const solvedDsaCount = solvedDsa.length;
  const dsaProgressPct = totalDsaCount > 0 ? Math.round((solvedDsaCount / totalDsaCount) * 100) : 0;

  return (
    <AppContext.Provider
      value={{
        jobs,
        savedJobs,
        appliedJobs,
        toggleSaveJob,
        applyToJob,
        updateApplicationStatus,
        addCustomJob,
        solvedDsa,
        starredDsa,
        dsaNotes,
        toggleSolvedDsa,
        toggleStarredDsa,
        saveDsaProblemNote,
        totalDsaCount,
        solvedDsaCount,
        dsaProgressPct,
        quizHistory,
        recordQuizResult,
        hrNotes,
        saveHrNote,
        triggerConfetti,
        theme,
        setTheme,
        toggleTheme
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
