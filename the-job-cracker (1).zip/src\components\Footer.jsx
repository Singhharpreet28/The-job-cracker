import React from 'react';
import { Link } from 'react-router-dom';
import { Code2, Github, Linkedin, Twitter, Heart, Sparkles, CheckCircle2 } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="border-t border-slate-800 bg-slate-950 text-slate-400 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
        
        {/* Brand */}
        <div className="space-y-4 md:col-span-1">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center text-white shadow-md">
              <Code2 className="w-5 h-5" />
            </div>
            <span className="font-display tracking-wider text-xl flex items-center gap-1.5">
              <span className="bg-gradient-to-r from-amber-400 via-orange-400 to-amber-300 bg-clip-text text-transparent font-black">
                The Job
              </span>
              <span className="bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent font-black">
                Cracker
              </span>
            </span>
          </Link>
          <p className="text-xs text-slate-400 leading-relaxed">
            The all-in-one platform for tech aspirants. Discover top high-paying software jobs, master topic-wise DSA sheets, revise core CS subjects, and crack premier company hiring drives.
          </p>
          <div className="flex items-center gap-2 text-xs text-emerald-400">
            <CheckCircle2 className="w-4 h-4" />
            <span>Updated for 2025/2026 Hiring Season</span>
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="text-sm font-semibold text-slate-200 uppercase tracking-wider mb-4">
            Job Portal
          </h4>
          <ul className="space-y-2 text-xs">
            <li><Link to="/jobs" className="hover:text-white transition-colors">Software Engineer Jobs</Link></li>
            <li><Link to="/jobs" className="hover:text-white transition-colors">Remote Tech Roles</Link></li>
            <li><Link to="/jobs" className="hover:text-white transition-colors">College Internships (2025/2026)</Link></li>
            <li><Link to="/applications" className="hover:text-white transition-colors">Application Tracker Board</Link></li>
          </ul>
        </div>

        {/* Prep Modules */}
        <div>
          <h4 className="text-sm font-semibold text-slate-200 uppercase tracking-wider mb-4">
            Preparation
          </h4>
          <ul className="space-y-2 text-xs">
            <li><Link to="/dsa-sheet" className="hover:text-white transition-colors">Dedicated DSA Topic Sheet</Link></li>
            <li><Link to="/prep/aptitude" className="hover:text-white transition-colors">Quantitative & Logical Aptitude</Link></li>
            <li><Link to="/prep/technical" className="hover:text-white transition-colors">DBMS, OS, CN & OOPs Notes</Link></li>
            <li><Link to="/prep/hr" className="hover:text-white transition-colors">STAR Method HR Interview Guide</Link></li>
          </ul>
        </div>

        {/* Company Patterns */}
        <div>
          <h4 className="text-sm font-semibold text-slate-200 uppercase tracking-wider mb-4">
            Company Hiring Patterns
          </h4>
          <ul className="space-y-2 text-xs">
            <li><Link to="/companies" className="hover:text-white transition-colors">Google SDE Hiring Process</Link></li>
            <li><Link to="/companies" className="hover:text-white transition-colors">Amazon 16 LPs & Interview Rounds</Link></li>
            <li><Link to="/companies" className="hover:text-white transition-colors">TCS NQT Syllabus & Pattern</Link></li>
            <li><Link to="/companies" className="hover:text-white transition-colors">Infosys HackWithInfy & SP Cadre</Link></li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto mt-12 pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
        <p>© 2026 The Job Cracker Platform. Built for developers, students and job seekers.</p>
        <div className="flex items-center gap-1">
          <span>Crafted with</span>
          <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
          <span>for engineering students everywhere</span>
        </div>
      </div>
    </footer>
  );
};
