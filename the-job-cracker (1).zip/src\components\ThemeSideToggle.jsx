import React, { useState } from 'react';
import { Sun, Moon, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ThemeSideToggle = () => {
  const { theme, toggleTheme, setTheme } = useApp();
  const [isHovered, setIsHovered] = useState(false);

  const isLight = theme === 'light';

  return (
    <div 
      className="fixed right-0 top-1/2 -translate-y-1/2 z-50 flex items-center select-none"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Side Docked Button */}
      <button
        onClick={toggleTheme}
        className={`group relative flex items-center gap-2.5 px-3 py-3 rounded-l-2xl border-y border-l shadow-2xl transition-all duration-300 ${
          isLight
            ? 'bg-white/95 border-slate-300 text-slate-800 hover:bg-slate-50 shadow-slate-400/20'
            : 'bg-slate-900/95 border-slate-700 text-slate-200 hover:bg-slate-850 shadow-black/50'
        } backdrop-blur-md hover:pl-4`}
        title={`Current theme: ${theme}. Click to switch to ${isLight ? 'Dark' : 'Light'} mode`}
        aria-label="Toggle Theme"
      >
        {/* Animated Icon */}
        <div className={`p-1.5 rounded-xl transition-all duration-300 ${
          isLight
            ? 'bg-amber-100 text-amber-600 rotate-0'
            : 'bg-indigo-950/80 text-indigo-400 -rotate-12'
        }`}>
          {isLight ? (
            <Sun className="w-5 h-5 text-amber-500 fill-amber-400 animate-spin-slow" />
          ) : (
            <Moon className="w-5 h-5 text-indigo-300 fill-indigo-400/30" />
          )}
        </div>

        {/* Text / Toggle Pill */}
        <div className="hidden sm:flex flex-col text-left pr-1">
          <span className="text-[10px] font-bold uppercase tracking-wider opacity-60">
            Theme
          </span>
          <span className="text-xs font-bold capitalize flex items-center gap-1">
            {isLight ? 'Light Mode' : 'Dark Mode'}
          </span>
        </div>

        {/* Indicator Dot */}
        <span className={`w-2 h-2 rounded-full ${isLight ? 'bg-amber-500 animate-pulse' : 'bg-indigo-400'}`}></span>
      </button>

      {/* Expanded Quick Options Panel when Hovered */}
      {isHovered && (
        <div className="absolute right-full mr-2 rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-2 flex flex-col gap-1.5 animate-in fade-in slide-in-from-right-2 duration-150 text-xs w-36">
          <div className="px-2 py-1 text-[10px] uppercase font-bold text-slate-400 tracking-wider">
            Select Theme
          </div>

          <button
            onClick={() => setTheme('light')}
            className={`flex items-center gap-2 px-2.5 py-1.5 rounded-xl font-medium transition-colors ${
              isLight
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Sun className="w-4 h-4 text-amber-400" />
            <span>Light Theme</span>
          </button>

          <button
            onClick={() => setTheme('dark')}
            className={`flex items-center gap-2 px-2.5 py-1.5 rounded-xl font-medium transition-colors ${
              !isLight
                ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Moon className="w-4 h-4 text-indigo-400" />
            <span>Dark Theme</span>
          </button>
        </div>
      )}
    </div>
  );
};
