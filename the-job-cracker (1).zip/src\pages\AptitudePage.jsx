import React, { useState } from 'react';
import { 
  Calculator, 
  Brain, 
  BookOpen, 
  Sparkles, 
  Trophy, 
  CheckCircle2, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  Play, 
  Clock 
} from 'lucide-react';
import { aptitudeSections } from '../data/aptitudeData';
import { QuizModal } from '../components/QuizModal';
import { useApp } from '../context/AppContext';

export const AptitudePage = () => {
  const { quizHistory } = useApp();
  const [activeTab, setActiveTab] = useState('quants');
  const [expandedExplanation, setExpandedExplanation] = useState({});
  const [activeQuizSection, setActiveQuizSection] = useState(null);

  const currentSection = aptitudeSections.find((s) => s.id === activeTab) || aptitudeSections[0];

  const toggleExplanation = (id) => {
    setExpandedExplanation((prev) => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const iconMap = {
    Calculator: Calculator,
    Brain: Brain,
    BookOpen: BookOpen
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Top Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-blue-950/40 to-slate-900 border border-slate-800 p-6 sm:p-8 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5" /> Campus Placement & OA Preparation
            </div>
            <h1 className="text-3xl font-extrabold text-white">
              Aptitude, Logical Reasoning & Verbal Mastery
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl leading-relaxed">
              Formula cheat sheets, speed shortcuts, and practice questions for TCS NQT, Infosys, Cognizant, Wipro, Accenture, and Big Tech screening assessments.
            </p>
          </div>

          {/* Quick Quiz CTA Card */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-5 shrink-0 flex flex-col justify-between space-y-3 min-w-[240px]">
            <div>
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Timed Assessment</div>
              <div className="text-sm font-bold text-white mt-0.5">{currentSection.title} Test</div>
            </div>
            <button
              onClick={() => setActiveQuizSection(currentSection)}
              className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md shadow-blue-600/30 flex items-center justify-center gap-2 transition-all hover:scale-[1.02]"
            >
              <Play className="w-3.5 h-3.5 fill-white" /> Start Practice Quiz
            </button>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-2 pt-4 border-t border-slate-800/80 overflow-x-auto">
          {aptitudeSections.map((sec) => {
            const Icon = iconMap[sec.icon] || Calculator;
            const isSelected = activeTab === sec.id;
            return (
              <button
                key={sec.id}
                onClick={() => setActiveTab(sec.id)}
                className={`px-4 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-2.5 ${
                  isSelected
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : 'bg-slate-950/80 border border-slate-800 text-slate-300 hover:border-slate-700 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{sec.title}</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                  isSelected ? 'bg-blue-800 text-blue-100' : 'bg-slate-800 text-slate-400'
                }`}>
                  {sec.questions.length} MCQs
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Revision Notes & Formula Cheat Sheets */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-blue-400" />
            Formula Cheat Sheets & High-Yield Notes
          </h2>
          <span className="text-xs text-slate-400">Quick Revision before Exams</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {currentSection.notes.map((note, index) => (
            <div
              key={index}
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2 hover:border-slate-700 transition-colors"
            >
              <h3 className="text-sm font-bold text-blue-300 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-400"></span>
                {note.topic}
              </h3>
              <pre className="text-xs text-slate-300 font-mono whitespace-pre-wrap leading-relaxed bg-slate-950/80 p-3.5 rounded-xl border border-slate-800/80">
                {note.content}
              </pre>
            </div>
          ))}
        </div>
      </div>

      {/* Practice Problems & Step-by-Step Solutions */}
      <div className="space-y-4 pt-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white">Practice Problems with Step-by-Step Solutions</h2>
            <p className="text-xs text-slate-400">Try solving them yourself first, then expand the detailed mathematical logic.</p>
          </div>
          <button
            onClick={() => setActiveQuizSection(currentSection)}
            className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-600 text-xs font-semibold text-white flex items-center gap-1.5 transition-colors"
          >
            <Clock className="w-3.5 h-3.5 text-blue-400" /> Take Timed Quiz
          </button>
        </div>

        <div className="space-y-4">
          {currentSection.questions.map((q, qIndex) => {
            const isExpanded = Boolean(expandedExplanation[q.id]);
            return (
              <div
                key={q.id}
                className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 uppercase tracking-wider">
                      {q.topic}
                    </span>
                    <h3 className="text-sm font-semibold text-white leading-relaxed pt-1">
                      {qIndex + 1}. {q.question}
                    </h3>
                  </div>

                  <button
                    onClick={() => toggleExplanation(q.id)}
                    className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 shrink-0 text-xs font-medium flex items-center gap-1 transition-colors"
                  >
                    <span>{isExpanded ? 'Hide Solution' : 'View Solution'}</span>
                    {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>
                </div>

                {/* Options List */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {q.options.map((opt, i) => (
                    <div
                      key={i}
                      className={`p-2.5 rounded-xl border flex items-center gap-2.5 ${
                        isExpanded && i === q.correctIndex
                          ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300 font-semibold'
                          : 'bg-slate-950/70 border-slate-800 text-slate-300'
                      }`}
                    >
                      <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[10px] border ${
                        isExpanded && i === q.correctIndex
                          ? 'border-emerald-400 bg-emerald-500/20 text-emerald-300'
                          : 'border-slate-700 bg-slate-900 text-slate-400'
                      }`}>
                        {String.fromCharCode(65 + i)}
                      </span>
                      <span>{opt}</span>
                    </div>
                  ))}
                </div>

                {/* Expandable Explanation */}
                {isExpanded && (
                  <div className="pt-3 border-t border-slate-800 space-y-2 text-xs animate-in fade-in duration-150">
                    <div className="p-3.5 rounded-xl bg-blue-950/20 border border-blue-500/20 text-slate-300 leading-relaxed">
                      <strong className="text-blue-300 font-bold block mb-1">Step-by-step Solution:</strong>
                      {q.explanation}
                    </div>

                    {q.shortcutTip && (
                      <div className="p-3 rounded-xl bg-amber-950/20 border border-amber-500/20 text-amber-300 flex items-center gap-2 font-medium">
                        <Sparkles className="w-4 h-4 shrink-0 text-amber-400" />
                        <span><strong>Speed Math Shortcut:</strong> {q.shortcutTip}</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Quiz Modal */}
      {activeQuizSection && (
        <QuizModal
          title={activeQuizSection.title}
          questions={activeQuizSection.questions}
          onClose={() => setActiveQuizSection(null)}
        />
      )}

    </div>
  );
};
