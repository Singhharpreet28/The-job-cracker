import React, { useState, useEffect } from 'react';
import { X, Clock, CheckCircle2, AlertCircle, ArrowRight, ArrowLeft, RotateCcw, Trophy, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const QuizModal = ({ title, questions, onClose }) => {
  const { recordQuizResult } = useApp();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState({});
  const [isFinished, setIsFinished] = useState(false);
  const [timeLeft, setTimeLeft] = useState(questions.length * 90); // 90 secs per question

  useEffect(() => {
    if (isFinished || timeLeft <= 0) return;
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          finishQuiz();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [isFinished, timeLeft]);

  const currentQ = questions[currentIndex];

  const handleSelect = (optIndex) => {
    if (isFinished) return;
    setSelectedAnswers({
      ...selectedAnswers,
      [currentIndex]: optIndex
    });
  };

  const finishQuiz = () => {
    setIsFinished(true);
    let score = 0;
    questions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctIndex) {
        score++;
      }
    });

    recordQuizResult({
      title,
      score,
      total: questions.length,
      percentage: Math.round((score / questions.length) * 100),
      timestamp: new Date().toLocaleDateString()
    });
  };

  const calculateScore = () => {
    let score = 0;
    questions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctIndex) {
        score++;
      }
    });
    return score;
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const score = calculateScore();
  const percentage = Math.round((score / questions.length) * 100);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div>
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              <Trophy className="w-4 h-4 text-amber-400" /> {title} Practice Test
            </h3>
            <p className="text-xs text-slate-400">
              {isFinished ? 'Quiz Completed' : `Question ${currentIndex + 1} of ${questions.length}`}
            </p>
          </div>

          <div className="flex items-center gap-3">
            {!isFinished && (
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800 border border-slate-700 text-xs font-mono text-indigo-300">
                <Clock className="w-3.5 h-3.5 text-indigo-400" />
                <span>{formatTime(timeLeft)}</span>
              </div>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {!isFinished ? (
            <>
              {/* Question */}
              <div className="space-y-3">
                <div className="text-xs font-semibold px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 inline-block">
                  {currentQ.topic || 'Aptitude'}
                </div>
                <h4 className="text-base font-medium text-slate-100 leading-relaxed">
                  {currentQ.question}
                </h4>
              </div>

              {/* Options */}
              <div className="space-y-2.5">
                {currentQ.options.map((opt, i) => {
                  const isSelected = selectedAnswers[currentIndex] === i;
                  return (
                    <button
                      key={i}
                      onClick={() => handleSelect(i)}
                      className={`w-full text-left p-3.5 rounded-xl border text-sm transition-all flex items-start gap-3 ${
                        isSelected
                          ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-sm'
                          : 'bg-slate-950/70 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-800/40'
                      }`}
                    >
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold border mt-0.5 shrink-0 ${
                        isSelected
                          ? 'border-indigo-400 bg-indigo-500 text-white'
                          : 'border-slate-700 text-slate-400'
                      }`}>
                        {String.fromCharCode(65 + i)}
                      </div>
                      <span className="flex-1">{opt}</span>
                    </button>
                  );
                })}
              </div>
            </>
          ) : (
            /* Results View */
            <div className="space-y-6">
              <div className="p-6 rounded-2xl bg-gradient-to-b from-indigo-950/40 to-slate-950 border border-indigo-500/20 text-center space-y-3">
                <div className="inline-flex p-3 rounded-full bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
                  <Trophy className="w-8 h-8" />
                </div>
                <h4 className="text-xl font-bold text-white">Scorecard</h4>
                <div className="flex items-center justify-center gap-4 text-sm">
                  <span className="text-3xl font-extrabold text-indigo-400">{score} / {questions.length}</span>
                  <span className="text-lg font-bold text-slate-300">({percentage}%)</span>
                </div>
                <p className="text-xs text-slate-400">
                  {percentage >= 80 ? 'Outstanding! Ready for high-tier company screening.' : percentage >= 50 ? 'Good effort! Review the tricky questions below to strengthen concepts.' : 'Keep practicing! Review formulas and retake to improve accuracy.'}
                </p>
              </div>

              {/* Review Solutions */}
              <div className="space-y-4">
                <h5 className="text-sm font-bold text-slate-200">Detailed Review & Explanations:</h5>
                {questions.map((q, idx) => {
                  const userAns = selectedAnswers[idx];
                  const isCorrect = userAns === q.correctIndex;
                  return (
                    <div key={idx} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
                      <div className="flex items-start justify-between gap-3">
                        <div className="text-xs font-bold text-slate-400">Q{idx + 1}. {q.question}</div>
                        {isCorrect ? (
                          <span className="shrink-0 flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Correct
                          </span>
                        ) : (
                          <span className="shrink-0 flex items-center gap-1 text-[11px] font-semibold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded-full border border-rose-500/20">
                            <AlertCircle className="w-3.5 h-3.5" /> Incorrect
                          </span>
                        )}
                      </div>

                      <div className="text-xs text-slate-300 space-y-1">
                        <div>
                          <span className="text-slate-500 font-medium">Your answer: </span>
                          <span className={isCorrect ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'}>
                            {userAns !== undefined ? q.options[userAns] : 'Not answered'}
                          </span>
                        </div>
                        {!isCorrect && (
                          <div>
                            <span className="text-slate-500 font-medium">Correct answer: </span>
                            <span className="text-emerald-400 font-semibold">{q.options[q.correctIndex]}</span>
                          </div>
                        )}
                      </div>

                      <div className="pt-2 border-t border-slate-800/80 text-xs text-slate-400 leading-relaxed">
                        <span className="text-indigo-400 font-semibold">Solution: </span>{q.explanation}
                        {q.shortcutTip && (
                          <div className="mt-1 text-amber-400 font-medium flex items-center gap-1">
                            <Sparkles className="w-3.5 h-3.5" /> Shortcut: {q.shortcutTip}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer Navigation */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between">
          {!isFinished ? (
            <>
              <button
                disabled={currentIndex === 0}
                onClick={() => setCurrentIndex((prev) => prev - 1)}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white disabled:opacity-30 disabled:pointer-events-none"
              >
                <ArrowLeft className="w-4 h-4" /> Previous
              </button>

              <div className="flex items-center gap-2">
                {currentIndex === questions.length - 1 ? (
                  <button
                    onClick={finishQuiz}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/30"
                  >
                    Finish Test
                  </button>
                ) : (
                  <button
                    onClick={() => setCurrentIndex((prev) => prev + 1)}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30"
                  >
                    Next <ArrowRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            </>
          ) : (
            <div className="flex items-center justify-between w-full">
              <button
                onClick={() => {
                  setSelectedAnswers({});
                  setIsFinished(false);
                  setCurrentIndex(0);
                  setTimeLeft(questions.length * 90);
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Retake Test
              </button>
              <button
                onClick={onClose}
                className="px-4 py-2 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white"
              >
                Done
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
