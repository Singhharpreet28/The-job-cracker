export const initialJobs = [
  {
    id: "job-1",
    title: "Software Development Engineer - I (SDE 1)",
    company: "Amazon",
    logo: "https://images.unsplash.com/photo-1523474253246-64e03e5eeae1?w=128&auto=format&fit=crop&q=80",
    companyBadge: "FAANG / Big Tech",
    location: "Bengaluru, India",
    mode: "Hybrid",
    type: "Full-time",
    experience: "0 - 2 Years",
    batch: "2024 / 2025 / 2026",
    salary: "₹24 - ₹42 LPA",
    salaryMin: 24,
    salaryMax: 42,
    skills: ["Java", "DSA", "Distributed Systems", "AWS", "OOPs"],
    postedDate: "2 days ago",
    deadline: "2026-11-15",
    description: "Join the Amazon Web Services (AWS) team building high-scale distributed cloud infrastructure services that power millions of customers globally. You will design, build, and deploy fault-tolerant microservices.",
    responsibilities: [
      "Design, implement, and maintain low-latency, high-availability distributed services.",
      "Collaborate with senior engineers to architect clean RESTful APIs and event-driven pipelines.",
      "Participate in code reviews, design docs, and operational excellence sprints.",
      "Write unit, integration, and stress tests ensuring 99.99% system uptime."
    ],
    requirements: [
      "B.Tech / B.E / M.Tech in Computer Science, IT, or related technical disciplines.",
      "Strong foundation in Data Structures, Algorithms, and Object-Oriented Design.",
      "Proficiency in at least one modern language: Java, C++, Python, or Go.",
      "Understanding of Relational & NoSQL databases (MySQL, DynamoDB, PostgreSQL)."
    ],
    interviewRounds: [
      "Round 1: Online Assessment (2 LeetCode Medium/Hard DSA questions + Work Style Assessment)",
      "Round 2: Technical Interview 1 (DSA: Trees/Graphs/DP + System Architecture basics)",
      "Round 3: Technical Interview 2 (Data Structures + Problem Solving + Low Level Design)",
      "Round 4: Bar Raiser & Amazon Leadership Principles (STAR method behavioral + scalability)"
    ],
    benefits: ["Health Insurance for family", "RSU Stock Grants", "Hybrid Work Flexibility", "Learning & Certification Budget"],
    applyUrl: "https://amazon.jobs",
    featured: true
  },
  {
    id: "job-2",
    title: "Frontend Engineer - React / Next.js",
    company: "Razorpay",
    logo: "https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=128&auto=format&fit=crop&q=80",
    companyBadge: "FinTech Unicorn",
    location: "Bengaluru (Remote Available)",
    mode: "Remote",
    type: "Full-time",
    experience: "1 - 3 Years",
    batch: "2023 / 2024 / 2025",
    salary: "₹18 - ₹28 LPA",
    salaryMin: 18,
    salaryMax: 28,
    skills: ["React", "TypeScript", "Tailwind CSS", "Next.js", "Web Performance", "State Management"],
    postedDate: "1 day ago",
    deadline: "2026-11-20",
    description: "Build developer-first payment checkout experiences, merchant analytics dashboards, and banking automation tools that process billions in transactions monthly.",
    responsibilities: [
      "Craft pixel-perfect, accessible, and blazing-fast web interfaces using React and TypeScript.",
      "Optimize core web vitals, bundle size, and micro-frontend architectures.",
      "Work closely with product managers and UI/UX designers to translate Figma into resilient code.",
      "Create reusable design system components with comprehensive test coverage."
    ],
    requirements: [
      "Solid command over modern JavaScript (ES6+), TypeScript, React, and browser internals.",
      "Demonstrated ability with state management libraries (Redux Toolkit, Zustand, or TanStack Query).",
      "Deep understanding of responsive CSS, Flexbox/Grid, and animation frameworks.",
      "Experience with frontend testing tools (Jest, React Testing Library, Cypress)."
    ],
    interviewRounds: [
      "Round 1: Machine Coding Challenge (Build an interactive React UI component in 90 mins)",
      "Round 2: Technical Deep Dive (JavaScript fundamentals, React internals, DOM, Performance)",
      "Round 3: Frontend Architecture & System Design (Caching, Offline sync, State modeling)",
      "Round 4: Culture Fit & Engineering Manager"
    ],
    benefits: ["Full Remote Stipend", "Wellness Allowance", "Stock Options (ESOPs)", "MacBook Pro provided"],
    applyUrl: "https://razorpay.com/careers",
    featured: true
  },
  {
    id: "job-3",
    title: "Associate Software Engineer",
    company: "Google",
    logo: "https://images.unsplash.com/photo-1572021335469-31706a17aaef?w=128&auto=format&fit=crop&q=80",
    companyBadge: "FAANG / Big Tech",
    location: "Hyderabad / Bengaluru",
    mode: "Hybrid",
    type: "Full-time",
    experience: "0 - 1 Years",
    batch: "2025 / 2026",
    salary: "₹30 - ₹55 LPA",
    salaryMin: 30,
    salaryMax: 55,
    skills: ["C++", "Python", "DSA", "Algorithms", "Operating Systems", "Computer Networks"],
    postedDate: "Just now",
    deadline: "2026-12-01",
    description: "At Google, engineers solve computational challenges of massive planetary scale. You will work on Search, YouTube, Android, Cloud, or Ads infrastructure.",
    responsibilities: [
      "Write clean, idiomatic, test-driven code in C++, Java, or Go.",
      "Analyze algorithm efficiency, Big-O complexities, and memory footprints.",
      "Collaborate across international teams to build robust scalable systems.",
      "Identify bottlenecks in production services and develop automated resilience fixes."
    ],
    requirements: [
      "Bachelor's or Master's degree in CS or equivalent field graduating in 2025/2026.",
      "Exceptional algorithmic problem-solving abilities (Competitive Programming or DSA).",
      "Proficiency with data structures (Segment Trees, Graphs, DP, Tries, Heaps).",
      "Solid grasp of operating systems, multithreading, and concurrency."
    ],
    interviewRounds: [
      "Round 1: Google Online Assessment / Coding Sample (2 Challenging Algorithmic Problems)",
      "Round 2: Technical Interview 1 (DSA & Complexity Analysis - Google Docs style coding)",
      "Round 3: Technical Interview 2 (Graph / DP / Advanced Trees Problem Solving)",
      "Round 4: Technical Interview 3 (System Logic & Algorithm Optimizations)",
      "Round 5: Googliness & Leadership (Values, Ethics, Teamwork, Inclusivity)"
    ],
    benefits: ["World-class free gourmet meals", "Relocation assistance", "Comprehensive insurance", "Substantial equity"],
    applyUrl: "https://careers.google.com",
    featured: true
  },
  {
    id: "job-4",
    title: "Backend Developer (Node.js & Go)",
    company: "Flipkart",
    logo: "https://images.unsplash.com/photo-1556742049-0a67e5572293?w=128&auto=format&fit=crop&q=80",
    companyBadge: "E-Commerce Leader",
    location: "Bengaluru, India",
    mode: "Onsite",
    type: "Full-time",
    experience: "1 - 3 Years",
    batch: "2023 / 2024 / 2025",
    salary: "₹16 - ₹26 LPA",
    salaryMin: 16,
    salaryMax: 26,
    skills: ["Node.js", "Golang", "Kafka", "Redis", "PostgreSQL", "Docker", "Microservices"],
    postedDate: "3 days ago",
    deadline: "2026-11-10",
    description: "Power the high-throughput inventory, order placement, and delivery logistics engines of India's biggest e-commerce platform during Big Billion Days sales.",
    responsibilities: [
      "Develop ultra-reliable backend APIs handling 100k+ requests per second.",
      "Design asynchronous message queues using Apache Kafka and Redis streams.",
      "Optimize database queries, indexing strategies, and database sharding.",
      "Implement zero-downtime deployment pipelines with Kubernetes."
    ],
    requirements: [
      "Strong background in Backend development using Node.js, Go, or Java.",
      "Hands-on experience with SQL/NoSQL databases and caching layers.",
      "Solid understanding of concurrency, event-driven architectures, and idempotency.",
      "Familiarity with containerization (Docker, Kubernetes) and CI/CD."
    ],
    interviewRounds: [
      "Round 1: Machine Coding (Implement a clean Object-Oriented design like Splitwise/Parking Lot)",
      "Round 2: Problem Solving & DSA (Data structures & edge case handling)",
      "Round 3: System Design & Architecture (Scalable backend design, Caching, DB schema)",
      "Round 4: Hiring Manager Discussion"
    ],
    benefits: ["Cab facility & meals", "Gym membership", "Annual bonus & appraisal", "Health insurance"],
    applyUrl: "https://flipkartcareers.com",
    featured: false
  },
  {
    id: "job-5",
    title: "Software Engineer Intern (Summer 2025/2026)",
    company: "Microsoft",
    logo: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=128&auto=format&fit=crop&q=80",
    companyBadge: "FAANG / Big Tech",
    location: "Hyderabad / Noida / Bengaluru",
    mode: "Hybrid",
    type: "Internship",
    experience: "0 Years (College Students)",
    batch: "2026 / 2027",
    salary: "₹1.25 Lakh / month stipend",
    salaryMin: 15,
    salaryMax: 20,
    skills: ["C#", "C++", "Python", "Data Structures", "Algorithms", "Azure"],
    postedDate: "4 days ago",
    deadline: "2026-11-25",
    description: "Join Microsoft for an intensive 2-month summer internship with high pre-placement offer (PPO) conversion rate! Work directly on Azure Cloud, Teams, Office, or Windows core systems.",
    responsibilities: [
      "Ship a meaningful end-to-end feature during your 8-12 week internship tenure.",
      "Learn industry-standard version control, CI/CD, and agile engineering practices.",
      "Receive 1-on-1 mentorship from principal engineers and engineering leaders.",
      "Present your final project to department leaders and product directors."
    ],
    requirements: [
      "Currently pursuing B.Tech/B.E./Dual Degree graduating in 2026 or 2027.",
      "CGPA 7.0 and above with no active backlogs.",
      "Strong coding skills in C++, C#, Java, or Python.",
      "Curious mindset and passion for solving challenging algorithmic problems."
    ],
    interviewRounds: [
      "Round 1: Microsoft Online Assessment (3 Coding questions on Codility/Mettle)",
      "Round 2: Technical Interview 1 (DSA: Linked Lists, Trees, Dynamic Programming)",
      "Round 3: Technical Interview 2 (System fundamentals, Array manipulations, Edge cases)",
      "Round 4: AA (As Appropriate / Partner Director Round - Problem solving & fitment)"
    ],
    benefits: ["Free corporate housing / hotel stay", "Travel reimbursement", "Full PPO eligibility", "Mentorship program"],
    applyUrl: "https://careers.microsoft.com",
    featured: true
  },
  {
    id: "job-6",
    title: "Systems Engineer (Digital & Prime Cadre)",
    company: "TCS (Tata Consultancy Services)",
    logo: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=128&auto=format&fit=crop&q=80",
    companyBadge: "MNC / Service Titan",
    location: "Pan India (Multiple Locations)",
    mode: "Onsite",
    type: "Full-time",
    experience: "0 - 1 Years",
    batch: "2024 / 2025 / 2026",
    salary: "₹7.0 - ₹9.5 LPA",
    salaryMin: 7,
    salaryMax: 9.5,
    skills: ["Python", "Java", "SQL", "Cloud Basics", "Aptitude", "Problem Solving"],
    postedDate: "5 days ago",
    deadline: "2026-11-30",
    description: "TCS National Qualifier Test (NQT) drive for Prime & Digital cadres! Selected candidates will work on next-generation digital transformation, AI solutions, and enterprise cloud modernisation.",
    responsibilities: [
      "Develop enterprise client software using modern stacks.",
      "Collaborate in cross-functional agile teams across worldwide delivery centres.",
      "Undergo specialized digital cadre training with global certification tracks.",
      "Maintain enterprise software quality through automated unit testing."
    ],
    requirements: [
      "B.E./B.Tech/M.E./M.Tech/MCA/M.Sc with 60% or 6.0 CGPA throughout academics.",
      "No active backlogs at the time of appearing for the process.",
      "Good communication skills and logical reasoning ability.",
      "Basic understanding of at least one programming language (C, C++, Java, or Python)."
    ],
    interviewRounds: [
      "Round 1: TCS NQT Foundation + Advanced Cognitive & Coding Section (180 mins)",
      "Round 2: Technical Interview (Core CS: DBMS, OS, OOPS + Project discussion)",
      "Round 3: HR & Managerial Interview (Communication, Flexibility, Relocation)"
    ],
    benefits: ["Health insurance", "Annual performance incentives", "Higher education sponsorship", "Job stability"],
    applyUrl: "https://www.tcs.com/careers",
    featured: false
  },
  {
    id: "job-7",
    title: "Cloud & DevOps Engineer",
    company: "Atlassian",
    logo: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=128&auto=format&fit=crop&q=80",
    companyBadge: "Global SaaS Leader",
    location: "Remote (Work from Anywhere in India)",
    mode: "Remote",
    type: "Full-time",
    experience: "1 - 4 Years",
    batch: "2023 / 2024 / 2025",
    salary: "₹25 - ₹40 LPA",
    salaryMin: 25,
    salaryMax: 40,
    skills: ["Kubernetes", "AWS", "Terraform", "CI/CD", "Linux", "Python/Bash", "Monitoring"],
    postedDate: "6 days ago",
    deadline: "2026-11-18",
    description: "Empower teamwork worldwide by building resilient cloud platforms that power Jira, Confluence, and Bitbucket for 250,000+ organizations.",
    responsibilities: [
      "Automate infrastructure provisioning using Terraform and AWS CloudFormation.",
      "Manage large-scale multi-region Kubernetes clusters with zero downtime.",
      "Architect CI/CD pipelines ensuring safe, fast, and automated deployments.",
      "Set up observability dashboards with Prometheus, Grafana, and Datadog."
    ],
    requirements: [
      "Solid experience with Linux systems administration, networking, and scripting.",
      "Expertise with container orchestration (Kubernetes, Docker).",
      "Hands-on experience with cloud providers (AWS, GCP, or Azure).",
      "Understanding of Site Reliability Engineering (SRE) principles."
    ],
    interviewRounds: [
      "Round 1: SRE Online Assessment (Scripting + Linux Troubleshooting)",
      "Round 2: Systems Coding & Automation Interview (Python/Go)",
      "Round 3: Infrastructure Architecture & Cloud Design Interview",
      "Round 4: Atlassian Values & Culture Interview (Open Company, No Bullshit)"
    ],
    benefits: ["100% Remote flexibility", "Generous home office stipend", "Well-being days", "Parental leave"],
    applyUrl: "https://www.atlassian.com/company/careers",
    featured: false
  },
  {
    id: "job-8",
    title: "Specialist Programmer (Power Programmer)",
    company: "Infosys",
    logo: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=128&auto=format&fit=crop&q=80",
    companyBadge: "MNC / Service Titan",
    location: "Bengaluru / Pune / Hyderabad",
    mode: "Hybrid",
    type: "Full-time",
    experience: "0 - 1 Years",
    batch: "2024 / 2025 / 2026",
    salary: "₹9.5 - ₹12 LPA",
    salaryMin: 9.5,
    salaryMax: 12,
    skills: ["Competitive Programming", "DSA", "Java", "Python", "Full Stack", "System Design"],
    postedDate: "1 week ago",
    deadline: "2026-12-05",
    description: "Infosys Specialist Programmer role via HackWithInfy! High-tier engineering position working on high-impact consulting and deep-tech innovation projects.",
    responsibilities: [
      "Develop complex algorithmic solutions for Fortune 500 enterprise applications.",
      "Work directly with global technical architects and engineering leaders.",
      "Rapidly prototype proofs-of-concept using cutting-edge AI and cloud architectures."
    ],
    requirements: [
      "Outstanding score in HackWithInfy / InfyTQ or qualifying campus rounds.",
      "High proficiency in competitive coding and advanced data structures.",
      "B.Tech / M.Tech in CS/IT or related branches with minimum 65% aggregate.",
      "Clear conceptual understanding of OOPs, OS, and Database internals."
    ],
    interviewRounds: [
      "Round 1: HackWithInfy Qualifier (3 Complex Algorithmic Problems - 3 Hours)",
      "Round 2: Advanced Technical Interview (DSA + Design + Deep project cross-questioning)",
      "Round 3: HR & Behavioral Evaluation"
    ],
    benefits: ["Accelerated career progression track", "Global project exposure", "Higher entry salary band"],
    applyUrl: "https://www.infosys.com/careers",
    featured: false
  }
];

export const getSavedJobs = () => {
  try {
    const data = localStorage.getItem("careerforge_saved_jobs");
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
};

export const setSavedJobs = (jobs) => {
  try {
    localStorage.setItem("careerforge_saved_jobs", JSON.stringify(jobs));
  } catch (e) {
    console.error("Failed to save jobs", e);
  }
};

export const getAppliedJobs = () => {
  try {
    const data = localStorage.getItem("careerforge_applied_jobs");
    return data ? JSON.parse(data) : [
      {
        id: "app-1",
        jobId: "job-1",
        title: "Software Development Engineer - I (SDE 1)",
        company: "Amazon",
        appliedDate: "2026-10-12",
        status: "Applied",
        notes: "Applied via referral with updated resume emphasizing DSA & AWS projects."
      },
      {
        id: "app-2",
        jobId: "job-2",
        title: "Frontend Engineer - React / Next.js",
        company: "Razorpay",
        appliedDate: "2026-10-10",
        status: "In Review",
        notes: "Completed machine coding submission, waiting for Round 2 scheduling."
      }
    ];
  } catch {
    return [];
  }
};

export const setAppliedJobs = (applications) => {
  try {
    localStorage.setItem("careerforge_applied_jobs", JSON.stringify(applications));
  } catch (e) {
    console.error("Failed to save applied jobs", e);
  }
};
