import React, { useState } from 'react';
import { X, Copy, Check, ExternalLink, Lightbulb, Clock, Database, Code2 } from 'lucide-react';

export const SolutionModal = ({ problem, onClose }) => {
  const [selectedLang, setSelectedLang] = useState('cpp');
  const [copied, setCopied] = useState(false);

  if (!problem) return null;

  const code = problem.codeSnippets[selectedLang] || '// Solution not available';

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const difficultyColors = {
    Easy: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    Medium: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    Hard: 'bg-rose-500/10 text-rose-400 border-rose-500/20'
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="space-y-1">
            <div className="flex items-center gap-2.5">
              <span className={`text-[11px] font-semibold px-2.5 py-0.5 rounded-full border ${difficultyColors[problem.difficulty]}`}>
                {problem.difficulty}
              </span>
              <h3 className="font-bold text-lg text-white">{problem.title}</h3>
            </div>
            <div className="flex items-center gap-3 text-xs text-slate-400">
              <span className="flex items-center gap-1 text-slate-300">
                <Clock className="w-3.5 h-3.5 text-indigo-400" /> Time: {problem.timeComplexity}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1 text-slate-300">
                <Database className="w-3.5 h-3.5 text-emerald-400" /> Space: {problem.spaceComplexity}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {problem.leetcodeUrl && (
              <a
                href={problem.leetcodeUrl}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                title="Open on LeetCode"
              >
                <ExternalLink className="w-4 h-4" />
              </a>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 overflow-y-auto flex-1">
          {/* Intuition Box */}
          <div className="rounded-xl p-4 bg-indigo-950/20 border border-indigo-500/20 space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-semibold text-indigo-400 uppercase tracking-wider">
              <Lightbulb className="w-4 h-4 text-yellow-400" /> Intuition & Approach
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              {problem.intuition}
            </p>
          </div>

          {/* Companies Tested In */}
          {problem.companies && problem.companies.length > 0 && (
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span className="font-medium text-slate-300">Asked in:</span>
              <div className="flex flex-wrap gap-1.5">
                {problem.companies.map((c, i) => (
                  <span key={i} className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[11px] border border-slate-700">
                    {c}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Code Tabs */}
          <div className="space-y-2">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-1">
                {[
                  { id: 'cpp', label: 'C++' },
                  { id: 'java', label: 'Java' },
                  { id: 'python', label: 'Python 3' },
                  { id: 'javascript', label: 'JavaScript' }
                ].map((lang) => (
                  <button
                    key={lang.id}
                    onClick={() => setSelectedLang(lang.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                      selectedLang === lang.id
                        ? 'bg-indigo-600 text-white shadow'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                    }`}
                  >
                    {lang.label}
                  </button>
                ))}
              </div>

              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-400" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>
            </div>

            {/* Code Block */}
            <div className="relative rounded-xl bg-slate-950 border border-slate-800 p-4 font-mono text-xs overflow-x-auto text-slate-200 leading-relaxed max-h-96">
              <pre>
                <code>{code}</code>
              </pre>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between text-xs text-slate-500">
          <span>Target Optimal Complexity: {problem.timeComplexity}</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
