export const companiesList = [
  {
    id: "google",
    name: "Google",
    logo: "https://images.unsplash.com/photo-1572021335469-31706a17aaef?w=128&auto=format&fit=crop&q=80",
    tier: "Tier 1 / Big Tech",
    difficulty: "Very High",
    avgCtc: "₹32 - ₹58 LPA",
    internStipend: "₹1.15 - ₹1.4 Lakh / month",
    overview: "Google's hiring bar centers strictly on algorithmic mastery, clean production-ready code with no compiler, complexity trade-offs, and 'Googliness' (cultural alignment, intellectual humility, and collaboration).",
    eligibility: {
      minCgpa: "No rigid CGPA cutoff (Generally 7.0+ preferred in campus hiring)",
      backlogs: "No active backlogs at the time of joining",
      branches: "B.Tech/M.Tech/Dual Degree in CS, IT, Math & Computing, ECE or equivalent practical experience",
      gapAllowed: "No formal restrictions on education gaps if technical competency is proven"
    },
    examPattern: [
      {
        section: "Online Assessment (OA) / Coding Sample",
        duration: "90 Minutes",
        questions: "2 Complex Algorithmic Problems",
        negativeMarking: "No",
        platform: "HackerEarth / Google Internal Testing Platform"
      },
      {
        section: "Technical Phone Screen (Telephonic/Google Meet)",
        duration: "45 Minutes",
        questions: "1-2 Algorithmic DSA problems coded live on Google Docs/Interview Editor",
        negativeMarking: "N/A",
        platform: "Google Meet"
      },
      {
        section: "Virtual Onsite: Technical Rounds 1, 2, and 3",
        duration: "45 Minutes each",
        questions: "Advanced Data Structures, Graph Traversals, DP, Tries, Algorithm Optimization",
        negativeMarking: "N/A",
        platform: "Google Meet"
      },
      {
        section: "Googliness & Leadership Round",
        duration: "45 Minutes",
        questions: "Ethical dilemmas, ambiguity handling, teamwork, resolving technical consensus",
        negativeMarking: "N/A",
        platform: "Google Meet"
      }
    ],
    syllabus: {
      coding: ["Graph Algorithms (Dijkstra, BFS/DFS, Topological Sort)", "Dynamic Programming (2D, Bitmask)", "Tries & Segment Trees", "Binary Search on Answer Space", "Strings & Rolling Hash"],
      coreCs: ["Time & Space Complexity Proofs", "Concurrency & Thread Safety Basics", "System Architecture & Memory Layout"],
      aptitude: ["No Aptitude round for SDE roles; 100% focused on algorithmic problem solving"]
    },
    hiringProcess: [
      {
        round: "Step 1: Resume Screening & OA",
        detail: "Recruiters screen for impactful projects, competitive programming profiles (Codeforces, LeetCode), and previous internships. Shortlisted candidates receive an invite to the 90-minute 2-question coding OA."
      },
      {
        round: "Step 2: Technical Rounds (3-4 Rounds)",
        detail: "Live collaborative coding on Google Docs/Sandbox with zero auto-completion. Interviewers evaluate code cleanliness, modularity, edge case handling, and ability to verbally articulate thought processes before writing code."
      },
      {
        round: "Step 3: Googliness Round",
        detail: "Evaluates intellectual humility, willingness to learn, bias for action, and response to ethical workplace scenarios using STAR format."
      },
      {
        round: "Step 4: Hiring Committee (HC) Review",
        detail: "Unlike most companies where the interviewer decides directly, Google sends comprehensive interviewer feedback packets to an independent Hiring Committee for unanimous consensus."
      }
    ],
    proTips: [
      "Never start coding immediately. Spend the first 5-8 minutes clarifying constraints, input sizes, negative values, and writing out sample test cases.",
      "Google Docs has no syntax highlighting or indentation helper—practice writing syntactically valid C++/Java/Python in plain text without an IDE.",
      "Communicate constantly: say what you're thinking out loud so the interviewer can steer you if you head toward a suboptimal path."
    ],
    frequentlyAskedTopics: ["Graphs & Trees (35%)", "Dynamic Programming (25%)", "Arrays & Two Pointers (20%)", "Binary Search & Math (20%)"]
  },
  {
    id: "amazon",
    name: "Amazon",
    logo: "https://images.unsplash.com/photo-1523474253246-64e03e5eeae1?w=128&auto=format&fit=crop&q=80",
    tier: "Tier 1 / Big Tech",
    difficulty: "High",
    avgCtc: "₹28 - ₹45 LPA",
    internStipend: "₹80,000 - ₹1.1 Lakh / month",
    overview: "Amazon evaluates candidates on two equal pillars: 50% Algorithmic & Data Structure prowess and 50% strict adherence to Amazon's 16 Leadership Principles (LPs) across all interview rounds.",
    eligibility: {
      minCgpa: "6.5 CGPA or 65% aggregate with no standing backlogs",
      backlogs: "0 Active Backlogs allowed at the time of application",
      branches: "B.Tech/M.Tech/MCA in CS, IT, ECE, EEE or allied engineering branches",
      gapAllowed: "Maximum 1 year gap allowed between education levels"
    },
    examPattern: [
      {
        section: "Online Assessment 1: Code Debugging + Coding",
        duration: "70 Minutes",
        questions: "2 Coding Questions (Medium LeetCode level) + Work Style Assessment",
        negativeMarking: "No",
        platform: "Hackerrank"
      },
      {
        section: "Online Assessment 2: Work Simulation & LP Survey",
        duration: "90 Minutes",
        questions: "Interactive workplace email/ticket resolution scenarios mapped to 16 LPs",
        negativeMarking: "No",
        platform: "Amazon Assessment Portal"
      },
      {
        section: "Technical Interview 1: DSA & Problem Solving",
        duration: "60 Minutes",
        questions: "Trees/Graphs/Heaps + 2 Leadership Principle STAR questions",
        negativeMarking: "N/A",
        platform: "Amazon Chime / LiveCode"
      },
      {
        section: "Technical Interview 2: LLD / OOD & Data Structures",
        duration: "60 Minutes",
        questions: "Object-Oriented Design (e.g. Parking Lot, Movie Booking) + LP behavioral stories",
        negativeMarking: "N/A",
        platform: "Amazon Chime"
      },
      {
        section: "Bar Raiser Round",
        duration: "60 Minutes",
        questions: "Independent senior interviewer outside the hiring team evaluating technical depth & extreme LP scrutiny",
        negativeMarking: "N/A",
        platform: "Amazon Chime"
      }
    ],
    syllabus: {
      coding: ["Binary Trees & BST (LCA, Path Sum, Traversal)", "Graphs (BFS/DFS, Topological Sort)", "Heaps & Priority Queues", "Sliding Window & Hash Maps", "Dynamic Programming"],
      coreCs: ["Object-Oriented Design (LLD)", "Database Schema Design & Normalization", "Concurrency & Thread Safety"],
      aptitude: ["Amazon Work Style Assessment (Behavioral judgment based on Customer Obsession, Ownership, Bias for Action, Dive Deep)"]
    },
    hiringProcess: [
      {
        round: "Round 1: OA (Coding + Work Simulation)",
        detail: "2 coding questions + situational judgment assessment simulating everyday Amazon SDE decision scenarios."
      },
      {
        round: "Round 2 & 3: Technical DSA & OOD",
        detail: "Focuses on clean object-oriented code, data structure selection, and 20 minutes of deep LP grilling per round."
      },
      {
        round: "Round 4: Bar Raiser",
        detail: "Conducted by a specially trained Bar Raiser who holds veto power. Focuses on whether the candidate raises the median performance bar of Amazon engineers."
      }
    ],
    proTips: [
      "Prepare at least 6-8 distinct stories following the STAR method mapped to Amazon Leadership Principles (Customer Obsession, Ownership, Invent & Simplify, Bias for Action, Have Backbone).",
      "Always discuss time and space complexity immediately after writing your solution without waiting for the interviewer to ask.",
      "Amazon loves Heap/Priority Queue and Tree problems—ensure you master BFS/DFS and two-heap patterns."
    ],
    frequentlyAskedTopics: ["Trees & BST (30%)", "Strings & Arrays (25%)", "Heaps & Hash Maps (25%)", "Dynamic Programming (20%)"]
  },
  {
    id: "microsoft",
    name: "Microsoft",
    logo: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=128&auto=format&fit=crop&q=80",
    tier: "Tier 1 / Big Tech",
    difficulty: "High",
    avgCtc: "₹26 - ₹45 LPA",
    internStipend: "₹1.0 - ₹1.25 Lakh / month",
    overview: "Microsoft focuses deeply on writing production-quality bug-free code, edge case consideration, understanding memory layouts, and Growth Mindset values.",
    eligibility: {
      minCgpa: "7.0 CGPA or 70% in current degree with no backlogs",
      backlogs: "Zero active backlogs permitted",
      branches: "B.Tech/M.Tech in CS, IT, Software Engineering, ECE, EEE",
      gapAllowed: "Up to 1 year gap in academics allowed"
    },
    examPattern: [
      {
        section: "Online Assessment (Codility)",
        duration: "70-90 Minutes",
        questions: "3 Coding Problems (Varied difficulty: Easy, Medium, Hard)",
        negativeMarking: "No",
        platform: "Codility"
      },
      {
        section: "Technical Round 1",
        duration: "45-60 Minutes",
        questions: "DSA (Linked Lists, Arrays, Strings, Recursion) + Edge case testing",
        negativeMarking: "N/A",
        platform: "Microsoft Teams"
      },
      {
        section: "Technical Round 2",
        duration: "45-60 Minutes",
        questions: "Advanced DSA (Trees, Graphs, DP) + Core CS concepts (OS, Memory management)",
        negativeMarking: "N/A",
        platform: "Microsoft Teams"
      },
      {
        section: "Technical Round 3 / AA (As Appropriate) Round",
        duration: "45-60 Minutes",
        questions: "Principal Engineer / Partner Director round covering architectural problem-solving, project deep dive, and Growth Mindset fit",
        negativeMarking: "N/A",
        platform: "Microsoft Teams"
      }
    ],
    syllabus: {
      coding: ["Linked Lists & Pointers", "Binary Trees & BST", "Dynamic Programming", "Bit Manipulation & Arrays", "Graphs & Shortest Path"],
      coreCs: ["Operating Systems (Processes, Paging, Deadlocks)", "OOPs Principles & Design Patterns", "Computer Networks basics"],
      aptitude: ["Pure coding and technical questions; no generic aptitude section in OA"]
    },
    hiringProcess: [
      {
        round: "Round 1: Codility Assessment",
        detail: "3 algorithmic questions. Passing test cases requires strictly optimal time complexity; hidden performance test cases evaluate big O efficiency."
      },
      {
        round: "Round 2 & 3: Technical Interviews",
        detail: "Focus on clean code, unit test planning, pointer manipulation, and reasoning through null pointers and boundary limits."
      },
      {
        round: "Round 4: AA (As Appropriate) Round",
        detail: "Senior leadership conversation focusing on your curiosity, handling failures, and architectural vision."
      }
    ],
    proTips: [
      "Always write manual test cases before telling the interviewer you are done. Walk through your code line by line with an empty array or single-element input.",
      "Microsoft places great value on 'Growth Mindset'—show how you learn from setbacks and accept constructive feedback graciously during the interview.",
      "Review Linked List and Tree pointer manipulations thoroughly (reversing in k-groups, clone with random pointer, flattening binary trees)."
    ],
    frequentlyAskedTopics: ["Linked Lists & Trees (35%)", "Arrays & Strings (30%)", "Dynamic Programming (20%)", "Operating Systems (15%)"]
  },
  {
    id: "tcs",
    name: "TCS (Tata Consultancy Services)",
    logo: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=128&auto=format&fit=crop&q=80",
    tier: "Service Titan / Mass Recruiter",
    difficulty: "Moderate",
    avgCtc: "₹3.36 LPA (Ninja) | ₹7.0 LPA (Digital) | ₹9.0 - ₹11.5 LPA (Prime)",
    internStipend: "N/A (Campus Drive / NQT)",
    overview: "TCS recruits through the National Qualifier Test (NQT). Candidates can qualify for Ninja, Digital, or Prime cadres based on their performance in the cognitive and advanced coding sections.",
    eligibility: {
      minCgpa: "Minimum 60% or 6.0 CGPA throughout 10th, 12th, Diploma, and Graduation",
      backlogs: "Maximum 1 active backlog permitted at test time (must be cleared before joining)",
      branches: "All Engineering branches (B.E/B.Tech/M.E/M.Tech/MCA/M.Sc)",
      gapAllowed: "Maximum 24 months (2 years) overall education gap permitted with valid justification"
    },
    examPattern: [
      {
        section: "Part A: Foundation Cognitive Section",
        duration: "75 Minutes",
        questions: "Numerical Ability (20 Qs) + Reasoning Ability (20 Qs) + Verbal Ability (25 Qs)",
        negativeMarking: "No negative marking",
        platform: "TCS iON Hub"
      },
      {
        section: "Part B: Advanced Cognitive & Coding (For Digital & Prime)",
        duration: "90 Minutes",
        questions: "Advanced Quants & Reasoning (25 Qs) + Advanced Coding (2 Programming Problems)",
        negativeMarking: "No negative marking",
        platform: "TCS iON Hub"
      },
      {
        section: "Combined Interview Round (Tech + MR + HR)",
        duration: "30 - 45 Minutes",
        questions: "Core CS (DBMS, OOPs), Final Year Project, Basic DSA, Managerial situational scenarios, Willingness to relocate & shifts",
        negativeMarking: "N/A",
        platform: "In-Person / MS Teams"
      }
    ],
    syllabus: {
      coding: ["Arrays & Strings Manipulations", "Matrix Operations", "Number Theory & Math Algorithms", "Recursion & Searching/Sorting"],
      coreCs: ["DBMS (SQL Queries, Normalization, ACID)", "OOPs (Inheritance, Polymorphism)", "Basics of SDLC and Cloud Technologies"],
      aptitude: ["Time & Work", "Percentages & Profit-Loss", "Speed, Distance & Time", "Data Interpretation", "Syllogisms & Blood Relations", "Reading Comprehension & Grammar"]
    },
    hiringProcess: [
      {
        round: "Round 1: TCS NQT Examination",
        detail: "Proctored assessment conducted at TCS iON physical centers or online. High scorers qualify directly for Digital and Prime cadre interviews."
      },
      {
        round: "Round 2: Technical Interview",
        detail: "Verifies coding solutions written during the exam, questions on resume projects, SQL queries, and basic programming language syntax."
      },
      {
        round: "Round 3: Managerial & HR Interview",
        detail: "Assesses communication, willingness to work in 24/7 rotational shifts, relocation readiness, and background verification."
      }
    ],
    proTips: [
      "Speed is crucial in Part A: Solve high-scoring arithmetic questions first and don't get stuck on single complex puzzles.",
      "For Digital & Prime, both coding problems must pass all private test cases—watch out for large integer boundary overflows (use long in Java or long long in C++).",
      "Be thoroughly prepared to explain every single line of code in your resume project."
    ],
    frequentlyAskedTopics: ["Quantitative Aptitude (35%)", "Basic & Intermediate Coding (30%)", "SQL & DBMS (20%)", "Reasoning Ability (15%)"]
  },
  {
    id: "infosys",
    name: "Infosys",
    logo: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=128&auto=format&fit=crop&q=80",
    tier: "Service Titan / Mass Recruiter",
    difficulty: "Moderate to High (for SP)",
    avgCtc: "₹3.6 LPA (System Engineer) | ₹6.25 LPA (DSE) | ₹9.5 LPA (Specialist Programmer)",
    internStipend: "N/A",
    overview: "Infosys conducts hiring through campus placement drives and national competitions like HackWithInfy and InfyTQ. Specialist Programmer (SP) is their highest tier software development role.",
    eligibility: {
      minCgpa: "Minimum 60% or 6.0 CGPA in 10th, 12th, and Graduation",
      backlogs: "No active backlogs allowed at the time of the hiring process",
      branches: "B.E/B.Tech/M.E/M.Tech in any branch; MCA and M.Sc (Computer Science / IT)",
      gapAllowed: "Maximum 2 years of education gap permitted"
    },
    examPattern: [
      {
        section: "Standard Drive: Online Test (System Engineer)",
        duration: "100 Minutes",
        questions: "Reasoning (15 Qs) + Mathematical Ability (10 Qs) + Verbal (20 Qs) + Pseudocode (5 Qs) + Puzzle Solving (4 Qs)",
        negativeMarking: "No negative marking",
        platform: "Infosys Assessment Platform"
      },
      {
        section: "HackWithInfy / SP Qualifier Round",
        duration: "180 Minutes (3 Hours)",
        questions: "3 High-Complexity Algorithmic Coding Problems (DP, Graphs, Greedy)",
        negativeMarking: "No",
        platform: "HackerEarth"
      },
      {
        section: "Technical & HR Interview",
        duration: "30 - 45 Minutes",
        questions: "DSA, OOPs, DBMS, Operating Systems, Project deep-dive, behavioral questions",
        negativeMarking: "N/A",
        platform: "Infosys Virtual Platform"
      }
    ],
    syllabus: {
      coding: ["Dynamic Programming", "Graph Traversals (BFS/DFS, Dijkstra)", "Bitmasking & Greedy", "Array/String Manipulation"],
      coreCs: ["Database Management (Joins, Indexes, Triggers)", "OOPs (Inheritance, Interfaces, Abstract Classes)", "Operating Systems concepts"],
      aptitude: ["Cryptography / Puzzle solving", "Data Sufficiency", "Syllogisms & Analytical Puzzles", "Sentence Correction"]
    },
    hiringProcess: [
      {
        round: "Round 1: Online Assessment / HackWithInfy",
        detail: "Standard campus test or 3-hour competitive programming contest where solving 2+ problems qualifies for SP/DSE interview."
      },
      {
        round: "Round 2: Technical Interview",
        detail: "In-depth review of HackWithInfy solutions, live coding, OOPs principles, and DBMS schema design."
      },
      {
        round: "Round 3: HR Interview",
        detail: "Basic background verification, communication check, and relocation confirmation."
      }
    ],
    proTips: [
      "Infosys tests pseudocode reading: practice predicting output of recursive functions and pointer operations under tight time constraints.",
      "In HackWithInfy, even a partial solution (passing 50% test cases) can qualify you for the Digital Specialist Engineer (DSE) role.",
      "Prepare your final year project thoroughly—interviewers will ask you to draw architecture diagrams and explain database tables."
    ],
    frequentlyAskedTopics: ["Competitive Coding (for SP) (40%)", "Logical Puzzles & Pseudocode (30%)", "Core CS & SQL (30%)"]
  },
  {
    id: "atlassian",
    name: "Atlassian",
    logo: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=128&auto=format&fit=crop&q=80",
    tier: "Tier 1 / Product SaaS",
    difficulty: "Very High",
    avgCtc: "₹45 - ₹75 LPA",
    internStipend: "₹1.0 - ₹1.3 Lakh / month",
    overview: "Atlassian offers one of the highest entry-level packages in India. Known for extensive live coding, system design, and rigorous adherence to their core values: 'Open company, no bullshit' and 'Don't #@!% the customer'.",
    eligibility: {
      minCgpa: "7.0+ CGPA with no standing backlogs",
      backlogs: "0 active backlogs",
      branches: "B.Tech/Dual Degree/M.Tech in CS/IT/ECE or related branches",
      gapAllowed: "Not strictly limited if candidates possess strong engineering achievements"
    },
    examPattern: [
      {
        section: "Online Assessment (OA)",
        duration: "90 Minutes",
        questions: "3 Complex Coding Problems on HackerRank (Heavy on Graphs, DP, and String Matching)",
        negativeMarking: "No",
        platform: "HackerRank"
      },
      {
        section: "Coding Round 1 (Data Structures & Algorithms)",
        duration: "60 Minutes",
        questions: "Production-quality clean code with unit tests (e.g. Rate Limiter, File System, Tagging System)",
        negativeMarking: "N/A",
        platform: "Zoom / CoderPad"
      },
      {
        section: "Coding Round 2 (Design & Architecture)",
        duration: "60 Minutes",
        questions: "Object-Oriented Design & Low-Level Architecture (Extensibility, SOLID principles)",
        negativeMarking: "N/A",
        platform: "Zoom / CoderPad"
      },
      {
        section: "Atlassian Values & Management Interview",
        duration: "45 Minutes",
        questions: "Deep behavioral evaluation based on Atlassian's 5 core company values",
        negativeMarking: "N/A",
        platform: "Zoom"
      }
    ],
    syllabus: {
      coding: ["Graph Algorithms & Shortest Path", "Dynamic Programming", "Tries & Hash Maps", "Concurrency & Multithreading in Java/C++"],
      coreCs: ["Low-Level Design (LLD)", "Design Patterns (Strategy, Factory, Observer)", "SOLID Principles", "System Scalability"],
      aptitude: ["No aptitude test; 100% engineering craftsmanship and values assessment"]
    },
    hiringProcess: [
      {
        round: "Round 1: HackerRank OA",
        detail: "3 difficult algorithmic problems. Perfect or near-perfect score required for interview shortlisting."
      },
      {
        round: "Round 2 & 3: Live Interactive Coding",
        detail: "Interviewers want to see clean, modular, extensible code with proper class structures and unit tests, not just brute-force hacky scripts."
      },
      {
        round: "Round 4: Values Round",
        detail: "Rigorous behavioral assessment evaluating teamwork, constructive feedback, empathy, and integrity."
      }
    ],
    proTips: [
      "Atlassian tests whether code is readable and maintainable. Use descriptive variable names, write clean helper methods, and include unit tests.",
      "Review Atlassian's 5 Core Values and prepare concrete examples where you embodied each value.",
      "Practice coding on CoderPad with unit testing frameworks."
    ],
    frequentlyAskedTopics: ["Data Structures & Graph Algorithms (40%)", "Low-Level Design / Clean Code (35%)", "Values & Behavioral (25%)"]
  }
];
