export const starMethodGuide = {
  title: "The STAR Framework for Behavioral Interviews",
  description: "The gold-standard method utilized by Amazon, Google, Microsoft, and top recruiters worldwide to evaluate past behavior as the best predictor of future performance.",
  steps: [
    {
      letter: "S",
      name: "Situation",
      allocation: "15% of your answer",
      description: "Set the context and background. Where and when did this take place? What was the business scenario or challenge?",
      tips: "Keep it concise (2-3 sentences). Don't drown the interviewer in technical jargon before getting to your action."
    },
    {
      letter: "T",
      name: "Task",
      allocation: "15% of your answer",
      description: "Explain your specific responsibility or the goal you needed to achieve. What was the hurdle or expectation?",
      tips: "Clearly distinguish your personal task from general team goals. Use 'I was responsible for' rather than 'We had to'."
    },
    {
      letter: "A",
      name: "Action",
      allocation: "55% of your answer",
      description: "Describe the specific steps YOU took. How did you diagnose the problem, collaborate, solve blockers, and execute?",
      tips: "This is the most critical part! Focus on YOUR decisions, thought process, and technical or communication skills."
    },
    {
      letter: "R",
      name: "Result",
      allocation: "15% of your answer",
      description: "Share the quantifiable outcome of your actions. Did you improve latency by 40%? Deliver 2 weeks ahead of deadline?",
      tips: "Use real metrics (percentages, dollars saved, hours reduced). Also mention what you learned or how the team benefited."
    }
  ]
};

export const hrQuestions = [
  {
    id: "hr-1",
    category: "Introduction",
    question: "Tell me about yourself / Walk me through your resume.",
    interviewerIntent: "Evaluating communication clarity, self-awareness, professional trajectory, and whether you can pitch your relevant strengths concisely within 2 minutes.",
    idealStrategy: "Use the 'Present - Past - Future' structure: 1) What you currently do and your core technical strengths. 2) 1 or 2 key past achievements/projects that demonstrate impact. 3) Why this specific role and company is your ideal next step.",
    sampleAnswer: "I'm a final-year Computer Science undergraduate with a passion for building scalable web applications and distributed systems. Recently, I completed an internship at a FinTech startup where I engineered an automated payment verification pipeline using Node.js and Redis, reducing reconciliation processing times by 35%. Outside of coursework, I've solved over 450 algorithmic problems on LeetCode and led our university hackathon team to 1st place among 80 teams. I've followed your engineering blog's work on microservices resilience, and I'm thrilled at the opportunity to contribute my problem-solving and full-stack development skills to your core platform team.",
    redFlags: [
      "Starting from kindergarten or listing your entire life story.",
      "Reciting your resume word-for-word without adding color or enthusiasm.",
      "Speaking for longer than 2.5 minutes without pause."
    ]
  },
  {
    id: "hr-2",
    category: "Behavioral",
    question: "Tell me about a time you faced a tough technical challenge and how you overcame it.",
    interviewerIntent: "Assessing problem-solving tenacity, analytical rigor, ability to debug under ambiguity, and whether you seek help appropriately.",
    idealStrategy: "Pick a real project or bug. Clearly state the baseline problem, the debugging steps you initiated, how you eliminated hypotheses, and the verified fix.",
    sampleAnswer: "(Situation): During our final year capstone project, our real-time collaboration whiteboard began experiencing random 3-second UI freezes whenever more than 15 users drew simultaneously.\n(Task): As the lead backend developer, I needed to identify the root cause and ensure 60 FPS smooth rendering under peak concurrent load.\n(Action): I profiled network packets and discovered our frontend was emitting un-throttled mouse-move WebSocket events at 120Hz per client, overwhelming the single-threaded Node.js event loop. I implemented client-side debouncing with requestAnimationFrame and redesigned the backend message broker to batch coordinate deltas using a Redis Pub/Sub buffer.\n(Result): WebSocket event volume dropped by 78%, server CPU utilization lowered from 94% to 28%, and the app maintained seamless sub-50ms latency with up to 100 concurrent collaborators.",
    redFlags: [
      "Claiming you've never faced a tough challenge or that everything is easy.",
      "Blaming teammates or third-party libraries without taking ownership.",
      "Not explaining how you verified that the bug was actually fixed."
    ]
  },
  {
    id: "hr-3",
    category: "Weakness & Failure",
    question: "What is your greatest weakness?",
    interviewerIntent: "Checking genuine self-awareness, vulnerability, honesty, and whether you take proactive steps toward continuous self-improvement.",
    idealStrategy: "Mention a real, non-fatal professional weakness, explain the exact system or habit you developed to counter it, and share evidence of progress.",
    sampleAnswer: "Early in my projects, I used to struggle with taking on too many tasks simultaneously and hesitating to ask for clarification early, fearing it might make me look inexperienced. During my internship, this led to me spending nearly two full days trying to reverse-engineer an internal API before realizing the team had updated documentation in a different repository. After that experience, I instituted the '30-minute rule': if I'm stuck on an undocumented blocker for more than 30 minutes, I formulate a clear summary of what I've tried, what hypotheses I tested, and reach out to a senior peer or mentor. This has helped me preserve velocity and become a far more communicative teammate.",
    redFlags: [
      "Giving a disguised cliché: 'I work too hard' or 'I am a perfectionist'.",
      "Listing a core job requirement: 'I don't really like writing code' or 'I miss deadlines'.",
      "Mentioning a weakness without explaining your active remediation process."
    ]
  },
  {
    id: "hr-4",
    category: "Teamwork & Conflict",
    question: "Tell me about a time you had a disagreement with a team member or manager. How did you resolve it?",
    interviewerIntent: "Evaluating emotional intelligence (EQ), constructive conflict resolution, active listening, and commitment to project success over ego.",
    idealStrategy: "Choose a disagreement over technical architecture or priorities—NOT a personal feud. Show how you focused on objective data, benchmarks, or user impact.",
    sampleAnswer: "(Situation): During a 48-hour hackathon, my teammate and I disagreed on whether to use GraphQL or standard REST endpoints for our mobile-first healthcare app.\n(Task): We had strict deadlines and could not afford to waste hours in architectural debate.\n(Action): Instead of arguing subjective preferences, I suggested we spend 30 minutes writing down the criteria that mattered most to our demo: development speed, payload size over 3G cellular, and ease of caching. We ran a quick Postman benchmark comparing payload responses. The benchmark showed that GraphQL reduced cellular mobile payload by 65% for our nested patient records. Acknowledging the clear data, we agreed on GraphQL, and I volunteered to set up Apollo Client to speed up his frontend integration.\n(Result): We completed our project 4 hours ahead of the deadline and won the Best UX award.",
    redFlags: [
      "Saying 'I've never had a disagreement with anyone'.",
      "Saying 'I proved I was right and forced them to do it my way'.",
      "Displaying lingering resentment or passive-aggressive behavior."
    ]
  },
  {
    id: "hr-5",
    category: "Culture Fit",
    question: "Why do you want to join our company specifically?",
    interviewerIntent: "Assessing whether you did research, care about their mission and engineering culture, or are just mass-applying to any job.",
    idealStrategy: "Mention specific recent products, engineering blog posts, open source contributions, or company culture values that resonate with your goals.",
    sampleAnswer: "Three things make your engineering team stand out to me. First, reading your tech blog on how your team migrated from monolith to event-driven microservices handling 50k RPS gave me enormous respect for your engineering standards. Second, your commitment to developer autonomy and continuous deployment means new engineers push production code in their first week. Third, your core mission of democratizing accessible financial tools aligns directly with my goal of building high-impact software that touches millions of users daily.",
    redFlags: [
      "Focusing solely on perks, salary, or free snacks.",
      "Giving generic praise that could apply to any company.",
      "Not knowing what products the company actually builds."
    ]
  },
  {
    id: "hr-6",
    category: "Future & Goals",
    question: "Where do you see yourself in 3 to 5 years?",
    interviewerIntent: "Checking career ambition, realistic expectations, learning mindset, and whether you plan to stay long enough for them to recoup training costs.",
    idealStrategy: "Focus on mastery of the software craft, taking on end-to-end feature ownership, mentoring junior engineers, and deepening system architecture expertise.",
    sampleAnswer: "In the next 3 to 5 years, my goal is to evolve from an executing engineer into a high-ownership technical leader who can independently architect complex distributed services. In the first year, I want to master your codebase, release reliable features, and earn team trust. Over years 2 and 3, I aim to lead critical system designs, optimize performance bottlenecks, and actively mentor incoming interns and junior developers, contributing to both the product and our engineering culture.",
    redFlags: [
      "Saying 'I want to be the CEO / have your job'.",
      "Saying 'I plan to leave after a year to do MBA / my own startup'.",
      "Displaying no ambition: 'Just doing the same thing'."
    ]
  }
];
