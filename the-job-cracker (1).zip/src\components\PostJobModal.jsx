import React, { useState } from 'react';
import { X, PlusCircle, Building2, MapPin, DollarSign, Calendar, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const PostJobModal = ({ onClose }) => {
  const { addCustomJob } = useApp();
  const [jobData, setJobData] = useState({
    title: '',
    company: '',
    location: 'Bengaluru, India',
    mode: 'Hybrid',
    type: 'Full-time',
    experience: '0 - 2 Years',
    batch: '2025 / 2026',
    salary: '₹14 - ₹24 LPA',
    salaryMin: 14,
    salaryMax: 24,
    skills: 'Java, Spring Boot, React, SQL',
    description: '',
    applyUrl: 'https://careers.example.com'
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const skillsArray = jobData.skills.split(',').map((s) => s.trim()).filter(Boolean);
    addCustomJob({
      ...jobData,
      skills: skillsArray,
      companyBadge: 'Recruiter Verified',
      logo: 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=128&auto=format&fit=crop&q=80',
      responsibilities: [
        'Build scalable microservices and client-facing web modules.',
        'Collaborate with agile cross-functional product squads.',
        'Write automated unit and integration tests.'
      ],
      requirements: [
        'Bachelor’s or Master’s in Computer Science or related degree.',
        'Good grasp of algorithms, data structures, and object-oriented design.',
        'Strong verbal and written communication.'
      ],
      interviewRounds: [
        'Round 1: Online Coding Assessment',
        'Round 2: Technical Interview (DSA + Project Discussion)',
        'Round 3: Hiring Manager & HR Round'
      ],
      benefits: ['Health Insurance', 'Flexible hours', 'Learning stipend']
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/50">
          <div className="flex items-center gap-2">
            <PlusCircle className="w-5 h-5 text-indigo-400" />
            <h3 className="font-bold text-white text-base">Post a New Job Opening</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Job Title *</label>
              <input
                type="text"
                required
                placeholder="e.g. SDE 1 / Full Stack Engineer"
                value={jobData.title}
                onChange={(e) => setJobData({ ...jobData, title: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Company Name *</label>
              <input
                type="text"
                required
                placeholder="e.g. Uber / Swiggy / InMobi"
                value={jobData.company}
                onChange={(e) => setJobData({ ...jobData, company: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Work Mode</label>
              <select
                value={jobData.mode}
                onChange={(e) => setJobData({ ...jobData, mode: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="Remote">Remote</option>
                <option value="Hybrid">Hybrid</option>
                <option value="Onsite">Onsite</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Job Type</label>
              <select
                value={jobData.type}
                onChange={(e) => setJobData({ ...jobData, type: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="Full-time">Full-time</option>
                <option value="Internship">Internship</option>
                <option value="Contract">Contract</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Location</label>
              <input
                type="text"
                value={jobData.location}
                onChange={(e) => setJobData({ ...jobData, location: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Salary / CTC</label>
              <input
                type="text"
                value={jobData.salary}
                onChange={(e) => setJobData({ ...jobData, salary: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Experience</label>
              <input
                type="text"
                value={jobData.experience}
                onChange={(e) => setJobData({ ...jobData, experience: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Eligible Batch</label>
              <input
                type="text"
                value={jobData.batch}
                onChange={(e) => setJobData({ ...jobData, batch: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Required Skills (comma separated)
            </label>
            <input
              type="text"
              value={jobData.skills}
              onChange={(e) => setJobData({ ...jobData, skills: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Job Description & Role Summary *
            </label>
            <textarea
              required
              rows={3}
              placeholder="Describe the role responsibilities, tech stack, and what the candidate will be building..."
              value={jobData.description}
              onChange={(e) => setJobData({ ...jobData, description: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 resize-none"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-medium text-slate-400 hover:text-white hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/30 transition-all hover:scale-[1.02]"
            >
              Publish Job Listing
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
