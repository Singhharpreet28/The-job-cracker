import React, { useState, useMemo } from 'react';
import { 
  Code2, 
  Search, 
  CheckCircle2, 
  Star, 
  ExternalLink, 
  BookOpen, 
  Filter, 
  Sparkles, 
  FileText, 
  Check, 
  RotateCcw,
  Building,
  Clock,
  Database
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { dsaProblems, dsaTopics } from '../data/dsaSheetsData';
import { SolutionModal } from '../components/SolutionModal';
import { DsaNotesModal } from '../components/DsaNotesModal';

export const DsaSheetPage = () => {
  const { 
    solvedDsa, 
    starredDsa, 
    toggleSolvedDsa, 
    toggleStarredDsa, 
    dsaNotes,
    totalDsaCount,
    solvedDsaCount,
    dsaProgressPct 
  } = useApp();

  const [selectedTopic, setSelectedTopic] = useState('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all'); // all, solved, unsolved, starred
  const [searchQuery, setSearchQuery] = useState('');
  
  // Modals
  const [activeSolutionProblem, setActiveSolutionProblem] = useState(null);
  const [activeNotesProblem, setActiveNotesProblem] = useState(null);

  // Filtered problems
  const filteredProblems = useMemo(() => {
    return dsaProblems.filter((p) => {
      // Topic filter
      if (selectedTopic !== 'all' && p.topic !== selectedTopic) {
        return false;
      }
      // Difficulty filter
      if (selectedDifficulty !== 'all' && p.difficulty !== selectedDifficulty) {
        return false;
      }
      // Status filter
      if (statusFilter === 'solved' && !solvedDsa.includes(p.id)) {
        return false;
      }
      if (statusFilter === 'unsolved' && solvedDsa.includes(p.id)) {
        return false;
      }
      if (statusFilter === 'starred' && !starredDsa.includes(p.id)) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = p.title.toLowerCase().includes(query);
        const matchesCompany = p.companies?.some((c) => c.toLowerCase().includes(query));
        const matchesSubTopic = p.subTopic?.toLowerCase().includes(query);
        if (!matchesTitle && !matchesCompany && !matchesSubTopic) {
          return false;
        }
      }
      return true;
    });
  }, [selectedTopic, selectedDifficulty, statusFilter, searchQuery, solvedDsa, starredDsa]);

  const difficultyColors = {
    Easy: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    Medium: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    Hard: 'bg-rose-500/10 text-rose-400 border-rose-500/20'
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Top Banner & Overall Progress */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 p-6 sm:p-8 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5" /> High-Yield Tech Interview Curriculum
            </div>
            <h1 className="text-3xl font-extrabold text-white">
              Dedicated Topic-Wise DSA Preparation Sheet
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl leading-relaxed">
              Curated LeetCode & GFG interview problems organized topic-by-topic. Mark completed, pin for revision, view C++/Java/Python/JS solutions, and track your interview preparedness.
            </p>
          </div>

          {/* Big Progress Card */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-5 min-w-[260px] space-y-3 shrink-0">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Overall Progress</span>
              <span className="text-sm font-extrabold text-emerald-400">{dsaProgressPct}%</span>
            </div>
            <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden">
              <div 
                className="bg-gradient-to-r from-indigo-500 to-emerald-400 h-full rounded-full transition-all duration-500" 
                style={{ width: `${dsaProgressPct}%` }}
              ></div>
            </div>
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Solved: <strong className="text-white">{solvedDsaCount}</strong> / {totalDsaCount}</span>
              <span>Starred: <strong className="text-amber-400">{starredDsa.length}</strong></span>
            </div>
          </div>
        </div>

        {/* Topic Pill Selector */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 pt-1 border-t border-slate-800/80">
          {dsaTopics.map((topic) => {
            const isSelected = selectedTopic === topic.id;
            // calculate topic solved count
            const topicProblems = topic.id === 'all' 
              ? dsaProblems 
              : dsaProblems.filter((p) => p.topic === topic.id);
            const topicSolved = topicProblems.filter((p) => solvedDsa.includes(p.id)).length;

            return (
              <button
                key={topic.id}
                onClick={() => setSelectedTopic(topic.id)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all flex items-center gap-2 ${
                  isSelected
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                    : 'bg-slate-950/70 border border-slate-800 text-slate-300 hover:border-slate-700 hover:text-white'
                }`}
              >
                <span>{topic.name}</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                  isSelected ? 'bg-indigo-800 text-indigo-100' : 'bg-slate-800 text-slate-400'
                }`}>
                  {topicSolved}/{topicProblems.length}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search problems, topics or companies (e.g. Google)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>

        {/* Difficulty and Status Filters */}
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          
          {/* Difficulty */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-xl p-1 text-xs">
            {['all', 'Easy', 'Medium', 'Hard'].map((diff) => (
              <button
                key={diff}
                onClick={() => setSelectedDifficulty(diff)}
                className={`px-3 py-1 rounded-lg font-medium transition-colors ${
                  selectedDifficulty === diff
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {diff === 'all' ? 'All Difficulties' : diff}
              </button>
            ))}
          </div>

          {/* Status */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-xl p-1 text-xs">
            {[
              { id: 'all', label: 'All' },
              { id: 'solved', label: 'Solved' },
              { id: 'unsolved', label: 'Unsolved' },
              { id: 'starred', label: 'Starred' }
            ].map((st) => (
              <button
                key={st.id}
                onClick={() => setStatusFilter(st.id)}
                className={`px-3 py-1 rounded-lg font-medium transition-colors ${
                  statusFilter === st.id
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>

        </div>
      </div>

      {/* Problems Table / List */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            
            {/* Table Header */}
            <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 uppercase font-semibold text-[11px] tracking-wider">
              <tr>
                <th className="py-3.5 px-4 w-12 text-center">Status</th>
                <th className="py-3.5 px-4 w-12 text-center">Star</th>
                <th className="py-3.5 px-4">Problem Name & Sub-topic</th>
                <th className="py-3.5 px-4 w-28">Difficulty</th>
                <th className="py-3.5 px-4 hidden lg:table-cell">Target Companies</th>
                <th className="py-3.5 px-4 w-32 text-center">Practice Link</th>
                <th className="py-3.5 px-4 w-36 text-center">Solution & Notes</th>
              </tr>
            </thead>

            {/* Table Body */}
            <tbody className="divide-y divide-slate-800/80">
              {filteredProblems.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-slate-500">
                    No matching problems found. Try adjusting your filters or search terms.
                  </td>
                </tr>
              ) : (
                filteredProblems.map((problem) => {
                  const isSolved = solvedDsa.includes(problem.id);
                  const isStarred = starredDsa.includes(problem.id);
                  const hasNote = Boolean(dsaNotes[problem.id]);

                  return (
                    <tr 
                      key={problem.id}
                      className={`hover:bg-slate-800/30 transition-colors ${
                        isSolved ? 'bg-emerald-950/10' : ''
                      }`}
                    >
                      {/* Checkbox */}
                      <td className="py-3.5 px-4 text-center">
                        <button
                          onClick={() => toggleSolvedDsa(problem.id)}
                          className={`w-6 h-6 rounded-lg border flex items-center justify-center transition-all ${
                            isSolved
                              ? 'bg-emerald-500 border-emerald-400 text-white'
                              : 'border-slate-700 bg-slate-950 hover:border-slate-500 text-transparent'
                          }`}
                          title={isSolved ? 'Mark as Unsolved' : 'Mark as Solved'}
                        >
                          <Check className="w-4 h-4 stroke-[3]" />
                        </button>
                      </td>

                      {/* Star Button */}
                      <td className="py-3.5 px-4 text-center">
                        <button
                          onClick={() => toggleStarredDsa(problem.id)}
                          className={`p-1.5 rounded-lg transition-colors ${
                            isStarred
                              ? 'text-amber-400 hover:text-amber-300'
                              : 'text-slate-600 hover:text-slate-400'
                          }`}
                          title={isStarred ? 'Unstar' : 'Star for Revision'}
                        >
                          <Star className={`w-4 h-4 ${isStarred ? 'fill-amber-400' : ''}`} />
                        </button>
                      </td>

                      {/* Title & Sub-Topic */}
                      <td className="py-3.5 px-4">
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2">
                            <span className={`font-semibold text-sm ${isSolved ? 'text-slate-400 line-through' : 'text-white'}`}>
                              {problem.title}
                            </span>
                            {problem.isMustDo && (
                              <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                                Must Do
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-400">
                            {problem.subTopic}
                          </div>
                        </div>
                      </td>

                      {/* Difficulty */}
                      <td className="py-3.5 px-4">
                        <span className={`text-[11px] font-semibold px-2.5 py-0.5 rounded-full border ${difficultyColors[problem.difficulty]}`}>
                          {problem.difficulty}
                        </span>
                      </td>

                      {/* Companies */}
                      <td className="py-3.5 px-4 hidden lg:table-cell">
                        <div className="flex flex-wrap gap-1 max-w-xs">
                          {problem.companies?.slice(0, 3).map((comp, idx) => (
                            <span key={idx} className="px-1.5 py-0.2 rounded bg-slate-800 text-[10px] text-slate-300 border border-slate-700">
                              {comp}
                            </span>
                          ))}
                          {problem.companies?.length > 3 && (
                            <span className="text-[10px] text-slate-500">+{problem.companies.length - 3}</span>
                          )}
                        </div>
                      </td>

                      {/* External Practice Links */}
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          {problem.leetcodeUrl && (
                            <a
                              href={problem.leetcodeUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-medium text-amber-300 hover:text-amber-200 border border-slate-700 transition-colors flex items-center gap-1"
                            >
                              LeetCode <ExternalLink className="w-3 h-3" />
                            </a>
                          )}
                        </div>
                      </td>

                      {/* Action Buttons: Solution & Notes */}
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => setActiveSolutionProblem(problem)}
                            className="px-2.5 py-1 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 border border-indigo-500/30 text-[11px] font-semibold transition-colors flex items-center gap-1"
                          >
                            <Code2 className="w-3 h-3" /> Solution
                          </button>

                          <button
                            onClick={() => setActiveNotesProblem(problem)}
                            className={`p-1.5 rounded-lg border transition-colors ${
                              hasNote
                                ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                                : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
                            }`}
                            title={hasNote ? 'View Notes (Note Added)' : 'Add Personal Note'}
                          >
                            <FileText className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>

                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modals */}
      {activeSolutionProblem && (
        <SolutionModal
          problem={activeSolutionProblem}
          onClose={() => setActiveSolutionProblem(null)}
        />
      )}

      {activeNotesProblem && (
        <DsaNotesModal
          problem={activeNotesProblem}
          onClose={() => setActiveNotesProblem(null)}
        />
      )}

    </div>
  );
};
