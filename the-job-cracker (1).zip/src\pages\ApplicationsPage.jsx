import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  CheckCircle2, 
  Clock, 
  Building2, 
  Briefcase, 
  Calendar, 
  Sparkles, 
  ArrowRight, 
  FileText, 
  Edit3, 
  Trophy, 
  XCircle,
  ExternalLink
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ApplicationsPage = () => {
  const { appliedJobs, updateApplicationStatus, triggerConfetti } = useApp();
  const [editingNotesId, setEditingNotesId] = useState(null);
  const [editedNote, setEditedNote] = useState('');

  const statusOptions = ['Applied', 'In Review', 'Interview Scheduled', 'Offer Received', 'Rejected'];

  const statusColors = {
    Applied: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    'In Review': 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    'Interview Scheduled': 'bg-purple-500/10 text-purple-400 border-purple-500/20',
    'Offer Received': 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    Rejected: 'bg-rose-500/10 text-rose-400 border-rose-500/20'
  };

  const handleStatusChange = (appId, newStatus) => {
    updateApplicationStatus(appId, newStatus);
    if (newStatus === 'Offer Received') {
      triggerConfetti();
    }
  };

  const handleStartEditNote = (app) => {
    setEditingNotesId(app.id);
    setEditedNote(app.notes || '');
  };

  const handleSaveNote = (appId) => {
    // update in context
    const updated = appliedJobs.map((a) => (a.id === appId ? { ...a, notes: editedNote } : a));
    try {
      localStorage.setItem('careerforge_applied_jobs', JSON.stringify(updated));
      window.location.reload(); // sync reload
    } catch (e) {
      console.error(e);
    }
    setEditingNotesId(null);
  };

  const offerCount = appliedJobs.filter((a) => a.status === 'Offer Received').length;
  const interviewCount = appliedJobs.filter((a) => a.status === 'Interview Scheduled').length;
  const inReviewCount = appliedJobs.filter((a) => a.status === 'In Review').length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Top Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 p-6 sm:p-8 space-y-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
            <CheckCircle2 className="w-3.5 h-3.5" /> Personal Placement Tracker
          </div>
          <h1 className="text-3xl font-extrabold text-white">
            Job Applications & Pipeline Tracker
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 max-w-2xl leading-relaxed">
            Monitor the status of your applications, interview schedules, recruiter contacts, and offers all in one central workspace.
          </p>
        </div>

        {/* Pipeline Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-2">
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800">
            <span className="text-xs text-slate-400">Total Applied</span>
            <div className="text-2xl font-black text-white mt-0.5">{appliedJobs.length}</div>
          </div>
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800">
            <span className="text-xs text-amber-400">In Review</span>
            <div className="text-2xl font-black text-amber-400 mt-0.5">{inReviewCount}</div>
          </div>
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800">
            <span className="text-xs text-purple-400">Interviews Scheduled</span>
            <div className="text-2xl font-black text-purple-400 mt-0.5">{interviewCount}</div>
          </div>
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800">
            <span className="text-xs text-emerald-400">Offers Received</span>
            <div className="text-2xl font-black text-emerald-400 mt-0.5">{offerCount}</div>
          </div>
        </div>
      </div>

      {/* Applications List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white">Active Applications ({appliedJobs.length})</h2>
          <Link
            to="/jobs"
            className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
          >
            Find more jobs <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {appliedJobs.length === 0 ? (
          <div className="py-16 text-center rounded-2xl border border-slate-800 bg-slate-900/40 space-y-3">
            <Briefcase className="w-10 h-10 text-slate-600 mx-auto" />
            <h3 className="text-base font-bold text-slate-300">No applications tracked yet</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Browse the Job Portal and click "Quick Apply" on any position to track it here automatically!
            </p>
            <div className="pt-2">
              <Link
                to="/jobs"
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs inline-flex items-center gap-1.5"
              >
                Go to Job Portal
              </Link>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {appliedJobs.map((app) => (
              <div
                key={app.id}
                className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 hover:border-slate-700 transition-colors"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center font-bold text-indigo-400 text-lg shrink-0">
                      {app.company.charAt(0)}
                    </div>
                    <div>
                      <h3 className="font-bold text-white text-base">{app.title}</h3>
                      <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                        <span className="text-indigo-300 font-semibold">{app.company}</span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" /> Applied on: {app.appliedDate}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Status Dropdown */}
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-slate-500 font-medium hidden sm:inline">Status:</span>
                    <select
                      value={app.status}
                      onChange={(e) => handleStatusChange(app.id, e.target.value)}
                      className={`px-3 py-1.5 rounded-xl border text-xs font-semibold focus:outline-none transition-colors ${
                        statusColors[app.status] || 'bg-slate-800 text-slate-200 border-slate-700'
                      }`}
                    >
                      {statusOptions.map((st) => (
                        <option key={st} value={st} className="bg-slate-900 text-white font-normal">
                          {st}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Notes & Candidate Log */}
                <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/80 text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-400 flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-indigo-400" /> Application Log & Notes:
                    </span>
                    <button
                      onClick={() => handleStartEditNote(app)}
                      className="text-slate-400 hover:text-white flex items-center gap-1 font-medium"
                    >
                      <Edit3 className="w-3 h-3" /> Edit Note
                    </button>
                  </div>

                  {editingNotesId === app.id ? (
                    <div className="space-y-2 pt-1">
                      <textarea
                        rows={2}
                        value={editedNote}
                        onChange={(e) => setEditedNote(e.target.value)}
                        className="w-full p-2.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-indigo-500 resize-none font-sans"
                      />
                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => setEditingNotesId(null)}
                          className="px-2.5 py-1 rounded bg-slate-800 text-slate-400 hover:text-white"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={() => handleSaveNote(app.id)}
                          className="px-3 py-1 rounded bg-indigo-600 hover:bg-indigo-500 text-white font-semibold"
                        >
                          Save
                        </button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-slate-300 leading-relaxed font-sans">
                      {app.notes || 'No custom notes logged yet.'}
                    </p>
                  )}
                </div>

              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
