export const technicalSubjects = [
  {
    id: "dbms",
    name: "Database Management Systems (DBMS)",
    badge: "Core CS",
    color: "from-blue-600 to-cyan-500",
    overview: "Covers Relational DB internals, ACID compliance, Normalization, Indexing structures, Transactions, and SQL queries.",
    cheatSheet: [
      {
        title: "ACID Properties",
        content: `• Atomicity: Entire transaction completes or completely rolls back ('All or Nothing').
• Consistency: Database remains in a valid state before and after transaction according to constraints.
• Isolation: Concurrent transactions execute without interfering with one another (Read Uncommitted, Read Committed, Repeatable Read, Serializable).
• Durability: Once committed, updates are permanently saved in non-volatile storage even across crashes.`
      },
      {
        title: "Normalization Forms",
        content: `• 1NF: Atomic values only (no repeating groups or comma-separated lists in a column).
• 2NF: Must be in 1NF + No partial dependency (non-prime attributes must depend on entire primary key, not part of a composite key).
• 3NF: Must be in 2NF + No transitive dependency (non-prime attributes must not depend on other non-prime attributes).
• BCNF (Boyce-Codd NF): For every functional dependency X -> Y, X must strictly be a Super Key.`
      },
      {
        title: "Indexing & B+ Trees",
        content: `• Clustered Index: Determines physical order of data on disk. Only ONE clustered index per table (usually Primary Key).
• Non-Clustered Index: Maintains a separate logical index structure with pointers to the actual data rows.
• Why B+ Tree over Binary Search Tree?
  1. High fan-out reduces tree height and disk I/O operations drastically.
  2. Leaf nodes are linked via pointers, making sequential range scans O(K) instead of repeated tree traversals.`
      }
    ],
    topQuestions: [
      {
        q: "What is the difference between Clustered and Non-Clustered Index?",
        a: "A Clustered Index physically re-orders the actual data records on disk to match the index order (hence only one clustered index per table, usually the Primary Key). A Non-Clustered Index creates a separate auxiliary index structure that maps search keys to physical disk pointers/Row IDs. You can have multiple non-clustered indexes on a table."
      },
      {
        q: "Explain Transaction Isolation Levels and concurrency anomalies.",
        a: "From weakest to strongest:\n1. Read Uncommitted: Susceptible to Dirty Reads (reading uncommitted changes of another tx).\n2. Read Committed: Prevents Dirty Reads; susceptible to Non-Repeatable Reads (reading same row twice gives different values).\n3. Repeatable Read: Prevents Non-Repeatable Reads; can have Phantom Reads (re-running a range query yields new rows inserted by others).\n4. Serializable: Complete isolation; prevents all anomalies using two-phase locking or MVCC, but has lowest concurrency throughput."
      },
      {
        q: "Compare SQL vs NoSQL databases. When to use which?",
        a: "• SQL (PostgreSQL, MySQL): Relational, structured schema, strong ACID consistency, excels in complex joins and transactional business data (finance, inventory).\n• NoSQL (MongoDB, DynamoDB, Cassandra): Document/Key-Value/Columnar, flexible schema, horizontal scaling out of the box, excels in high-write velocity, unstructured payloads, real-time analytics, and microservices."
      }
    ]
  },
  {
    id: "os",
    name: "Operating Systems (OS)",
    badge: "Core CS",
    color: "from-amber-600 to-orange-500",
    overview: "Process management, CPU scheduling, Memory management, Paging, Virtual Memory, Concurrency, and Deadlocks.",
    cheatSheet: [
      {
        title: "Process vs Thread",
        content: `• Process: An executing instance of a program with its own dedicated address space (Code, Data, Heap, Stack). Heavyweight context switching.
• Thread: The smallest unit of CPU execution within a process ('Lightweight process'). Threads share Code, Data, and Heap of parent process, but each thread has its own Stack and Program Counter (PC).`
      },
      {
        title: "Deadlock Conditions (Coffman Conditions)",
        content: `A deadlock can occur if and only if all four conditions hold simultaneously:
1. Mutual Exclusion: At least one resource must be held in non-shareable mode.
2. Hold and Wait: A process holds at least one resource and waits to acquire additional resources held by others.
3. No Preemption: Resources cannot be forcibly seized; only released voluntarily.
4. Circular Wait: A closed loop chain of processes where each process waits for a resource held by the next.`
      },
      {
        title: "Virtual Memory & Thrashing",
        content: `• Virtual Memory: Memory management technique creating the illusion of a vast contiguous memory using secondary storage paging.
• Page Fault: Occurs when a program accesses a virtual memory page not currently mapped into physical RAM frames.
• Thrashing: Condition where CPU spends more time swapping pages in and out of disk than executing actual instructions, collapsing system throughput.`
      }
    ],
    topQuestions: [
      {
        q: "What is a Mutex vs Semaphore?",
        a: "• Mutex (Mutual Exclusion Object): A locking mechanism owned strictly by the thread that acquired it. Only one thread can enter the critical section. (Key owner unlocks it).\n• Semaphore: A signaling mechanism based on an integer counter. Can be Binary (0 or 1) or Counting (allowing up to N concurrent threads). Any thread can signal (V) or wait (P), allowing cooperative inter-thread coordination."
      },
      {
        q: "Explain CPU Scheduling algorithms and their trade-offs.",
        a: "• FCFS (First Come First Serve): Non-preemptive, simple, suffers from Convoy Effect where small processes wait behind heavy CPU-bound jobs.\n• SJF (Shortest Job First): Optimal average waiting time, but requires advance knowledge of CPU burst time; can cause starvation for longer jobs.\n• Round Robin (RR): Preemptive, assigns a fixed time quantum. Great for responsive interactive multitasking; performance hinges on time quantum size."
      }
    ]
  },
  {
    id: "cn",
    name: "Computer Networks (CN)",
    badge: "Core CS",
    color: "from-emerald-600 to-teal-500",
    overview: "OSI vs TCP/IP layer architectures, TCP 3-Way Handshake, DNS resolution, HTTP/HTTPS, SSL/TLS, and Sockets.",
    cheatSheet: [
      {
        title: "The 7 Layers of OSI Model",
        content: `1. Physical Layer: Raw bit stream transmission over physical medium (cables, radio waves).
2. Data Link Layer: Node-to-node framing, MAC addressing, error detection (Ethernet, Wi-Fi).
3. Network Layer: Host-to-host routing and logical addressing (IP, ICMP, Routers).
4. Transport Layer: End-to-end process communication, flow and congestion control (TCP, UDP).
5. Session Layer: Dialogue control and session management.
6. Presentation Layer: Data encryption, compression, and translation (SSL/TLS, JSON/XML).
7. Application Layer: User application protocols (HTTP, DNS, SMTP, FTP).`
      },
      {
        title: "TCP 3-Way Handshake & Teardown",
        content: `Handshake:
1. Client -> Server: SYN (Synchronize sequence number X).
2. Server -> Client: SYN-ACK (Acknowledge X+1, Synchronize server sequence number Y).
3. Client -> Server: ACK (Acknowledge Y+1). Connection is ESTABLISHED.
Teardown (4-Way):
FIN -> ACK -> FIN -> ACK (Client enters TIME_WAIT state before full close).`
      },
      {
        title: "What happens when you type google.com into your browser?",
        content: `1. Browser checks cache: Browser cache -> OS hosts file -> Local DNS resolver cache.
2. DNS Query: Resolves 'google.com' to IP via Root DNS -> TLD (.com) -> Authoritative Nameserver.
3. TCP Connection: Browser initiates 3-Way Handshake with the server IP on Port 443.
4. TLS Handshake: Negotiates cipher suite, verifies SSL certificate, generates symmetric session keys.
5. HTTP GET Request: Browser transmits encrypted HTTP request for index.html.
6. Server processes request through Load Balancer & Web Server, returns 200 OK HTML payload.
7. Browser renders DOM tree, CSSOM, downloads scripts/images, and executes JavaScript.`
      }
    ],
    topQuestions: [
      {
        q: "What is the difference between TCP and UDP?",
        a: "• TCP (Transmission Control Protocol): Connection-oriented (3-way handshake), reliable (guarantees packet delivery, ordering, and retransmission of lost packets), implements flow and congestion control. Used in HTTP/HTTPS, Email (SMTP), File transfer (FTP).\n• UDP (User Datagram Protocol): Connectionless, unreliable (no ACKs or retransmissions), minimal packet header overhead (8 bytes vs 20+ bytes), low latency. Used in live video streaming, VoIP, online gaming, and DNS."
      },
      {
        q: "Explain HTTP/1.1 vs HTTP/2 vs HTTP/3.",
        a: "• HTTP/1.1: Persistent connections, but suffers from Head-of-Line (HoL) blocking at application level (one response blocks subsequent requests on a single connection).\n• HTTP/2: Binary protocol, introduces multiplexing (multiple concurrent streams over one single TCP connection), header compression (HPACK), and server push.\n• HTTP/3: Replaces TCP with QUIC protocol over UDP, eliminating TCP-level Head-of-Line blocking and enabling 0-RTT connection migration."
      }
    ]
  },
  {
    id: "oops",
    name: "Object-Oriented Programming (OOPs)",
    badge: "Core CS",
    color: "from-purple-600 to-indigo-500",
    overview: "Encapsulation, Abstraction, Inheritance, Polymorphism, SOLID principles, and clean design patterns.",
    cheatSheet: [
      {
        title: "The 4 Core Pillars of OOP",
        content: `1. Encapsulation: Bundling data (attributes) and methods (behavior) together into a single unit (class), restricting direct access via private/protected access modifiers to prevent unauthorized state tampering.
2. Abstraction: Hiding internal complex implementation details and exposing only the essential interface to the user (e.g., Abstract Classes and Interfaces).
3. Inheritance: Mechanism where a child class inherits properties and behaviors from a parent class, promoting code reuse.
4. Polymorphism: Ability of an entity to take multiple forms.
   - Compile-Time: Method Overloading (same method name, different parameter signature).
   - Run-Time: Method Overriding (subclass provides specific implementation of a virtual method declared in superclass).`
      },
      {
        title: "SOLID Principles Breakdown",
        content: `• S - Single Responsibility: A class should have one, and only one, reason to change.
• O - Open/Closed: Software entities should be open for extension, but closed for modification.
• L - Liskov Substitution: Subclasses must be substitutable for their base classes without breaking program correctness.
• I - Interface Segregation: Clients should not be forced to depend on interfaces they do not use (prefer small, role-specific interfaces).
• D - Dependency Inversion: High-level modules should not depend on low-level modules; both should depend on abstractions.`
      }
    ],
    topQuestions: [
      {
        q: "What is the difference between Method Overloading and Method Overriding?",
        a: "• Method Overloading (Compile-Time / Static Polymorphism): Multiple methods in the same class share the identical name but have different parameter count, types, or order. Resolved at compile time.\n• Method Overriding (Run-Time / Dynamic Polymorphism): A subclass provides its own specific implementation of a method that is already defined in its parent class with the exact same signature. Resolved at runtime using virtual method tables (vtable)."
      },
      {
        q: "Explain the Singleton Pattern and how to prevent thread-safety issues.",
        a: "The Singleton pattern restricts the instantiation of a class to one single instance and provides a global access point. In multithreaded environments, race conditions can instantiate multiple instances. To prevent this, use Double-Checked Locking with a volatile instance variable, or Java's static inner class (Bill Pugh Singleton) which leverages JVM class-loader thread-safety without synchronization overhead."
      }
    ]
  },
  {
    id: "system-design",
    name: "System Design Essentials (HLD & LLD)",
    badge: "High Yield",
    color: "from-rose-600 to-pink-500",
    overview: "Load balancing, Caching, CAP theorem, Database Sharding, Message Queues, and Microservice patterns.",
    cheatSheet: [
      {
        title: "CAP Theorem",
        content: `In any distributed data store, you can guarantee at most TWO out of three properties simultaneously in the presence of network partitions:
• Consistency (C): Every read receives the most recent write or an error.
• Availability (A): Every non-failing node returns a non-error response, but without guarantee it contains the most recent write.
• Partition Tolerance (P): The system continues operating despite arbitrary dropped or delayed network messages between nodes.
Since network failures (Partitions) are inevitable in real-world networks, distributed systems must choose between CP (e.g., MongoDB, HBase) or AP (e.g., Cassandra, DynamoDB).`
      },
      {
        title: "Caching Strategies",
        content: `• Cache-Aside (Lazy Loading): Application queries cache; on cache miss, reads from DB and writes result to cache. Simple, resilient to cache crashes.
• Read-Through: Application queries cache directly; cache transparently reads from DB on miss.
• Write-Through: Application writes to cache; cache immediately writes synchronously to DB before returning. Strong consistency, higher write latency.
• Write-Back (Write-Behind): Application writes to cache; cache asynchronously batches writes to DB later. Ultra-fast writes, risk of data loss on power failure.`
      }
    ],
    topQuestions: [
      {
        q: "How would you design a URL Shortener like Bitly (High-Level)?",
        a: "Key components:\n1. API: POST /api/v1/shorten (accepts longUrl, returns 7-char hash); GET /{shortCode} (returns 301/302 redirect).\n2. Encoding: Base62 encoding (a-z, A-Z, 0-9) of a unique 64-bit auto-incrementing ID generated by a distributed ID generator (e.g., Twitter Snowflake). Base62 with 7 characters gives 62^7 ≈ 3.5 trillion unique URLs.\n3. Storage: Relational or Key-Value store mapping shortKey -> originalUrl.\n4. Caching: Redis cluster caching the top 20% most accessed URLs (80-20 Pareto principle) with LRU eviction.\n5. Scalability: Multiple stateless app servers behind an NGINX load balancer."
      },
      {
        q: "What is Database Sharding vs Replication?",
        a: "• Replication: Copying the entire database across multiple replica nodes (Master-Slave/Leader-Follower). Master handles writes, while read replicas distribute read traffic and provide high availability.\n• Sharding (Horizontal Partitioning): Splitting a massive table across multiple independent database machines based on a Shard Key (e.g., hash(userId) % num_shards). Solves write scalability and memory limits when data size exceeds single-node capacity."
      }
    ]
  }
];
