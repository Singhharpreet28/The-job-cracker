# The Job Cracker - Job Portal & Tech Interview Preparation Hub

A modern, comprehensive full-stack career platform engineered for software engineering students, fresh graduates, and experienced developers.

## 🚀 Key Modules & Capabilities

### 1. 💼 Tech Job Portal
- **Rich Job Listings**: Software Development Engineer (SDE 1/2), Frontend, Backend, Data Engineer, Cloud/DevOps, and College Internships across FAANG, Unicorns (Razorpay, Swiggy, Flipkart), and MNCs (TCS, Infosys).
- **Multi-dimensional Filtering**: Filter by Work Mode (Remote, Hybrid, Onsite), Job Type (Full-time, Internship), Experience Level (Freshers vs Experienced), and search by title, skills, or company.
- **Detailed Job Dossiers**: Full breakdown of responsibilities, requirements, CTC salary packages, eligible batches (2024/2025/2026), and hiring stages.
- **Quick-Apply Modal**: Instant resume attachment and profile submission with celebratory confetti and status tracking.
- **Post a Job Portal**: Recruiter / User job posting system with local persistence.
- **Saved Bookmarks**: Pin jobs for later review.

### 2. 🧩 Dedicated Topic-Wise DSA Preparation Sheet
- **Curated Problem Curriculum**: Inspired by Striver SDE Sheet, Love Babbar 450, and NeetCode 150.
- **Topics Covered**: Arrays, Strings, Two Pointers & Sliding Window, Binary Search, Linked List, Stacks & Queues, Trees & BST, Graphs, Dynamic Programming.
- **Multi-Language Solutions**: Every problem features intuition, Big-O Time & Space complexity analysis, and verified production code in **C++, Java, Python, and JavaScript** with 1-click copy.
- **Progress Tracking**: LocalStorage-persisted checkboxes, overall completion bar, topic-wise counts, and revision star flags.
- **In-Browser Notes**: Personal notes scratchpad per problem to save edge cases and review points.

### 3. 📚 Preparation Section (3 Complete Pillars)
- **Aptitude & Logical Reasoning**:
  - Quantitative Aptitude (Percentages, Profit & Loss, Speed-Distance-Time, Time & Work, Probability) formula cheat sheets.
  - Logical Reasoning (Blood Relations, Syllogisms, Direction Sense, Coding-Decoding).
  - Verbal Ability (Subject-Verb agreement, Parallelism, Idioms).
  - Interactive Timed Quizzes with timer countdown, instant scorecards, and step-by-step mathematical explanations.
- **Core Technical Computer Science**:
  - Deep-dive notes for DBMS (ACID, Normalization, B+ Trees, Indexing), Operating Systems (Processes, Threads, Coffman Deadlock conditions, Paging, Virtual Memory), Computer Networks (OSI layers, TCP 3-way handshake, DNS lifecycle, HTTP/2/3), OOPs (4 Pillars, SOLID Principles, Design Patterns), and System Design (CAP Theorem, Caching, Sharding).
  - High-yield interview questions with expandable answers.
- **HR & Behavioral Interview Prep**:
  - The STAR Framework (Situation, Task, Action, Result) breakdown.
  - Top 30 HR interview questions with interviewer evaluation intent, winning strategies, model STAR answers, and red flag warnings.
  - Interactive "Draft Your Personal Story" worksheet saved locally.

### 4. 🏢 Companies Hiring Process & Exam Blueprints
- In-depth profiles for 15+ premier companies: Google, Amazon, Microsoft, TCS, Infosys, Atlassian, Flipkart, Razorpay, etc.
- **Exam Pattern**: Section-by-section breakdown (Aptitude, Coding, Technical), duration, question count, negative marking, and testing platforms (HackerRank, Codility, TCS iON, HackerEarth).
- **Syllabus**: Exact topics tested in coding and aptitude.
- **Eligibility**: Cutoff CGPA/percentage, backlog policies, branch eligibility, and allowed education gaps.
- **Selection Process Timeline**: OA -> Tech Round 1 -> Tech Round 2 -> System Design / Bar Raiser -> HR.
- **Pro Tips**: Practical guidance from candidates who cleared the drives.

### 5. 📋 Application Pipeline Tracker
- Track applied jobs through all stages: `Applied` ➔ `In Review` ➔ `Interview Scheduled` ➔ `Offer Received` ➔ `Rejected`.
- Pipeline counters and custom recruiter notes log.

---

## 🛠️ Tech Stack
- **Frontend Framework**: React 18 with Vite
- **Styling**: Tailwind CSS with custom glassmorphism and modern dark tech theme
- **Icons**: Lucide React
- **Routing**: React Router DOM (v6)
- **State & Storage**: React Context API with LocalStorage persistence
- **Animation & FX**: Canvas Confetti

---

## 💻 Getting Started

```bash
# Navigate to project directory
cd "C:\Users\HARPREET\.gemini\antigravity\scratch\job-prep-portal"

# Start the local development server
npm run dev
```

Open `http://localhost:5173` in your browser.
