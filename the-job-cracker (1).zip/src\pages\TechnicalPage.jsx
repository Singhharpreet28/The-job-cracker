import React, { useState } from 'react';
import { 
  Terminal, 
  Database, 
  Cpu, 
  Globe, 
  Layers, 
  Sparkles, 
  CheckCircle2, 
  ChevronDown, 
  ChevronUp, 
  BookOpen, 
  Code2 
} from 'lucide-react';
import { technicalSubjects } from '../data/technicalData';

export const TechnicalPage = () => {
  const [selectedSubjectId, setSelectedSubjectId] = useState('dbms');
  const [expandedQuestions, setExpandedQuestions] = useState({});

  const subject = technicalSubjects.find((s) => s.id === selectedSubjectId) || technicalSubjects[0];

  const toggleQuestion = (idx) => {
    setExpandedQuestions((prev) => ({
      ...prev,
      [idx]: !prev[idx]
    }));
  };

  const icons = {
    dbms: Database,
    os: Cpu,
    cn: Globe,
    oops: Layers,
    'system-design': Code2
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Top Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-purple-950/40 to-slate-900 border border-slate-800 p-6 sm:p-8 space-y-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" /> High-Impact Core Engineering Concepts
          </div>
          <h1 className="text-3xl font-extrabold text-white">
            Core Technical Computer Science Revision
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 max-w-2xl leading-relaxed">
            Essential concepts tested in Technical Rounds across Google, Amazon, Microsoft, TCS Digital, and product startups. Master DBMS, Operating Systems, Computer Networks, OOPs, and System Design.
          </p>
        </div>

        {/* Subject Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-2 border-t border-slate-800">
          {technicalSubjects.map((sub) => {
            const Icon = icons[sub.id] || Terminal;
            const isSelected = selectedSubjectId === sub.id;
            return (
              <button
                key={sub.id}
                onClick={() => setSelectedSubjectId(sub.id)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-2.5 ${
                  isSelected
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                    : 'bg-slate-950/80 border border-slate-800 text-slate-300 hover:border-slate-700 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{sub.name.split(' (')[0]}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Subject Overview */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            {subject.name}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">{subject.overview}</p>
        </div>
        <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20">
          {subject.badge}
        </span>
      </div>

      {/* Cheat Sheets */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {subject.cheatSheet.map((item, index) => (
          <div
            key={index}
            className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 hover:border-slate-700 transition-colors flex flex-col justify-between"
          >
            <div>
              <h3 className="text-sm font-bold text-purple-300 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-purple-400"></span>
                {item.title}
              </h3>
              <pre className="mt-2 text-xs text-slate-300 font-sans whitespace-pre-wrap leading-relaxed">
                {item.content}
              </pre>
            </div>
            <div className="text-[10px] text-slate-500 font-mono uppercase tracking-wider pt-2 border-t border-slate-800">
              High-Frequency Concept
            </div>
          </div>
        ))}
      </div>

      {/* Top Interview Questions */}
      <div className="space-y-4 pt-4">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-purple-400" />
          Frequently Asked Interview Questions & Deep Dives
        </h2>

        <div className="space-y-4">
          {subject.topQuestions.map((qa, index) => {
            const isExpanded = Boolean(expandedQuestions[index]);
            return (
              <div
                key={index}
                className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3"
              >
                <div
                  onClick={() => toggleQuestion(index)}
                  className="flex items-start justify-between gap-4 cursor-pointer"
                >
                  <h3 className="text-sm font-semibold text-white leading-relaxed flex items-start gap-2.5">
                    <span className="text-purple-400 font-bold text-xs mt-0.5">Q{index + 1}.</span>
                    <span>{qa.q}</span>
                  </h3>
                  <button className="p-1 rounded-lg text-slate-400 hover:text-white shrink-0">
                    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </button>
                </div>

                {isExpanded && (
                  <div className="pt-3 border-t border-slate-800 text-xs text-slate-300 leading-relaxed font-sans whitespace-pre-wrap bg-slate-950/70 p-4 rounded-xl border border-slate-800/80 animate-in fade-in duration-150">
                    <strong className="text-purple-300 font-semibold block mb-1">Model Answer:</strong>
                    {qa.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
