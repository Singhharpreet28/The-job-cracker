import React from 'react';

export const CompanyLogosBackground = () => {
  const logosRow1 = [
    { name: 'Google', symbol: 'G', tag: 'Big Tech' },
    { name: 'Amazon', symbol: 'a', tag: 'FAANG' },
    { name: 'Microsoft', symbol: '⊞', tag: 'Big Tech' },
    { name: 'Meta', symbol: '∞', tag: 'FAANG' },
    { name: 'Apple', symbol: '', svg: 'apple', tag: 'FAANG' },
    { name: 'Netflix', symbol: 'N', tag: 'FAANG' },
    { name: 'Uber', symbol: 'U', tag: 'Mobility' },
    { name: 'Atlassian', symbol: '▲', tag: 'SaaS' },
    { name: 'Adobe', symbol: 'A', tag: 'Creative' },
    { name: 'NVIDIA', symbol: 'NV', tag: 'AI & Chips' },
    { name: 'Flipkart', symbol: 'F', tag: 'E-Comm' },
    { name: 'Razorpay', symbol: 'R', tag: 'FinTech' }
  ];

  const logosRow2 = [
    { name: 'TCS', symbol: 'TCS', tag: 'Titan' },
    { name: 'Infosys', symbol: 'INFY', tag: 'Titan' },
    { name: 'Goldman Sachs', symbol: 'GS', tag: 'FinTech' },
    { name: 'Morgan Stanley', symbol: 'MS', tag: 'FinTech' },
    { name: 'Wipro', symbol: 'W', tag: 'MNC' },
    { name: 'Cognizant', symbol: 'CTS', tag: 'MNC' },
    { name: 'Swiggy', symbol: 'S', tag: 'Unicorn' },
    { name: 'Zomato', symbol: 'Z', tag: 'Tech' },
    { name: 'Accenture', symbol: '>', tag: 'Titan' },
    { name: 'Salesforce', symbol: '☁', tag: 'Cloud' },
    { name: 'Spotify', symbol: '≈', tag: 'Streaming' },
    { name: 'GitHub', symbol: '⌥', tag: 'Dev Tools' }
  ];

  const logosRow3 = [
    { name: 'Oracle', symbol: 'O', tag: 'Database' },
    { name: 'Cisco', symbol: '|||', tag: 'Networks' },
    { name: 'Intuit', symbol: 'int', tag: 'FinTech' },
    { name: 'Paytm', symbol: '₹', tag: 'FinTech' },
    { name: 'InMobi', symbol: 'im', tag: 'AdTech' },
    { name: 'PhonePe', symbol: 'पे', tag: 'FinTech' },
    { name: 'Samsung', symbol: 'S', tag: 'Tech' },
    { name: 'Intel', symbol: 'i', tag: 'Hardware' },
    { name: 'AMD', symbol: 'AMD', tag: 'Semicon' },
    { name: 'Twitter / X', symbol: '𝕏', tag: 'Social' },
    { name: 'LinkedIn', symbol: 'in', tag: 'Network' },
    { name: 'Qualcomm', symbol: 'Q', tag: '5G Tech' }
  ];

  return (
    <div 
      aria-hidden="true" 
      className="fixed inset-0 pointer-events-none select-none overflow-hidden z-0"
    >
      {/* Ambient Lighting Orbs */}
      <div className="absolute top-10 left-1/4 w-[32rem] h-[32rem] bg-indigo-600/[0.04] rounded-full blur-3xl"></div>
      <div className="absolute top-1/2 right-10 w-[28rem] h-[28rem] bg-emerald-500/[0.03] rounded-full blur-3xl"></div>
      <div className="absolute bottom-10 left-10 w-[30rem] h-[30rem] bg-purple-600/[0.03] rounded-full blur-3xl"></div>

      {/* Watermark Diagonal Ambient Grid of Tech Logos */}
      <div className="absolute -inset-10 flex flex-col justify-around rotate-[-6deg] opacity-[0.038] dark:opacity-[0.032] scale-110">
        
        {/* Row 1 - Sliding Right */}
        <div className="flex gap-8 whitespace-nowrap animate-marquee-slow">
          {[...logosRow1, ...logosRow1].map((logo, index) => (
            <div
              key={`r1-${index}`}
              className="flex items-center gap-3 px-6 py-3.5 rounded-2xl border border-current font-mono text-sm tracking-wider uppercase shrink-0"
            >
              <div className="w-8 h-8 rounded-xl border border-current flex items-center justify-center font-black text-xs">
                {logo.symbol}
              </div>
              <div className="flex flex-col text-left">
                <span className="font-extrabold text-sm tracking-tight">{logo.name}</span>
                <span className="text-[9px] opacity-75">{logo.tag}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Row 2 - Sliding Left (Reverse) */}
        <div className="flex gap-8 whitespace-nowrap animate-marquee-reverse">
          {[...logosRow2, ...logosRow2].map((logo, index) => (
            <div
              key={`r2-${index}`}
              className="flex items-center gap-3 px-6 py-3.5 rounded-2xl border border-current font-mono text-sm tracking-wider uppercase shrink-0"
            >
              <div className="w-8 h-8 rounded-xl border border-current flex items-center justify-center font-black text-xs">
                {logo.symbol}
              </div>
              <div className="flex flex-col text-left">
                <span className="font-extrabold text-sm tracking-tight">{logo.name}</span>
                <span className="text-[9px] opacity-75">{logo.tag}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Row 3 - Sliding Right */}
        <div className="flex gap-8 whitespace-nowrap animate-marquee-slow">
          {[...logosRow3, ...logosRow3].map((logo, index) => (
            <div
              key={`r3-${index}`}
              className="flex items-center gap-3 px-6 py-3.5 rounded-2xl border border-current font-mono text-sm tracking-wider uppercase shrink-0"
            >
              <div className="w-8 h-8 rounded-xl border border-current flex items-center justify-center font-black text-xs">
                {logo.symbol}
              </div>
              <div className="flex flex-col text-left">
                <span className="font-extrabold text-sm tracking-tight">{logo.name}</span>
                <span className="text-[9px] opacity-75">{logo.tag}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Row 4 - Duplicate for Full Vertical Screen Coverage */}
        <div className="flex gap-8 whitespace-nowrap animate-marquee-reverse">
          {[...logosRow1, ...logosRow2].map((logo, index) => (
            <div
              key={`r4-${index}`}
              className="flex items-center gap-3 px-6 py-3.5 rounded-2xl border border-current font-mono text-sm tracking-wider uppercase shrink-0"
            >
              <div className="w-8 h-8 rounded-xl border border-current flex items-center justify-center font-black text-xs">
                {logo.symbol}
              </div>
              <div className="flex flex-col text-left">
                <span className="font-extrabold text-sm tracking-tight">{logo.name}</span>
                <span className="text-[9px] opacity-75">{logo.tag}</span>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Subtle Vignette / Edge Fade so background gently fades at borders */}
      <div className="absolute inset-0 bg-radial-gradient pointer-events-none"></div>
    </div>
  );
};
