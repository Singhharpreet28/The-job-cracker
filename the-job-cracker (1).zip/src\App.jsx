import React, { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { JobsPage } from './pages/JobsPage';
import { DsaSheetPage } from './pages/DsaSheetPage';
import { AptitudePage } from './pages/AptitudePage';
import { TechnicalPage } from './pages/TechnicalPage';
import { HrPrepPage } from './pages/HrPrepPage';
import { CompaniesPage } from './pages/CompaniesPage';
import { ApplicationsPage } from './pages/ApplicationsPage';
import { JobDetailModal } from './components/JobDetailModal';
import { ApplyModal } from './components/ApplyModal';
import { PostJobModal } from './components/PostJobModal';
import { ThemeSideToggle } from './components/ThemeSideToggle';
import { CompanyLogosBackground } from './components/CompanyLogosBackground';

export const App = () => {
  const [selectedJobForDetail, setSelectedJobForDetail] = useState(null);
  const [selectedJobForApply, setSelectedJobForApply] = useState(null);
  const [isPostJobOpen, setIsPostJobOpen] = useState(false);

  return (
    <div className="flex flex-col min-h-screen bg-slate-950 text-slate-100 antialiased selection:bg-indigo-600 selection:text-white relative">
      {/* Ambient Tech Company Logos in Background */}
      <CompanyLogosBackground />

      {/* Side Theme Toggle */}
      <ThemeSideToggle />

      {/* Navigation & App Content (Z-indexed above background) */}
      <div className="relative z-10 flex flex-col min-h-screen">
        <Navbar onOpenPostJob={() => setIsPostJobOpen(true)} />

        {/* Main Content */}
        <main className="flex-1">
        <Routes>
          <Route 
            path="/" 
            element={
              <HomePage 
                onSelectJob={(j) => setSelectedJobForDetail(j)}
                onApplyJob={(j) => setSelectedJobForApply(j)}
              />
            } 
          />
          <Route path="/jobs" element={<JobsPage />} />
          <Route path="/dsa-sheet" element={<DsaSheetPage />} />
          <Route path="/prep/aptitude" element={<AptitudePage />} />
          <Route path="/prep/technical" element={<TechnicalPage />} />
          <Route path="/prep/hr" element={<HrPrepPage />} />
          <Route path="/companies" element={<CompaniesPage />} />
          <Route path="/applications" element={<ApplicationsPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>

        {/* Footer */}
        <Footer />
      </div>

      {/* Global Modals for Home & Cross-Page CTAs */}
      {selectedJobForDetail && (
        <JobDetailModal
          job={selectedJobForDetail}
          onClose={() => setSelectedJobForDetail(null)}
          onApply={(j) => setSelectedJobForApply(j)}
        />
      )}

      {selectedJobForApply && (
        <ApplyModal
          job={selectedJobForApply}
          onClose={() => setSelectedJobForApply(null)}
        />
      )}

      {isPostJobOpen && (
        <PostJobModal
          onClose={() => setIsPostJobOpen(false)}
        />
      )}
    </div>
  );
};

export default App;
