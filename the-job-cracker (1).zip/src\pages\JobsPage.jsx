import React, { useState, useMemo } from 'react';
import { 
  Briefcase, 
  Search, 
  MapPin, 
  Filter, 
  PlusCircle, 
  Bookmark, 
  Sparkles, 
  CheckCircle2, 
  X,
  SlidersHorizontal
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { JobCard } from '../components/JobCard';
import { JobDetailModal } from '../components/JobDetailModal';
import { ApplyModal } from '../components/ApplyModal';
import { PostJobModal } from '../components/PostJobModal';

export const JobsPage = () => {
  const { jobs, savedJobs } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMode, setSelectedMode] = useState('All'); // All, Remote, Hybrid, Onsite
  const [selectedType, setSelectedType] = useState('All'); // All, Full-time, Internship
  const [selectedExp, setSelectedExp] = useState('All');
  const [showSavedOnly, setShowSavedOnly] = useState(false);
  const [selectedJobForDetail, setSelectedJobForDetail] = useState(null);
  const [selectedJobForApply, setSelectedJobForApply] = useState(null);
  const [isPostJobOpen, setIsPostJobOpen] = useState(false);

  const filteredJobs = useMemo(() => {
    return jobs.filter((job) => {
      // Saved filter
      if (showSavedOnly && !savedJobs.includes(job.id)) {
        return false;
      }
      // Mode filter
      if (selectedMode !== 'All' && job.mode !== selectedMode) {
        return false;
      }
      // Type filter
      if (selectedType !== 'All' && job.type !== selectedType) {
        return false;
      }
      // Experience filter
      if (selectedExp !== 'All') {
        if (selectedExp === 'Fresher' && !job.experience.includes('0')) return false;
        if (selectedExp === 'Experienced' && job.experience.includes('0 Years')) return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = job.title.toLowerCase().includes(q);
        const matchesCompany = job.company.toLowerCase().includes(q);
        const matchesSkills = job.skills?.some((s) => s.toLowerCase().includes(q));
        const matchesLoc = job.location.toLowerCase().includes(q);
        if (!matchesTitle && !matchesCompany && !matchesSkills && !matchesLoc) {
          return false;
        }
      }
      return true;
    });
  }, [jobs, savedJobs, showSavedOnly, selectedMode, selectedType, selectedExp, searchQuery]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Top Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 p-6 sm:p-8 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5" /> High-Paying Engineering & Tech Roles
            </div>
            <h1 className="text-3xl font-extrabold text-white">
              Tech Job Portal & Verified Openings
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl leading-relaxed">
              Curated full-time software engineering roles, summer internships, and remote opportunities across FAANG, Unicorns, and MNCs for 2024, 2025, and 2026 batches.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setIsPostJobOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-semibold text-xs shadow-md shadow-indigo-600/30 flex items-center gap-2 transition-all hover:scale-[1.02]"
            >
              <PlusCircle className="w-4 h-4" /> Post an Opportunity
            </button>
          </div>
        </div>

        {/* Search & Main Filter Bar */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 pt-2">
          
          {/* Keyword Search */}
          <div className="md:col-span-5 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by title, skill (e.g. React, Java), or company..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Work Mode */}
          <div className="md:col-span-2">
            <select
              value={selectedMode}
              onChange={(e) => setSelectedMode(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="All">All Modes</option>
              <option value="Remote">Remote</option>
              <option value="Hybrid">Hybrid</option>
              <option value="Onsite">Onsite</option>
            </select>
          </div>

          {/* Job Type */}
          <div className="md:col-span-2">
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="All">All Types</option>
              <option value="Full-time">Full-time</option>
              <option value="Internship">Internship</option>
            </select>
          </div>

          {/* Experience Filter */}
          <div className="md:col-span-2">
            <select
              value={selectedExp}
              onChange={(e) => setSelectedExp(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="All">All Experience</option>
              <option value="Fresher">Freshers (0 - 1 Yrs)</option>
              <option value="Experienced">Experienced (1+ Yrs)</option>
            </select>
          </div>

          {/* Saved Toggle Button */}
          <div className="md:col-span-1">
            <button
              onClick={() => setShowSavedOnly(!showSavedOnly)}
              className={`w-full h-full py-2.5 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center transition-colors ${
                showSavedOnly
                  ? 'bg-indigo-600 border-indigo-500 text-white shadow-sm'
                  : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
              }`}
              title="Show Saved Only"
            >
              <Bookmark className={`w-4 h-4 ${showSavedOnly ? 'fill-white' : ''}`} />
            </button>
          </div>

        </div>
      </div>

      {/* Results Header */}
      <div className="flex items-center justify-between text-xs text-slate-400">
        <div>
          Showing <strong className="text-white">{filteredJobs.length}</strong> openings {showSavedOnly && '(Saved Only)'}
        </div>
        {(searchQuery || selectedMode !== 'All' || selectedType !== 'All' || selectedExp !== 'All' || showSavedOnly) && (
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedMode('All');
              setSelectedType('All');
              setSelectedExp('All');
              setShowSavedOnly(false);
            }}
            className="text-indigo-400 hover:underline flex items-center gap-1"
          >
            <X className="w-3.5 h-3.5" /> Clear all filters
          </button>
        )}
      </div>

      {/* Jobs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredJobs.length === 0 ? (
          <div className="col-span-full py-16 text-center rounded-2xl border border-slate-800 bg-slate-900/40 space-y-3">
            <Briefcase className="w-10 h-10 text-slate-600 mx-auto" />
            <h3 className="text-base font-bold text-slate-300">No jobs match your active filters</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Try searching for broader keywords like 'Engineer' or 'Developer', or remove filters.
            </p>
          </div>
        ) : (
          filteredJobs.map((job) => (
            <JobCard
              key={job.id}
              job={job}
              onSelectJob={(j) => setSelectedJobForDetail(j)}
              onApply={(j) => setSelectedJobForApply(j)}
            />
          ))
        )}
      </div>

      {/* Modals */}
      {selectedJobForDetail && (
        <JobDetailModal
          job={selectedJobForDetail}
          onClose={() => setSelectedJobForDetail(null)}
          onApply={(j) => setSelectedJobForApply(j)}
        />
      )}

      {selectedJobForApply && (
        <ApplyModal
          job={selectedJobForApply}
          onClose={() => setSelectedJobForApply(null)}
        />
      )}

      {isPostJobOpen && (
        <PostJobModal
          onClose={() => setIsPostJobOpen(false)}
        />
      )}

    </div>
  );
};
