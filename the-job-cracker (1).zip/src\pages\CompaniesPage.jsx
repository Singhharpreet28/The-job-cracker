import React, { useState } from 'react';
import { 
  Building2, 
  Search, 
  CheckCircle2, 
  Clock, 
  Award, 
  DollarSign, 
  FileText, 
  AlertCircle, 
  HelpCircle, 
  Sparkles, 
  ChevronRight, 
  ChevronDown, 
  GraduationCap, 
  Calendar, 
  BookOpen, 
  ShieldCheck 
} from 'lucide-react';
import { companiesList } from '../data/companiesData';

export const CompaniesPage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTier, setSelectedTier] = useState('All');
  const [activeCompanyId, setActiveCompanyId] = useState('google');

  const tiers = ['All', 'Tier 1 / Big Tech', 'Service Titan / Mass Recruiter', 'Tier 1 / Product SaaS'];

  const filteredCompanies = companiesList.filter((comp) => {
    if (selectedTier !== 'All' && !comp.tier.includes(selectedTier.split(' / ')[0])) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        comp.name.toLowerCase().includes(q) ||
        comp.overview.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const activeCompany = companiesList.find((c) => c.id === activeCompanyId) || companiesList[0];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Top Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 p-6 sm:p-8 space-y-4">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" /> Comprehensive Recruitment Blueprints
          </div>
          <h1 className="text-3xl font-extrabold text-white">
            Companies Hiring Process, Exam Pattern & Syllabus
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 max-w-2xl leading-relaxed">
            Everything you need to crack on-campus & off-campus drives: eligibility cutoffs, sectional test patterns, coding platform details, and insider interview experiences.
          </p>
        </div>

        {/* Company Quick Badges */}
        <div className="flex items-center gap-2 overflow-x-auto pt-2 border-t border-slate-800">
          {companiesList.map((comp) => (
            <button
              key={comp.id}
              onClick={() => setActiveCompanyId(comp.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-2 shrink-0 ${
                activeCompanyId === comp.id
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'bg-slate-950/80 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
              }`}
            >
              <span>{comp.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Split Layout: Left Company List + Right Detailed Dossier */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Company Cards */}
        <div className="lg:col-span-4 space-y-4">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search companies..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="space-y-2.5">
            {filteredCompanies.map((comp) => {
              const isSelected = comp.id === activeCompany.id;
              return (
                <div
                  key={comp.id}
                  onClick={() => setActiveCompanyId(comp.id)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                    isSelected
                      ? 'bg-indigo-950/30 border-indigo-500/50 shadow-lg shadow-indigo-950/40'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-slate-950 border border-slate-800 p-1 flex items-center justify-center shrink-0 overflow-hidden">
                      {comp.logo ? (
                        <img src={comp.logo} alt={comp.name} className="w-full h-full object-cover rounded-lg" />
                      ) : (
                        <Building2 className="w-5 h-5 text-indigo-400" />
                      )}
                    </div>
                    <div>
                      <h4 className="font-bold text-white text-sm">{comp.name}</h4>
                      <p className="text-[11px] text-slate-400">{comp.tier}</p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs font-bold text-emerald-400 block">{comp.avgCtc.split(' | ')[0]}</span>
                    <span className="text-[10px] text-slate-500">{comp.difficulty} Diff.</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: In-Depth Selected Company Dossier */}
        <div className="lg:col-span-8 space-y-6">
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 space-y-8">
            
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-slate-950 border border-slate-800 p-1 flex items-center justify-center shrink-0 overflow-hidden">
                  {activeCompany.logo ? (
                    <img src={activeCompany.logo} alt={activeCompany.name} className="w-full h-full object-cover rounded-xl" />
                  ) : (
                    <Building2 className="w-7 h-7 text-indigo-400" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                      {activeCompany.tier}
                    </span>
                    <span className="text-xs font-medium text-slate-400">
                      Difficulty: <strong className="text-amber-400">{activeCompany.difficulty}</strong>
                    </span>
                  </div>
                  <h2 className="text-2xl font-black text-white mt-1">{activeCompany.name} Hiring Drive</h2>
                </div>
              </div>

              <div className="sm:text-right bg-slate-950/80 p-3 rounded-xl border border-slate-800 shrink-0">
                <div className="text-[11px] text-slate-400 uppercase font-semibold">Compensation (CTC)</div>
                <div className="text-base font-extrabold text-emerald-400">{activeCompany.avgCtc}</div>
                {activeCompany.internStipend && (
                  <div className="text-[10px] text-slate-500 mt-0.5">Stipend: {activeCompany.internStipend}</div>
                )}
              </div>
            </div>

            {/* Overview */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Company Hiring Overview</h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans">
                {activeCompany.overview}
              </p>
            </div>

            {/* Eligibility Criteria */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <GraduationCap className="w-4 h-4 text-indigo-400" /> Eligibility Criteria & Cutoffs
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-slate-500 font-semibold block">Academic Marks / CGPA:</span>
                  <span className="text-slate-200 font-medium">{activeCompany.eligibility.minCgpa}</span>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-slate-500 font-semibold block">Backlog Restrictions:</span>
                  <span className="text-slate-200 font-medium">{activeCompany.eligibility.backlogs}</span>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-slate-500 font-semibold block">Eligible Streams / Degrees:</span>
                  <span className="text-slate-200 font-medium">{activeCompany.eligibility.branches}</span>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-slate-500 font-semibold block">Education Gap Allowed:</span>
                  <span className="text-slate-200 font-medium">{activeCompany.eligibility.gapAllowed}</span>
                </div>
              </div>
            </div>

            {/* Exam Pattern */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-emerald-400" /> Sectional Online Exam Pattern
              </h3>
              <div className="space-y-2.5">
                {activeCompany.examPattern.map((sec, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                      <div className="font-bold text-white text-xs">{sec.section}</div>
                      <div className="flex items-center gap-2 text-[11px] text-slate-400">
                        <span className="px-2 py-0.5 rounded bg-slate-800 text-indigo-300 font-semibold">
                          Duration: {sec.duration}
                        </span>
                        <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                          Platform: {sec.platform}
                        </span>
                      </div>
                    </div>
                    <p className="text-xs text-slate-300">{sec.questions}</p>
                    <div className="text-[11px] text-slate-500">
                      Negative Marking: <strong className="text-slate-400">{sec.negativeMarking}</strong>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Detailed Syllabus */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <BookOpen className="w-4 h-4 text-purple-400" /> Detailed Exam & Interview Syllabus
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <span className="font-bold text-purple-300 flex items-center gap-1.5">
                    Coding & DSA
                  </span>
                  <ul className="space-y-1 text-slate-400 list-disc list-inside">
                    {activeCompany.syllabus.coding.map((item, i) => (
                      <li key={i}><span className="text-slate-300">{item}</span></li>
                    ))}
                  </ul>
                </div>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <span className="font-bold text-blue-300 flex items-center gap-1.5">
                    Core Technical CS
                  </span>
                  <ul className="space-y-1 text-slate-400 list-disc list-inside">
                    {activeCompany.syllabus.coreCs.map((item, i) => (
                      <li key={i}><span className="text-slate-300">{item}</span></li>
                    ))}
                  </ul>
                </div>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <span className="font-bold text-emerald-300 flex items-center gap-1.5">
                    Aptitude & Behavioral
                  </span>
                  <ul className="space-y-1 text-slate-400 list-disc list-inside">
                    {activeCompany.syllabus.aptitude.map((item, i) => (
                      <li key={i}><span className="text-slate-300">{item}</span></li>
                    ))}
                  </ul>
                </div>

              </div>
            </div>

            {/* Hiring Process Rounds Timeline */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-400" /> Round-by-Round Selection Timeline
              </h3>
              <div className="space-y-2.5">
                {activeCompany.hiringProcess.map((round, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-lg bg-indigo-500/10 text-indigo-400 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <div className="space-y-1">
                      <div className="text-xs font-bold text-white">{round.round}</div>
                      <p className="text-xs text-slate-300 leading-relaxed">{round.detail}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Pro Tips from Selected Candidates */}
            <div className="p-5 rounded-2xl bg-amber-950/20 border border-amber-500/20 space-y-2.5">
              <h3 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" /> Pro Tips from Candidates Who Cleared {activeCompany.name}
              </h3>
              <ul className="space-y-1.5 text-xs text-slate-200 list-disc list-inside leading-relaxed">
                {activeCompany.proTips.map((tip, idx) => (
                  <li key={idx}>{tip}</li>
                ))}
              </ul>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
