import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Briefcase, 
  Code2, 
  BookOpen, 
  Building2, 
  Bookmark, 
  CheckCircle2, 
  Menu, 
  X, 
  PlusCircle, 
  Sparkles, 
  ChevronDown,
  Sun,
  Moon
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Navbar = ({ onOpenPostJob }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [prepDropdownOpen, setPrepDropdownOpen] = useState(false);
  const location = useLocation();
  const { appliedJobs, dsaProgressPct, solvedDsaCount, totalDsaCount, theme, toggleTheme } = useApp();

  const isActive = (path) => location.pathname === path;

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800 bg-slate-950/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-emerald-400 p-0.5 shadow-lg shadow-indigo-500/20 group-hover:scale-105 transition-transform">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Code2 className="w-5 h-5 text-indigo-400 group-hover:text-emerald-400 transition-colors" />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-display tracking-wider text-2xl flex items-center gap-1.5 drop-shadow-md">
                <span className="bg-gradient-to-r from-amber-400 via-orange-400 to-amber-300 bg-clip-text text-transparent font-black filter drop-shadow-[0_2px_8px_rgba(251,146,60,0.25)]">
                  The Job
                </span>
                <span className="bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent font-black filter drop-shadow-[0_2px_8px_rgba(99,102,241,0.25)]">
                  Cracker
                </span>
              </span>
              <span className="hidden sm:inline-block ml-1 text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 bg-gradient-to-r from-amber-500/10 to-indigo-500/10 text-amber-400 border border-amber-500/30 rounded-full shadow-sm">
                Portal & Prep
              </span>
            </div>
          </Link>

          {/* Desktop Nav Links */}
          <nav className="hidden md:flex items-center gap-1">
            <Link
              to="/jobs"
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${
                isActive('/jobs')
                  ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-slate-900'
              }`}
            >
              <Briefcase className="w-4 h-4" />
              Job Portal
            </Link>

            <Link
              to="/dsa-sheet"
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${
                isActive('/dsa-sheet')
                  ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-slate-900'
              }`}
            >
              <Code2 className="w-4 h-4" />
              DSA Sheet
              <span className="text-[11px] font-semibold px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full">
                {dsaProgressPct}%
              </span>
            </Link>

            {/* Preparation Dropdown */}
            <div className="relative">
              <button
                onClick={() => setPrepDropdownOpen(!prepDropdownOpen)}
                onBlur={() => setTimeout(() => setPrepDropdownOpen(false), 200)}
                className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
                  location.pathname.startsWith('/prep')
                    ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                    : 'text-slate-300 hover:text-white hover:bg-slate-900'
                }`}
              >
                <BookOpen className="w-4 h-4" />
                Preparation
                <ChevronDown className={`w-3.5 h-3.5 transition-transform ${prepDropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              {prepDropdownOpen && (
                <div className="absolute left-0 mt-2 w-56 rounded-xl bg-slate-900 border border-slate-800 shadow-xl shadow-black/50 py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                  <Link
                    to="/prep/aptitude"
                    className="flex items-center gap-3 px-4 py-2.5 text-sm text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors"
                  >
                    <div className="w-2 h-2 rounded-full bg-blue-400"></div>
                    <div>
                      <div className="font-medium">Aptitude & Quants</div>
                      <div className="text-xs text-slate-500">Formulas, notes & MCQs</div>
                    </div>
                  </Link>
                  <Link
                    to="/prep/technical"
                    className="flex items-center gap-3 px-4 py-2.5 text-sm text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors"
                  >
                    <div className="w-2 h-2 rounded-full bg-purple-400"></div>
                    <div>
                      <div className="font-medium">Core Technical</div>
                      <div className="text-xs text-slate-500">DBMS, OS, CN, OOPs</div>
                    </div>
                  </Link>
                  <Link
                    to="/prep/hr"
                    className="flex items-center gap-3 px-4 py-2.5 text-sm text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors"
                  >
                    <div className="w-2 h-2 rounded-full bg-emerald-400"></div>
                    <div>
                      <div className="font-medium">HR Interview Prep</div>
                      <div className="text-xs text-slate-500">STAR method & answers</div>
                    </div>
                  </Link>
                </div>
              )}
            </div>

            <Link
              to="/companies"
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${
                isActive('/companies')
                  ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-slate-900'
              }`}
            >
              <Building2 className="w-4 h-4" />
              Company Patterns
            </Link>

            <Link
              to="/applications"
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${
                isActive('/applications')
                  ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-slate-900'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              My Tracker
              {appliedJobs.length > 0 && (
                <span className="text-[11px] font-semibold px-1.5 py-0.2 bg-indigo-500/20 text-indigo-300 rounded-full">
                  {appliedJobs.length}
                </span>
              )}
            </Link>
          </nav>

          {/* Right Action Buttons */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Theme Switcher Button */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 transition-colors"
              title={`Switch to ${theme === 'light' ? 'Dark' : 'Light'} Mode`}
              aria-label="Toggle light or dark theme"
            >
              {theme === 'light' ? (
                <Moon className="w-4 h-4 text-indigo-400" />
              ) : (
                <Sun className="w-4 h-4 text-amber-400" />
              )}
            </button>

            <button
              onClick={onOpenPostJob}
              className="flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 transition-all hover:border-slate-600"
            >
              <PlusCircle className="w-4 h-4 text-emerald-400" />
              Post a Job
            </button>
            <Link
              to="/dsa-sheet"
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white shadow-md shadow-indigo-600/25 transition-all hover:scale-[1.02]"
            >
              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
              Practice DSA
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center gap-2">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-900 border border-slate-800"
              title="Toggle Theme"
            >
              {theme === 'light' ? (
                <Moon className="w-4 h-4 text-indigo-400" />
              ) : (
                <Sun className="w-4 h-4 text-amber-400" />
              )}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-900 focus:outline-none"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-slate-800 bg-slate-950 px-4 pt-2 pb-6 space-y-2">
          <Link
            to="/jobs"
            onClick={() => setMobileMenuOpen(false)}
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-slate-200 hover:bg-slate-900"
          >
            <Briefcase className="w-4 h-4 text-indigo-400" />
            Job Portal
          </Link>
          <Link
            to="/dsa-sheet"
            onClick={() => setMobileMenuOpen(false)}
            className="flex items-center justify-between px-3 py-2.5 rounded-lg text-sm text-slate-200 hover:bg-slate-900"
          >
            <div className="flex items-center gap-3">
              <Code2 className="w-4 h-4 text-indigo-400" />
              DSA Topic Sheet
            </div>
            <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400">
              {solvedDsaCount}/{totalDsaCount}
            </span>
          </Link>
          <div className="px-3 pt-2 pb-1 text-xs font-semibold uppercase text-slate-500 tracking-wider">
            Preparation Sections
          </div>
          <Link
            to="/prep/aptitude"
            onClick={() => setMobileMenuOpen(false)}
            className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-slate-900 pl-6"
          >
            <div className="w-2 h-2 rounded-full bg-blue-400"></div>
            Aptitude & Formulas
          </Link>
          <Link
            to="/prep/technical"
            onClick={() => setMobileMenuOpen(false)}
            className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-slate-900 pl-6"
          >
            <div className="w-2 h-2 rounded-full bg-purple-400"></div>
            Core CS (DBMS, OS, CN, OOPs)
          </Link>
          <Link
            to="/prep/hr"
            onClick={() => setMobileMenuOpen(false)}
            className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-slate-900 pl-6"
          >
            <div className="w-2 h-2 rounded-full bg-emerald-400"></div>
            HR Interview & STAR Framework
          </Link>
          <div className="pt-2 border-t border-slate-800">
            <Link
              to="/companies"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-slate-200 hover:bg-slate-900"
            >
              <Building2 className="w-4 h-4 text-indigo-400" />
              Companies Hiring Process
            </Link>
            <Link
              to="/applications"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-slate-200 hover:bg-slate-900"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              My Applications Tracker ({appliedJobs.length})
            </Link>
          </div>
          <div className="pt-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenPostJob();
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-semibold bg-indigo-600 text-white"
            >
              <PlusCircle className="w-4 h-4" />
              Post a New Job
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
