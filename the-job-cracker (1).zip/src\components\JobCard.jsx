import React from 'react';
import { 
  Building2, 
  MapPin, 
  Briefcase, 
  DollarSign, 
  Bookmark, 
  BookmarkCheck, 
  Clock, 
  Sparkles, 
  ArrowRight,
  CheckCircle2
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const JobCard = ({ job, onSelectJob, onApply }) => {
  const { savedJobs, toggleSaveJob, appliedJobs } = useApp();
  const isSaved = savedJobs.includes(job.id);
  const isApplied = appliedJobs.some((app) => app.jobId === job.id);

  const modeBadgeColors = {
    Remote: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    Hybrid: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20',
    Onsite: 'bg-amber-500/10 text-amber-400 border-amber-500/20'
  };

  return (
    <div className={`group relative rounded-2xl bg-slate-900/90 border transition-all duration-200 hover:shadow-xl hover:shadow-indigo-950/30 flex flex-col justify-between ${
      job.featured 
        ? 'border-indigo-500/40 hover:border-indigo-400' 
        : 'border-slate-800 hover:border-slate-700'
    }`}>
      
      {/* Featured Ribbon */}
      {job.featured && (
        <div className="absolute -top-2.5 right-4 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 text-[10px] font-bold text-white uppercase tracking-wider flex items-center gap-1 shadow-sm">
          <Sparkles className="w-2.5 h-2.5 text-yellow-300" /> Hot Role
        </div>
      )}

      {/* Card Header & Content */}
      <div className="p-6 space-y-4">
        
        {/* Top: Logo + Company Info + Bookmark */}
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-slate-950 border border-slate-800 p-1 flex items-center justify-center shrink-0 overflow-hidden">
              {job.logo ? (
                <img src={job.logo} alt={job.company} className="w-full h-full object-cover rounded-lg" />
              ) : (
                <Building2 className="w-6 h-6 text-indigo-400" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-slate-300">{job.company}</span>
                {job.companyBadge && (
                  <span className="text-[10px] font-medium px-1.5 py-0.2 rounded bg-slate-800 text-indigo-300 border border-slate-700">
                    {job.companyBadge}
                  </span>
                )}
              </div>
              <h3 
                onClick={() => onSelectJob(job)}
                className="text-base font-bold text-white group-hover:text-indigo-300 transition-colors cursor-pointer line-clamp-1"
              >
                {job.title}
              </h3>
            </div>
          </div>

          <button
            onClick={() => toggleSaveJob(job.id)}
            className={`p-2 rounded-xl border transition-colors shrink-0 ${
              isSaved 
                ? 'bg-indigo-500/10 border-indigo-500/30 text-indigo-400' 
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
            }`}
            title={isSaved ? 'Remove from saved' : 'Save job'}
          >
            {isSaved ? <BookmarkCheck className="w-4 h-4 fill-indigo-400" /> : <Bookmark className="w-4 h-4" />}
          </button>
        </div>

        {/* Metadata Badges */}
        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-300">
          <span className={`px-2.5 py-1 rounded-lg border font-medium ${modeBadgeColors[job.mode] || 'bg-slate-800 text-slate-300'}`}>
            {job.mode}
          </span>
          <span className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800">
            <MapPin className="w-3.5 h-3.5 text-slate-400" /> {job.location}
          </span>
          <span className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800">
            <Briefcase className="w-3.5 h-3.5 text-slate-400" /> {job.experience}
          </span>
          <span className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 font-semibold">
            <DollarSign className="w-3.5 h-3.5" /> {job.salary}
          </span>
        </div>

        {/* Snippet Description */}
        <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
          {job.description}
        </p>

        {/* Skills Tag Pills */}
        <div className="flex flex-wrap gap-1.5 pt-1">
          {job.skills?.slice(0, 4).map((skill, index) => (
            <span
              key={index}
              className="text-[11px] font-medium px-2 py-0.5 rounded-md bg-slate-800/80 text-slate-300 border border-slate-700/60"
            >
              {skill}
            </span>
          ))}
          {job.skills?.length > 4 && (
            <span className="text-[11px] text-slate-500 px-1 py-0.5">
              +{job.skills.length - 4} more
            </span>
          )}
        </div>
      </div>

      {/* Card Footer */}
      <div className="px-6 py-3.5 border-t border-slate-800/80 bg-slate-950/40 rounded-b-2xl flex items-center justify-between text-xs">
        <div className="flex items-center gap-1 text-slate-500">
          <Clock className="w-3.5 h-3.5" />
          <span>{job.postedDate || 'Active'}</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onSelectJob(job)}
            className="px-3 py-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors font-medium"
          >
            View Details
          </button>

          {isApplied ? (
            <span className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-semibold">
              <CheckCircle2 className="w-3.5 h-3.5" /> Applied
            </span>
          ) : (
            <button
              onClick={() => onApply(job)}
              className="flex items-center gap-1 px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold shadow-md shadow-indigo-600/20 transition-all hover:scale-[1.02]"
            >
              Apply <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
