import React, { useState } from 'react';
import { 
  Award, 
  Sparkles, 
  AlertTriangle, 
  CheckCircle2, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  Save, 
  Check, 
  Layers,
  Lightbulb,
  Edit3
} from 'lucide-react';
import { starMethodGuide, hrQuestions } from '../data/hrInterviewData';
import { useApp } from '../context/AppContext';

export const HrPrepPage = () => {
  const { hrNotes, saveHrNote } = useApp();
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [expandedAnswers, setExpandedAnswers] = useState({});
  const [draftAnswers, setDraftAnswers] = useState(hrNotes);
  const [saveSuccess, setSaveSuccess] = useState({});

  const categories = ['All', 'Introduction', 'Behavioral', 'Weakness & Failure', 'Teamwork & Conflict', 'Culture Fit', 'Future & Goals'];

  const filteredQuestions = selectedCategory === 'All'
    ? hrQuestions
    : hrQuestions.filter((q) => q.category === selectedCategory);

  const toggleAnswer = (id) => {
    setExpandedAnswers((prev) => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const handleSaveDraft = (id) => {
    saveHrNote(id, draftAnswers[id] || '');
    setSaveSuccess((prev) => ({ ...prev, [id]: true }));
    setTimeout(() => {
      setSaveSuccess((prev) => ({ ...prev, [id]: false }));
    }, 1500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      
      {/* Top Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-emerald-950/40 to-slate-900 border border-slate-800 p-6 sm:p-8 space-y-4">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" /> Behavioral & Cultural Assessment Mastery
          </div>
          <h1 className="text-3xl font-extrabold text-white">
            HR & Behavioral Interview Preparation Guide
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 max-w-2xl leading-relaxed">
            Tech skills get you the interview; behavioral clarity and culture fit win you the offer. Learn how to craft authentic, compelling STAR stories that impress hiring managers.
          </p>
        </div>
      </div>

      {/* The STAR Method Breakdown */}
      <div className="space-y-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Award className="w-5 h-5 text-emerald-400" />
            {starMethodGuide.title}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">{starMethodGuide.description}</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {starMethodGuide.steps.map((step, idx) => (
            <div
              key={idx}
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 relative overflow-hidden"
            >
              <div className="flex items-center justify-between">
                <span className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-extrabold text-lg flex items-center justify-center">
                  {step.letter}
                </span>
                <span className="text-[11px] font-semibold text-slate-400 bg-slate-800 px-2 py-0.5 rounded-full">
                  {step.allocation}
                </span>
              </div>
              <h3 className="text-sm font-bold text-white">{step.name}</h3>
              <p className="text-xs text-slate-300 leading-relaxed">{step.description}</p>
              <div className="pt-2 border-t border-slate-800 text-[11px] text-emerald-400">
                <strong>Pro Tip:</strong> {step.tips}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Top HR Questions & Model Answers */}
      <div className="space-y-6 pt-2">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-white">Top 30 HR & Behavioral Questions</h2>
            <p className="text-xs text-slate-400">Includes interviewer intent, model answers, and pitfall alerts.</p>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-colors ${
                  selectedCategory === cat
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-5">
          {filteredQuestions.map((q) => {
            const isExpanded = Boolean(expandedAnswers[q.id]);
            const currentDraft = draftAnswers[q.id] || '';

            return (
              <div
                key={q.id}
                className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 hover:border-slate-700 transition-colors"
              >
                {/* Question Header */}
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 uppercase tracking-wider">
                      {q.category}
                    </span>
                    <h3 className="text-base font-bold text-white leading-snug pt-1">
                      {q.question}
                    </h3>
                  </div>

                  <button
                    onClick={() => toggleAnswer(q.id)}
                    className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 shrink-0 transition-colors"
                  >
                    <span>{isExpanded ? 'Hide Answer' : 'Model Answer & Prep'}</span>
                    {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>
                </div>

                {/* Intent & Strategy */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 space-y-1">
                    <span className="text-slate-400 font-bold flex items-center gap-1.5">
                      <Lightbulb className="w-3.5 h-3.5 text-yellow-400" /> What the interviewer is evaluating:
                    </span>
                    <p className="text-slate-300 leading-relaxed">{q.interviewerIntent}</p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 space-y-1">
                    <span className="text-slate-400 font-bold flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Winning Answer Strategy:
                    </span>
                    <p className="text-slate-300 leading-relaxed">{q.idealStrategy}</p>
                  </div>
                </div>

                {/* Expanded Model Answer & Custom Draft */}
                {isExpanded && (
                  <div className="pt-4 border-t border-slate-800 space-y-4 animate-in fade-in duration-150">
                    
                    {/* Model Answer Box */}
                    <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/20 space-y-2">
                      <div className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                        <Award className="w-4 h-4" /> Polished STAR Model Response:
                      </div>
                      <p className="text-xs text-slate-200 leading-relaxed font-sans whitespace-pre-wrap">
                        {q.sampleAnswer}
                      </p>
                    </div>

                    {/* Red Flags Alert */}
                    {q.redFlags && (
                      <div className="p-3.5 rounded-xl bg-rose-950/20 border border-rose-500/20 text-xs space-y-1.5">
                        <div className="font-bold text-rose-400 flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
                          <AlertTriangle className="w-3.5 h-3.5" /> Red Flags & Mistakes to Avoid:
                        </div>
                        <ul className="space-y-1 text-slate-300 list-disc list-inside">
                          {q.redFlags.map((flag, idx) => (
                            <li key={idx}>{flag}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Interactive Personalized Answer Draft */}
                    <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                          <Edit3 className="w-3.5 h-3.5 text-indigo-400" /> Draft Your Personal Story for This Question:
                        </label>
                        {saveSuccess[q.id] && (
                          <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                            <Check className="w-3.5 h-3.5" /> Draft Saved!
                          </span>
                        )}
                      </div>
                      <textarea
                        rows={3}
                        placeholder="Write your personal STAR story here (Situation, Task, Action, Result)... Saves automatically to your browser."
                        value={currentDraft}
                        onChange={(e) => setDraftAnswers({ ...draftAnswers, [q.id]: e.target.value })}
                        className="w-full p-3 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 resize-none font-sans"
                      />
                      <div className="flex justify-end">
                        <button
                          onClick={() => handleSaveDraft(q.id)}
                          className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
                        >
                          <Save className="w-3.5 h-3.5" /> Save My Answer
                        </button>
                      </div>
                    </div>

                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
