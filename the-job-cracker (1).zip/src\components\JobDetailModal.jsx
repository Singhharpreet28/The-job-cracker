import React from 'react';
import { 
  X, 
  Building2, 
  MapPin, 
  Briefcase, 
  DollarSign, 
  Calendar, 
  CheckCircle2, 
  Sparkles, 
  Bookmark, 
  BookmarkCheck, 
  ExternalLink,
  ShieldCheck,
  Award
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const JobDetailModal = ({ job, onClose, onApply }) => {
  const { savedJobs, toggleSaveJob, appliedJobs } = useApp();

  if (!job) return null;

  const isSaved = savedJobs.includes(job.id);
  const isApplied = appliedJobs.some((app) => app.jobId === job.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-start justify-between p-6 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-slate-950 border border-slate-800 p-1 flex items-center justify-center shrink-0 overflow-hidden">
              {job.logo ? (
                <img src={job.logo} alt={job.company} className="w-full h-full object-cover rounded-xl" />
              ) : (
                <Building2 className="w-8 h-8 text-indigo-400" />
              )}
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-slate-300">{job.company}</span>
                {job.companyBadge && (
                  <span className="text-xs font-medium px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                    {job.companyBadge}
                  </span>
                )}
              </div>
              <h2 className="text-xl font-bold text-white">{job.title}</h2>
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 pt-1">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5" /> {job.location} ({job.mode})
                </span>
                <span>•</span>
                <span className="flex items-center gap-1 text-emerald-400 font-semibold">
                  <DollarSign className="w-3.5 h-3.5" /> {job.salary}
                </span>
                <span>•</span>
                <span>Batch: {job.batch || 'Any'}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => toggleSaveJob(job.id)}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              title={isSaved ? 'Remove Bookmark' : 'Bookmark Job'}
            >
              {isSaved ? <BookmarkCheck className="w-5 h-5 text-indigo-400 fill-indigo-400" /> : <Bookmark className="w-5 h-5" />}
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-300 text-sm">
          
          {/* Overview */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">About The Role</h4>
            <p className="leading-relaxed text-slate-300">{job.description}</p>
          </div>

          {/* Key Responsibilities */}
          {job.responsibilities && (
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Key Responsibilities</h4>
              <ul className="space-y-1.5">
                {job.responsibilities.map((r, i) => (
                  <li key={i} className="flex items-start gap-2.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-2 shrink-0"></span>
                    <span className="text-slate-300">{r}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Requirements & Eligibility */}
          {job.requirements && (
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Requirements & Qualifications</h4>
              <ul className="space-y-1.5">
                {job.requirements.map((req, i) => (
                  <li key={i} className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span className="text-slate-300">{req}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Interview Stages / Rounds */}
          {job.interviewRounds && (
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Hiring & Interview Stages</h4>
              <div className="space-y-2">
                {job.interviewRounds.map((round, i) => (
                  <div key={i} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-lg bg-indigo-500/10 text-indigo-400 font-bold text-xs flex items-center justify-center shrink-0">
                      {i + 1}
                    </span>
                    <span className="text-xs text-slate-300 font-medium">{round}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Required Skills */}
          {job.skills && (
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Tech Stack & Skills</h4>
              <div className="flex flex-wrap gap-2">
                {job.skills.map((skill, i) => (
                  <span key={i} className="px-3 py-1 rounded-lg bg-slate-950 border border-slate-700 text-xs font-medium text-slate-200">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Benefits */}
          {job.benefits && (
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Perks & Benefits</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {job.benefits.map((b, i) => (
                  <div key={i} className="flex items-center gap-2 p-2.5 rounded-lg bg-slate-950 border border-slate-800/80 text-xs text-slate-300">
                    <Award className="w-4 h-4 text-amber-400" />
                    <span>{b}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 px-6 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <div className="text-xs text-slate-400">
            Application Deadline: <span className="text-slate-200 font-medium">{job.deadline || 'Rolling basis'}</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-medium text-slate-400 hover:text-white"
            >
              Back to Listings
            </button>
            {isApplied ? (
              <span className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold">
                <CheckCircle2 className="w-4 h-4" /> Already Applied
              </span>
            ) : (
              <button
                onClick={() => {
                  onClose();
                  onApply(job);
                }}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white text-xs font-bold shadow-lg shadow-indigo-600/30 transition-all hover:scale-[1.02]"
              >
                Apply for this Role
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
