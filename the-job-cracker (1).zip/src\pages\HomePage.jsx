import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Briefcase, 
  Code2, 
  BookOpen, 
  Building2, 
  CheckCircle2, 
  Sparkles, 
  ArrowRight, 
  ChevronRight, 
  TrendingUp, 
  Award, 
  Terminal, 
  Compass, 
  Check, 
  Star 
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { JobCard } from '../components/JobCard';
import { companiesList } from '../data/companiesData';
import { dsaProblems } from '../data/dsaSheetsData';

export const HomePage = ({ onSelectJob, onApplyJob }) => {
  const { jobs, totalDsaCount, solvedDsaCount, dsaProgressPct } = useApp();
  const featuredJobs = jobs.filter((j) => j.featured).slice(0, 3);
  const sampleProblems = dsaProblems.slice(0, 4);

  return (
    <div className="space-y-16 pb-20">
      
      {/* Hero Section */}
      <section className="relative pt-12 sm:pt-20 pb-12 overflow-hidden">
        {/* Glow gradients */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute top-1/3 right-10 w-72 h-72 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="max-w-5xl mx-auto text-center space-y-6 px-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-900 border border-slate-700/80 text-xs font-medium text-slate-300 shadow-sm animate-in fade-in slide-in-from-top-3">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-display tracking-wide font-black text-sm">
              <span className="bg-gradient-to-r from-amber-400 via-orange-400 to-amber-300 bg-clip-text text-transparent">The Job</span>{' '}
              <span className="bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">Cracker</span>
            </span>
            <span className="text-slate-500">•</span>
            <span>2025/2026 Placement & Interview Hub</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white leading-tight sm:leading-[1.15]">
            Land Your Dream Software Job. <br />
            <span className="bg-gradient-to-r from-indigo-400 via-purple-300 to-emerald-400 bg-clip-text text-transparent">
              Master Every Interview Stage.
            </span>
          </h1>

          <p className="text-base sm:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
            The comprehensive platform unifying verified tech job listings, topic-wise DSA sheets with 4-language code solutions, Aptitude & Core CS notes, and insider company exam patterns.
          </p>

          <div className="pt-2 flex flex-wrap items-center justify-center gap-3 sm:gap-4">
            <Link
              to="/jobs"
              className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 transition-all hover:scale-[1.02] flex items-center gap-2"
            >
              <Briefcase className="w-4 h-4" />
              Explore Job Openings
            </Link>

            <Link
              to="/dsa-sheet"
              className="px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 font-bold text-sm border border-slate-700 transition-all hover:border-slate-600 flex items-center gap-2"
            >
              <Code2 className="w-4 h-4 text-emerald-400" />
              Dedicated DSA Sheet ({dsaProgressPct}% Solved)
            </Link>

            <Link
              to="/companies"
              className="px-5 py-3.5 rounded-xl bg-slate-900/60 hover:bg-slate-800 text-slate-300 font-medium text-sm border border-slate-800 flex items-center gap-1.5"
            >
              <Building2 className="w-4 h-4 text-indigo-400" />
              Company Exam Patterns
            </Link>
          </div>

          {/* Quick Metrics Bar */}
          <div className="pt-10 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-sm">
              <div className="text-2xl font-black text-white">{jobs.length}+</div>
              <div className="text-xs text-slate-400 mt-0.5">Active Tech Jobs & Internships</div>
            </div>
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-sm">
              <div className="text-2xl font-black text-emerald-400">{totalDsaCount}+</div>
              <div className="text-xs text-slate-400 mt-0.5">Curated DSA Questions</div>
            </div>
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-sm">
              <div className="text-2xl font-black text-indigo-400">4 Pillars</div>
              <div className="text-xs text-slate-400 mt-0.5">Aptitude, Core CS, DSA & HR</div>
            </div>
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-sm">
              <div className="text-2xl font-black text-amber-400">15+ Drives</div>
              <div className="text-xs text-slate-400 mt-0.5">FAANG & MNC Hiring Blueprints</div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Jobs Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex items-end justify-between">
          <div>
            <div className="text-xs font-bold text-indigo-400 uppercase tracking-wider">Top Opportunities</div>
            <h2 className="text-2xl font-bold text-white mt-1">Featured Tech Job Openings</h2>
          </div>
          <Link
            to="/jobs"
            className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 group"
          >
            View all jobs ({jobs.length})
            <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredJobs.map((job) => (
            <JobCard
              key={job.id}
              job={job}
              onSelectJob={onSelectJob}
              onApply={onApplyJob}
            />
          ))}
        </div>
      </section>

      {/* Dedicated DSA Topic-Wise Sheet Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-gradient-to-br from-indigo-950/60 via-slate-900 to-slate-900 border border-indigo-500/20 p-8 sm:p-10 relative overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-7 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
                <Code2 className="w-3.5 h-3.5" /> Dedicated Topic-Wise DSA Preparation Sheet
              </div>
              <h3 className="text-3xl font-extrabold text-white">
                Crack Technical Rounds with Curated Problem Sets
              </h3>
              <p className="text-sm text-slate-300 leading-relaxed">
                Topic-by-topic progression from Arrays & Two Pointers to Trees, Graphs, and Dynamic Programming. Each problem comes with time & space complexity, intuitive approach, and verified code in <span className="text-indigo-300 font-semibold">C++, Java, Python, and JavaScript</span>.
              </p>

              <div className="pt-2 flex flex-wrap gap-4 items-center">
                <Link
                  to="/dsa-sheet"
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center gap-2"
                >
                  Open DSA Sheet <ArrowRight className="w-4 h-4" />
                </Link>

                <div className="text-xs text-slate-400 flex items-center gap-2">
                  <div className="w-32 bg-slate-800 h-2.5 rounded-full overflow-hidden">
                    <div 
                      className="bg-emerald-400 h-full rounded-full transition-all duration-500" 
                      style={{ width: `${dsaProgressPct}%` }}
                    ></div>
                  </div>
                  <span className="font-semibold text-white">{solvedDsaCount}/{totalDsaCount} Solved ({dsaProgressPct}%)</span>
                </div>
              </div>
            </div>

            {/* Quick Preview Table */}
            <div className="lg:col-span-5 space-y-2">
              <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Must-Do Practice Samples</div>
              <div className="space-y-2">
                {sampleProblems.map((p) => (
                  <div
                    key={p.id}
                    className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between hover:border-slate-700 transition-colors"
                  >
                    <div className="space-y-0.5">
                      <div className="text-xs font-bold text-white flex items-center gap-2">
                        {p.title}
                        <span className={`text-[10px] px-1.5 py-0.2 rounded font-semibold ${
                          p.difficulty === 'Easy' ? 'text-emerald-400 bg-emerald-500/10' : 'text-amber-400 bg-amber-500/10'
                        }`}>
                          {p.difficulty}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400">{p.subTopic}</div>
                    </div>

                    <Link
                      to="/dsa-sheet"
                      className="text-xs text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1"
                    >
                      Solve <ChevronRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 4 Preparation Pillars */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div>
          <div className="text-xs font-bold text-indigo-400 uppercase tracking-wider">All-Round Readiness</div>
          <h2 className="text-2xl font-bold text-white mt-1">Four Complete Preparation Pillars</h2>
          <p className="text-sm text-slate-400 mt-1">Formula cheat sheets, interview Q&As, and interactive timed practice questions.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Aptitude Card */}
          <Link
            to="/prep/aptitude"
            className="group p-6 rounded-2xl bg-slate-900 border border-slate-800 hover:border-blue-500/40 hover:bg-slate-900/80 transition-all flex flex-col justify-between"
          >
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <BookOpen className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white group-hover:text-blue-300 transition-colors">
                  Aptitude, Quants & Reasoning
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Formula cheat sheets for Percentages, Time & Work, Speed-Distance, Syllogisms, and Blood Relations with interactive timed quizzes.
                </p>
              </div>
            </div>
            <div className="pt-6 flex items-center justify-between text-xs font-semibold text-blue-400">
              <span>Study Notes & MCQs</span>
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </Link>

          {/* Technical Card */}
          <Link
            to="/prep/technical"
            className="group p-6 rounded-2xl bg-slate-900 border border-slate-800 hover:border-purple-500/40 hover:bg-slate-900/80 transition-all flex flex-col justify-between"
          >
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Terminal className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white group-hover:text-purple-300 transition-colors">
                  Core Technical CS Subjects
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Deep revision notes & top interview Q&As for DBMS (ACID, Normalization), Operating Systems (Deadlocks, Paging), Computer Networks, and OOPs.
                </p>
              </div>
            </div>
            <div className="pt-6 flex items-center justify-between text-xs font-semibold text-purple-400">
              <span>Explore CS Modules</span>
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </Link>

          {/* HR Card */}
          <Link
            to="/prep/hr"
            className="group p-6 rounded-2xl bg-slate-900 border border-slate-800 hover:border-emerald-500/40 hover:bg-slate-900/80 transition-all flex flex-col justify-between"
          >
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white group-hover:text-emerald-300 transition-colors">
                  HR & Behavioral Interviews
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Master the STAR (Situation, Task, Action, Result) method. Model answers for "Tell me about yourself", weaknesses, conflict, and salary questions.
                </p>
              </div>
            </div>
            <div className="pt-6 flex items-center justify-between text-xs font-semibold text-emerald-400">
              <span>STAR Guide & Answers</span>
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </Link>

        </div>
      </section>

      {/* Companies Hiring Patterns Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex items-end justify-between">
          <div>
            <div className="text-xs font-bold text-indigo-400 uppercase tracking-wider">Exam Blueprints</div>
            <h2 className="text-2xl font-bold text-white mt-1">Company Hiring Processes & Syllabi</h2>
          </div>
          <Link
            to="/companies"
            className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 group"
          >
            View all company patterns
            <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {companiesList.slice(0, 3).map((comp) => (
            <div
              key={comp.id}
              className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 hover:border-slate-700 transition-all"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-950 border border-slate-800 p-1 flex items-center justify-center overflow-hidden">
                    {comp.logo ? (
                      <img src={comp.logo} alt={comp.name} className="w-full h-full object-cover rounded-lg" />
                    ) : (
                      <Building2 className="w-6 h-6 text-indigo-400" />
                    )}
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-base">{comp.name}</h4>
                    <span className="text-[11px] text-slate-400">{comp.tier}</span>
                  </div>
                </div>
                <span className="text-xs font-bold text-emerald-400 px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20">
                  {comp.avgCtc}
                </span>
              </div>

              <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                {comp.overview}
              </p>

              <div className="text-xs text-slate-300 space-y-1.5 pt-2 border-t border-slate-800">
                <div className="flex items-center justify-between text-slate-400">
                  <span>Exam Rounds:</span>
                  <span className="font-medium text-white">{comp.examPattern.length} Rounds</span>
                </div>
                <div className="flex items-center justify-between text-slate-400">
                  <span>Eligibility:</span>
                  <span className="font-medium text-white truncate max-w-[180px]">{comp.eligibility.minCgpa}</span>
                </div>
              </div>

              <Link
                to={`/companies`}
                className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 flex items-center justify-center gap-1.5 transition-colors"
              >
                Inspect Exam Pattern & Syllabus <ChevronRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
};
