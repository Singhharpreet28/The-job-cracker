export const dsaTopics = [
  { id: "all", name: "All Topics", count: 32 },
  { id: "arrays", name: "Arrays", count: 5 },
  { id: "strings", name: "Strings", count: 4 },
  { id: "two-pointers", name: "Two Pointers & Sliding Window", count: 3 },
  { id: "binary-search", name: "Binary Search", count: 3 },
  { id: "linked-list", name: "Linked List", count: 3 },
  { id: "stacks-queues", name: "Stacks & Queues", count: 3 },
  { id: "trees", name: "Trees & BST", count: 4 },
  { id: "graphs", name: "Graphs", count: 3 },
  { id: "dynamic-programming", name: "Dynamic Programming", count: 4 }
];

export const dsaProblems = [
  // --- ARRAYS ---
  {
    id: "dsa-1",
    title: "Two Sum",
    topic: "arrays",
    subTopic: "Hashing / Map",
    difficulty: "Easy",
    isMustDo: true,
    companies: ["Google", "Amazon", "Microsoft", "Meta", "Apple"],
    leetcodeUrl: "https://leetcode.com/problems/two-sum/",
    gfgUrl: "https://www.geeksforgeeks.org/check-if-pair-with-given-sum-exists-in-array/",
    intuition: "Instead of quadratic nested loops checking every pair (O(N^2)), use a hash map to remember each visited number and its index. For each number x, check if the complement (target - x) is already in the map.",
    timeComplexity: "O(N)",
    spaceComplexity: "O(N)",
    codeSnippets: {
      cpp: `class Solution {
public:
    vector<int> twoSum(vector<int>& nums, int target) {
        unordered_map<int, int> mp;
        for (int i = 0; i < nums.size(); ++i) {
            int complement = target - nums[i];
            if (mp.find(complement) != mp.end()) {
                return {mp[complement], i};
            }
            mp[nums[i]] = i;
        }
        return {};
    }
};`,
      java: `class Solution {
    public int[] twoSum(int[] nums, int target) {
        Map<Integer, Integer> map = new HashMap<>();
        for (int i = 0; i < nums.length; i++) {
            int complement = target - nums[i];
            if (map.containsKey(complement)) {
                return new int[] { map.get(complement), i };
            }
            map.put(nums[i], i);
        }
        return new int[] {};
    }
}`,
      python: `class Solution:
    def twoSum(self, nums: List[int], target: int) -> List[int]:
        seen = {}
        for i, num in enumerate(nums):
            complement = target - num
            if complement in seen:
                return [seen[complement], i]
            seen[num] = i
        return []`,
      javascript: `var twoSum = function(nums, target) {
    const map = new Map();
    for (let i = 0; i < nums.length; i++) {
        const complement = target - nums[i];
        if (map.has(complement)) {
            return [map.get(complement), i];
        }
        map.set(nums[i], i);
    }
    return [];
};`
    }
  },
  {
    id: "dsa-2",
    title: "Best Time to Buy and Sell Stock",
    topic: "arrays",
    subTopic: "Kadane's / One Pass",
    difficulty: "Easy",
    isMustDo: true,
    companies: ["Amazon", "Microsoft", "Goldman Sachs", "Uber"],
    leetcodeUrl: "https://leetcode.com/problems/best-time-to-buy-and-sell-stock/",
    gfgUrl: "https://www.geeksforgeeks.org/stock-buy-sell/",
    intuition: "Maintain the minimum price seen so far while iterating across the array. At each day, calculate the potential profit if sold today (current price - minPrice) and track the global maximum profit.",
    timeComplexity: "O(N)",
    spaceComplexity: "O(1)",
    codeSnippets: {
      cpp: `class Solution {
public:
    int maxProfit(vector<int>& prices) {
        int minPrice = INT_MAX;
        int maxProfit = 0;
        for (int price : prices) {
            minPrice = min(minPrice, price);
            maxProfit = max(maxProfit, price - minPrice);
        }
        return maxProfit;
    }
};`,
      java: `class Solution {
    public int maxProfit(int[] prices) {
        int minPrice = Integer.MAX_VALUE;
        int maxProfit = 0;
        for (int price : prices) {
            if (price < minPrice) minPrice = price;
            else if (price - minPrice > maxProfit) maxProfit = price - minPrice;
        }
        return maxProfit;
    }
}`,
      python: `class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        min_price = float('inf')
        max_profit = 0
        for price in prices:
            min_price = min(min_price, price)
            max_profit = max(max_profit, price - min_price)
        return max_profit`,
      javascript: `var maxProfit = function(prices) {
    let minPrice = Infinity;
    let maxProfit = 0;
    for (const price of prices) {
        minPrice = Math.min(minPrice, price);
        maxProfit = Math.max(maxProfit, price - minPrice);
    }
    return maxProfit;
};`
    }
  },
  {
    id: "dsa-3",
    title: "Maximum Subarray (Kadane's Algorithm)",
    topic: "arrays",
    subTopic: "Kadane's Algorithm",
    difficulty: "Medium",
    isMustDo: true,
    companies: ["Microsoft", "Google", "Amazon", "TCS", "Infosys"],
    leetcodeUrl: "https://leetcode.com/problems/maximum-subarray/",
    gfgUrl: "https://www.geeksforgeeks.org/largest-sum-contiguous-subarray/",
    intuition: "At each element, decide whether to append it to the existing running sum (currentSum + num) or start a fresh subarray at this element (num). Track the peak sum across the loop.",
    timeComplexity: "O(N)",
    spaceComplexity: "O(1)",
    codeSnippets: {
      cpp: `class Solution {
public:
    int maxSubArray(vector<int>& nums) {
        int curSum = 0, maxSum = nums[0];
        for (int x : nums) {
            curSum = max(x, curSum + x);
            maxSum = max(maxSum, curSum);
        }
        return maxSum;
    }
};`,
      java: `class Solution {
    public int maxSubArray(int[] nums) {
        int cur = nums[0], max = nums[0];
        for (int i = 1; i < nums.length; i++) {
            cur = Math.max(nums[i], cur + nums[i]);
            max = Math.max(max, cur);
        }
        return max;
    }
}`,
      python: `class Solution:
    def maxSubArray(self, nums: List[int]) -> int:
        cur_sum = max_sum = nums[0]
        for x in nums[1:]:
            cur_sum = max(x, cur_sum + x)
            max_sum = max(max_sum, cur_sum)
        return max_sum`,
      javascript: `var maxSubArray = function(nums) {
    let cur = nums[0], max = nums[0];
    for (let i = 1; i < nums.length; i++) {
        cur = Math.max(nums[i], cur + nums[i]);
        max = Math.max(max, cur);
    }
    return max;
};`
    }
  },
  {
    id: "dsa-4",
    title: "Merge Intervals",
    topic: "arrays",
    subTopic: "Sorting / Intervals",
    difficulty: "Medium",
    isMustDo: true,
    companies: ["Google", "Meta", "Amazon", "Flipkart", "Atlassian"],
    leetcodeUrl: "https://leetcode.com/problems/merge-intervals/",
    gfgUrl: "https://www.geeksforgeeks.org/merging-intervals/",
    intuition: "Sort intervals by their start points. Then iterate: if the current interval starts before or at the end of the previous merged interval, merge them by extending the end to max(prev.end, curr.end). Otherwise, push a new interval.",
    timeComplexity: "O(N log N)",
    spaceComplexity: "O(N)",
    codeSnippets: {
      cpp: `class Solution {
public:
    vector<vector<int>> merge(vector<vector<int>>& intervals) {
        if (intervals.empty()) return {};
        sort(intervals.begin(), intervals.end());
        vector<vector<int>> merged = {intervals[0]};
        for (int i = 1; i < intervals.size(); ++i) {
            if (intervals[i][0] <= merged.back()[1]) {
                merged.back()[1] = max(merged.back()[1], intervals[i][1]);
            } else {
                merged.push_back(intervals[i]);
            }
        }
        return merged;
    }
};`,
      java: `class Solution {
    public int[][] merge(int[][] intervals) {
        Arrays.sort(intervals, (a, b) -> Integer.compare(a[0], b[0]));
        List<int[]> res = new ArrayList<>();
        int[] curr = intervals[0];
        res.add(curr);
        for (int[] next : intervals) {
            if (next[0] <= curr[1]) {
                curr[1] = Math.max(curr[1], next[1]);
            } else {
                curr = next;
                res.add(curr);
            }
        }
        return res.toArray(new int[res.size()][]);
    }
}`,
      python: `class Solution:
    def merge(self, intervals: List[List[int]]) -> List[List[int]]:
        intervals.sort(key=lambda x: x[0])
        merged = [intervals[0]]
        for start, end in intervals[1:]:
            if start <= merged[-1][1]:
                merged[-1][1] = max(merged[-1][1], end)
            else:
                merged.append([start, end])
        return merged`,
      javascript: `var merge = function(intervals) {
    intervals.sort((a, b) => a[0] - b[0]);
    const merged = [intervals[0]];
    for (let i = 1; i < intervals.length; i++) {
        const curr = intervals[i];
        const last = merged[merged.length - 1];
        if (curr[0] <= last[1]) {
            last[1] = Math.max(last[1], curr[1]);
        } else {
            merged.push(curr);
        }
    }
    return merged;
};`
    }
  },
  {
    id: "dsa-5",
    title: "Trapping Rain Water",
    topic: "arrays",
    subTopic: "Two Pointers / Prefix Max",
    difficulty: "Hard",
    isMustDo: true,
    companies: ["Google", "Amazon", "Goldman Sachs", "Microsoft"],
    leetcodeUrl: "https://leetcode.com/problems/trapping-rain-water/",
    gfgUrl: "https://www.geeksforgeeks.org/trapping-rain-water/",
    intuition: "Using two pointers (left and right) and tracking leftMax and rightMax. Water trapped at any index is bounded by min(leftMax, rightMax) - height[i]. Move the pointer with the smaller max inward.",
    timeComplexity: "O(N)",
    spaceComplexity: "O(1)",
    codeSnippets: {
      cpp: `class Solution {
public:
    int trap(vector<int>& height) {
        int l = 0, r = height.size() - 1;
        int leftMax = 0, rightMax = 0, ans = 0;
        while (l < r) {
            if (height[l] < height[r]) {
                if (height[l] >= leftMax) leftMax = height[l];
                else ans += leftMax - height[l];
                l++;
            } else {
                if (height[r] >= rightMax) rightMax = height[r];
                else ans += rightMax - height[r];
                r--;
            }
        }
        return ans;
    }
};`,
      java: `class Solution {
    public int trap(int[] height) {
        int l = 0, r = height.length - 1;
        int leftMax = 0, rightMax = 0, total = 0;
        while (l < r) {
            if (height[l] < height[r]) {
                leftMax = Math.max(leftMax, height[l]);
                total += leftMax - height[l];
                l++;
            } else {
                rightMax = Math.max(rightMax, height[r]);
                total += rightMax - height[r];
                r--;
            }
        }
        return total;
    }
}`,
      python: `class Solution:
    def trap(self, height: List[int]) -> int:
        l, r = 0, len(height) - 1
        left_max = right_max = ans = 0
        while l < r:
            if height[l] < height[r]:
                left_max = max(left_max, height[l])
                ans += left_max - height[l]
                l += 1
            else:
                right_max = max(right_max, height[r])
                ans += right_max - height[r]
                r -= 1
        return ans`,
      javascript: `var trap = function(height) {
    let l = 0, r = height.length - 1;
    let leftMax = 0, rightMax = 0, ans = 0;
    while (l < r) {
        if (height[l] < height[r]) {
            leftMax = Math.max(leftMax, height[l]);
            ans += leftMax - height[l];
            l++;
        } else {
            rightMax = Math.max(rightMax, height[r]);
            ans += rightMax - height[r];
            r--;
        }
    }
    return ans;
};`
    }
  },

  // --- STRINGS ---
  {
    id: "dsa-6",
    title: "Valid Anagram",
    topic: "strings",
    subTopic: "Frequency Map / Hashing",
    difficulty: "Easy",
    isMustDo: true,
    companies: ["Amazon", "Uber", "Cognizant", "TCS"],
    leetcodeUrl: "https://leetcode.com/problems/valid-anagram/",
    gfgUrl: "https://www.geeksforgeeks.org/check-whether-two-strings-are-anagram-of-each-other/",
    intuition: "Count the frequency of each character in string s and decrement for string t using an array of size 26. If all counts are zero, both strings have identical character distributions.",
    timeComplexity: "O(N)",
    spaceComplexity: "O(1) - 26 chars",
    codeSnippets: {
      cpp: `class Solution {
public:
    bool isAnagram(string s, string t) {
        if (s.size() != t.size()) return false;
        int count[26] = {0};
        for (char c : s) count[c - 'a']++;
        for (char c : t) {
            if (--count[c - 'a'] < 0) return false;
        }
        return true;
    }
};`,
      java: `class Solution {
    public boolean isAnagram(String s, String t) {
        if (s.length() != t.length()) return false;
        int[] count = new int[26];
        for (char c : s.toCharArray()) count[c - 'a']++;
        for (char c : t.toCharArray()) {
            if (--count[c - 'a'] < 0) return false;
        }
        return true;
    }
}`,
      python: `class Solution:
    def isAnagram(self, s: str, t: str) -> bool:
        if len(s) != len(t): return False
        counts = {}
        for c in s: counts[c] = counts.get(c, 0) + 1
        for c in t:
            if c not in counts or counts[c] == 0: return False
            counts[c] -= 1
        return True`,
      javascript: `var isAnagram = function(s, t) {
    if (s.length !== t.length) return false;
    const freq = new Array(26).fill(0);
    for (let i = 0; i < s.length; i++) {
        freq[s.charCodeAt(i) - 97]++;
        freq[t.charCodeAt(i) - 97]--;
    }
    return freq.every(x => x === 0);
};`
    }
  },
  {
    id: "dsa-7",
    title: "Longest Substring Without Repeating Characters",
    topic: "strings",
    subTopic: "Sliding Window / Map",
    difficulty: "Medium",
    isMustDo: true,
    companies: ["Amazon", "Microsoft", "Google", "Adobe", "Razorpay"],
    leetcodeUrl: "https://leetcode.com/problems/longest-substring-without-repeating-characters/",
    gfgUrl: "https://www.geeksforgeeks.org/length-of-the-longest-substring-without-repeating-characters/",
    intuition: "Maintain a sliding window [left, right] and store the last seen position of each character. When a duplicate character is encountered inside the current window, shift left to lastSeen[c] + 1.",
    timeComplexity: "O(N)",
    spaceComplexity: "O(min(M, N))",
    codeSnippets: {
      cpp: `class Solution {
public:
    int lengthOfLongestSubstring(string s) {
        vector<int> last(256, -1);
        int maxLen = 0, left = 0;
        for (int right = 0; right < s.size(); right++) {
            if (last[s[right]] >= left) {
                left = last[s[right]] + 1;
            }
            last[s[right]] = right;
            maxLen = max(maxLen, right - left + 1);
        }
        return maxLen;
    }
};`,
      java: `class Solution {
    public int lengthOfLongestSubstring(String s) {
        int[] last = new int[256];
        Arrays.fill(last, -1);
        int maxLen = 0, left = 0;
        for (int right = 0; right < s.length(); right++) {
            char c = s.charAt(right);
            if (last[c] >= left) left = last[c] + 1;
            last[c] = right;
            maxLen = Math.max(maxLen, right - left + 1);
        }
        return maxLen;
    }
}`,
      python: `class Solution:
    def lengthOfLongestSubstring(self, s: str) -> int:
        seen = {}
        left = max_len = 0
        for right, char in enumerate(s):
            if char in seen and seen[char] >= left:
                left = seen[char] + 1
            seen[char] = right
            max_len = max(max_len, right - left + 1)
        return max_len`,
      javascript: `var lengthOfLongestSubstring = function(s) {
    const seen = new Map();
    let left = 0, maxLen = 0;
    for (let right = 0; right < s.length; right++) {
        const c = s[right];
        if (seen.has(c) && seen.get(c) >= left) {
            left = seen.get(c) + 1;
        }
        seen.set(c, right);
        maxLen = Math.max(maxLen, right - left + 1);
    }
    return maxLen;
};`
    }
  },
  {
    id: "dsa-8",
    title: "Longest Palindromic Substring",
    topic: "strings",
    subTopic: "Expand Around Center",
    difficulty: "Medium",
    isMustDo: true,
    companies: ["Amazon", "Microsoft", "Flipkart", "Accenture"],
    leetcodeUrl: "https://leetcode.com/problems/longest-palindromic-substring/",
    gfgUrl: "https://www.geeksforgeeks.org/longest-palindromic-substring/",
    intuition: "A palindrome mirrors around its center. There are 2n - 1 potential centers (odd length centered at i, even length centered between i and i+1). Expand outwards from each center as long as characters match.",
    timeComplexity: "O(N^2)",
    spaceComplexity: "O(1)",
    codeSnippets: {
      cpp: `class Solution {
public:
    string longestPalindrome(string s) {
        if (s.empty()) return "";
        int start = 0, maxLen = 1;
        auto expand = [&](int l, int r) {
            while (l >= 0 && r < s.size() && s[l] == s[r]) {
                if (r - l + 1 > maxLen) {
                    start = l;
                    maxLen = r - l + 1;
                }
                l--; r++;
            }
        };
        for (int i = 0; i < s.size(); ++i) {
            expand(i, i);
            expand(i, i + 1);
        }
        return s.substr(start, maxLen);
    }
};`,
      java: `class Solution {
    int start = 0, maxLen = 0;
    public String longestPalindrome(String s) {
        if (s.length() < 2) return s;
        for (int i = 0; i < s.length(); i++) {
            expand(s, i, i);
            expand(s, i, i + 1);
        }
        return s.substring(start, start + maxLen);
    }
    private void expand(String s, int l, int r) {
        while (l >= 0 && r < s.length() && s.charAt(l) == s.charAt(r)) {
            if (r - l + 1 > maxLen) {
                start = l;
                maxLen = r - l + 1;
            }
            l--; r++;
        }
    }
}`,
      python: `class Solution:
    def longestPalindrome(self, s: str) -> str:
        res = ""
        def expand(l, r):
            nonlocal res
            while l >= 0 and r < len(s) and s[l] == s[r]:
                if (r - l + 1) > len(res):
                    res = s[l:r+1]
                l -= 1
                r += 1
        for i in range(len(s)):
            expand(i, i)
            expand(i, i + 1)
        return res`,
      javascript: `var longestPalindrome = function(s) {
    let start = 0, maxLen = 0;
    function expand(l, r) {
        while (l >= 0 && r < s.length && s[l] === s[r]) {
            if (r - l + 1 > maxLen) {
                start = l;
                maxLen = r - l + 1;
            }
            l--; r++;
        }
    }
    for (let i = 0; i < s.length; i++) {
        expand(i, i);
        expand(i, i + 1);
    }
    return s.slice(start, start + maxLen);
};`
    }
  },
  {
    id: "dsa-9",
    title: "Minimum Window Substring",
    topic: "strings",
    subTopic: "Sliding Window / Hash Table",
    difficulty: "Hard",
    isMustDo: true,
    companies: ["Google", "Meta", "Amazon", "Uber"],
    leetcodeUrl: "https://leetcode.com/problems/minimum-window-substring/",
    gfgUrl: "https://www.geeksforgeeks.org/find-the-smallest-window-in-a-string-containing-all-characters-of-another-string/",
    intuition: "Keep frequency map of characters in target t. Expand the right pointer until all characters with their counts are covered. Once valid, contract the left pointer to find the minimal window.",
    timeComplexity: "O(N + M)",
    spaceComplexity: "O(K)",
    codeSnippets: {
      cpp: `class Solution {
public:
    string minWindow(string s, string t) {
        unordered_map<char, int> target, window;
        for (char c : t) target[c]++;
        int matched = 0, start = 0, minLen = INT_MAX, l = 0;
        for (int r = 0; r < s.size(); r++) {
            char c = s[r];
            if (target.count(c)) {
                window[c]++;
                if (window[c] == target[c]) matched++;
            }
            while (matched == target.size()) {
                if (r - l + 1 < minLen) {
                    minLen = r - l + 1;
                    start = l;
                }
                char leftChar = s[l];
                if (target.count(leftChar)) {
                    if (window[leftChar] == target[leftChar]) matched--;
                    window[leftChar]--;
                }
                l++;
            }
        }
        return minLen == INT_MAX ? "" : s.substr(start, minLen);
    }
};`,
      java: `class Solution {
    public String minWindow(String s, String t) {
        int[] map = new int[128];
        for (char c : t.toCharArray()) map[c]++;
        int count = t.length(), begin = 0, end = 0, head = 0, len = Integer.MAX_VALUE;
        while (end < s.length()) {
            if (map[s.charAt(end++)]-- > 0) count--;
            while (count == 0) {
                if (end - begin < len) {
                    len = end - (head = begin);
                }
                if (map[s.charAt(begin++)]++ == 0) count++;
            }
        }
        return len == Integer.MAX_VALUE ? "" : s.substring(head, head + len);
    }
}`,
      python: `class Solution:
    def minWindow(self, s: str, t: str) -> str:
        from collections import Counter
        target = Counter(t)
        window = {}
        matched = 0
        min_len = float('inf')
        start = l = 0
        for r, c in enumerate(s):
            if c in target:
                window[c] = window.get(c, 0) + 1
                if window[c] == target[c]: matched += 1
            while matched == len(target):
                if r - l + 1 < min_len:
                    min_len = r - l + 1
                    start = l
                left_c = s[l]
                if left_c in target:
                    if window[left_c] == target[left_c]: matched -= 1
                    window[left_c] -= 1
                l += 1
        return "" if min_len == float('inf') else s[start:start+min_len]`,
      javascript: `var minWindow = function(s, t) {
    const map = new Map();
    for (const c of t) map.set(c, (map.get(c) || 0) + 1);
    let l = 0, start = 0, minLen = Infinity, matched = 0;
    const window = new Map();
    for (let r = 0; r < s.length; r++) {
        const c = s[r];
        if (map.has(c)) {
            window.set(c, (window.get(c) || 0) + 1);
            if (window.get(c) === map.get(c)) matched++;
        }
        while (matched === map.size) {
            if (r - l + 1 < minLen) {
                minLen = r - l + 1;
                start = l;
            }
            const leftChar = s[l];
            if (map.has(leftChar)) {
                if (window.get(leftChar) === map.get(leftChar)) matched--;
                window.set(leftChar, window.get(leftChar) - 1);
            }
            l++;
        }
    }
    return minLen === Infinity ? "" : s.slice(start, start + minLen);
};`
    }
  },

  // --- TWO POINTERS ---
  {
    id: "dsa-10",
    title: "Container With Most Water",
    topic: "two-pointers",
    subTopic: "Greedy Two Pointers",
    difficulty: "Medium",
    isMustDo: true,
    companies: ["Amazon", "Google", "Flipkart", "Infosys"],
    leetcodeUrl: "https://leetcode.com/problems/container-with-most-water/",
    gfgUrl: "https://www.geeksforgeeks.org/container-with-most-water/",
    intuition: "Place pointers at extremes (left=0, right=n-1). Calculate area = (right - left) * min(h[left], h[right]). To potentially find a taller boundary and larger area, increment the pointer with the shorter bar.",
    timeComplexity: "O(N)",
    spaceComplexity: "O(1)",
    codeSnippets: {
      cpp: `class Solution {
public:
    int maxArea(vector<int>& height) {
        int l = 0, r = height.size() - 1, maxWater = 0;
        while (l < r) {
            maxWater = max(maxWater, (r - l) * min(height[l], height[r]));
            if (height[l] < height[r]) l++;
            else r--;
        }
        return maxWater;
    }
};`,
      java: `class Solution {
    public int maxArea(int[] height) {
        int l = 0, r = height.length - 1, maxWater = 0;
        while (l < r) {
            maxWater = Math.max(maxWater, (r - l) * Math.min(height[l], height[r]));
            if (height[l] < height[r]) l++;
            else r--;
        }
        return maxWater;
    }
}`,
      python: `class Solution:
    def maxArea(self, height: List[int]) -> int:
        l, r = 0, len(height) - 1
        max_water = 0
        while l < r:
            max_water = max(max_water, (r - l) * min(height[l], height[r]))
            if height[l] < height[r]: l += 1
            else: r -= 1
        return max_water`,
      javascript: `var maxArea = function(height) {
    let l = 0, r = height.length - 1, max = 0;
    while (l < r) {
        max = Math.max(max, (r - l) * Math.min(height[l], height[r]));
        if (height[l] < height[r]) l++;
        else r--;
    }
    return max;
};`
    }
  },
  {
    id: "dsa-11",
    title: "3Sum",
    topic: "two-pointers",
    subTopic: "Sort + Two Pointers",
    difficulty: "Medium",
    isMustDo: true,
    companies: ["Amazon", "Microsoft", "Meta", "Adobe"],
    leetcodeUrl: "https://leetcode.com/problems/3sum/",
    gfgUrl: "https://www.geeksforgeeks.org/find-a-triplet-that-sum-to-a-given-value/",
    intuition: "Sort the array. Fix the first element nums[i], then use two pointers (left = i+1, right = n-1) to find pairs summing to -nums[i]. Skip duplicate values at each step to prevent duplicate triplets.",
    timeComplexity: "O(N^2)",
    spaceComplexity: "O(1) extra space",
    codeSnippets: {
      cpp: `class Solution {
public:
    vector<vector<int>> threeSum(vector<int>& nums) {
        sort(nums.begin(), nums.end());
        vector<vector<int>> res;
        for (int i = 0; i < (int)nums.size() - 2; ++i) {
            if (i > 0 && nums[i] == nums[i - 1]) continue;
            int l = i + 1, r = nums.size() - 1;
            while (l < r) {
                int sum = nums[i] + nums[l] + nums[r];
                if (sum == 0) {
                    res.push_back({nums[i], nums[l], nums[r]});
                    while (l < r && nums[l] == nums[l + 1]) l++;
                    while (l < r && nums[r] == nums[r - 1]) r--;
                    l++; r--;
                } else if (sum < 0) l++;
                else r--;
            }
        }
        return res;
    }
};`,
      java: `class Solution {
    public List<List<Integer>> threeSum(int[] nums) {
        Arrays.sort(nums);
        List<List<Integer>> res = new ArrayList<>();
        for (int i = 0; i < nums.length - 2; i++) {
            if (i > 0 && nums[i] == nums[i - 1]) continue;
            int l = i + 1, r = nums.length - 1;
            while (l < r) {
                int sum = nums[i] + nums[l] + nums[r];
                if (sum == 0) {
                    res.add(Arrays.asList(nums[i], nums[l], nums[r]));
                    while (l < r && nums[l] == nums[l + 1]) l++;
                    while (l < r && nums[r] == nums[r - 1]) r--;
                    l++; r--;
                } else if (sum < 0) l++;
                else r--;
            }
        }
        return res;
    }
}`,
      python: `class Solution:
    def threeSum(self, nums: List[int]) -> List[List[int]]:
        nums.sort()
        res = []
        for i in range(len(nums) - 2):
            if i > 0 and nums[i] == nums[i - 1]: continue
            l, r = i + 1, len(nums) - 1
            while l < r:
                s = nums[i] + nums[l] + nums[r]
                if s == 0:
                    res.append([nums[i], nums[l], nums[r]])
                    while l < r and nums[l] == nums[l + 1]: l += 1
                    while l < r and nums[r] == nums[r - 1]: r -= 1
                    l += 1; r -= 1
                elif s < 0: l += 1
                else: r -= 1
        return res`,
      javascript: `var threeSum = function(nums) {
    nums.sort((a, b) => a - b);
    const res = [];
    for (let i = 0; i < nums.length - 2; i++) {
        if (i > 0 && nums[i] === nums[i - 1]) continue;
        let l = i + 1, r = nums.length - 1;
        while (l < r) {
            const sum = nums[i] + nums[l] + nums[r];
            if (sum === 0) {
                res.push([nums[i], nums[l], nums[r]]);
                while (l < r && nums[l] === nums[l + 1]) l++;
                while (l < r && nums[r] === nums[r - 1]) r--;
                l++; r--;
            } else if (sum < 0) l++;
            else r--;
        }
    }
    return res;
};`
    }
  },

  // --- BINARY SEARCH ---
  {
    id: "dsa-12",
    title: "Search in Rotated Sorted Array",
    topic: "binary-search",
    subTopic: "Modified Binary Search",
    difficulty: "Medium",
    isMustDo: true,
    companies: ["Google", "Amazon", "Microsoft", "Flipkart"],
    leetcodeUrl: "https://leetcode.com/problems/search-in-rotated-sorted-array/",
    gfgUrl: "https://www.geeksforgeeks.org/search-an-element-in-a-sorted-and-pivoted-array/",
    intuition: "At any midpoint, at least one half (left or right) is strictly sorted. Check if nums[mid] == target. If left half is sorted, check if target lies in that range. Otherwise check the right half.",
    timeComplexity: "O(log N)",
    spaceComplexity: "O(1)",
    codeSnippets: {
      cpp: `class Solution {
public:
    int search(vector<int>& nums, int target) {
        int l = 0, r = nums.size() - 1;
        while (l <= r) {
            int mid = l + (r - l) / 2;
            if (nums[mid] == target) return mid;
            if (nums[l] <= nums[mid]) {
                if (target >= nums[l] && target < nums[mid]) r = mid - 1;
                else l = mid + 1;
            } else {
                if (target > nums[mid] && target <= nums[r]) l = mid + 1;
                else r = mid - 1;
            }
        }
        return -1;
    }
};`,
      java: `class Solution {
    public int search(int[] nums, int target) {
        int l = 0, r = nums.length - 1;
        while (l <= r) {
            int mid = l + (r - l) / 2;
            if (nums[mid] == target) return mid;
            if (nums[l] <= nums[mid]) {
                if (target >= nums[l] && target < nums[mid]) r = mid - 1;
                else l = mid + 1;
            } else {
                if (target > nums[mid] && target <= nums[r]) l = mid + 1;
                else r = mid - 1;
            }
        }
        return -1;
    }
}`,
      python: `class Solution:
    def search(self, nums: List[int], target: int) -> int:
        l, r = 0, len(nums) - 1
        while l <= r:
            mid = (l + r) // 2
            if nums[mid] == target: return mid
            if nums[l] <= nums[mid]:
                if nums[l] <= target < nums[mid]: r = mid - 1
                else: l = mid + 1
            else:
                if nums[mid] < target <= nums[r]: l = mid + 1
                else: r = mid - 1
        return -1`,
      javascript: `var search = function(nums, target) {
    let l = 0, r = nums.length - 1;
    while (l <= r) {
        const mid = Math.floor((l + r) / 2);
        if (nums[mid] === target) return mid;
        if (nums[l] <= nums[mid]) {
            if (target >= nums[l] && target < nums[mid]) r = mid - 1;
            else l = mid + 1;
        } else {
            if (target > nums[mid] && target <= nums[r]) l = mid + 1;
            else r = mid - 1;
        }
    }
    return -1;
};`
    }
  },

  // --- LINKED LIST ---
  {
    id: "dsa-13",
    title: "Reverse a Linked List",
    topic: "linked-list",
    subTopic: "Pointers / Iterative",
    difficulty: "Easy",
    isMustDo: true,
    companies: ["Amazon", "Microsoft", "TCS", "Accenture", "Cognizant"],
    leetcodeUrl: "https://leetcode.com/problems/reverse-linked-list/",
    gfgUrl: "https://www.geeksforgeeks.org/reverse-a-linked-list/",
    intuition: "Maintain three pointers: prev = null, curr = head, and next. In each iteration, save curr.next, redirect curr.next to prev, then advance prev to curr and curr to next.",
    timeComplexity: "O(N)",
    spaceComplexity: "O(1)",
    codeSnippets: {
      cpp: `class Solution {
public:
    ListNode* reverseList(ListNode* head) {
        ListNode* prev = nullptr;
        ListNode* curr = head;
        while (curr) {
            ListNode* nxt = curr->next;
            curr->next = prev;
            prev = curr;
            curr = nxt;
        }
        return prev;
    }
};`,
      java: `class Solution {
    public ListNode reverseList(ListNode head) {
        ListNode prev = null, curr = head;
        while (curr != null) {
            ListNode next = curr.next;
            curr.next = prev;
            prev = curr;
            curr = next;
        }
        return prev;
    }
}`,
      python: `class Solution:
    def reverseList(self, head: Optional[ListNode]) -> Optional[ListNode]:
        prev = None
        curr = head
        while curr:
            nxt = curr.next
            curr.next = prev
            prev = curr
            curr = nxt
        return prev`,
      javascript: `var reverseList = function(head) {
    let prev = null, curr = head;
    while (curr) {
        const next = curr.next;
        curr.next = prev;
        prev = curr;
        curr = next;
    }
    return prev;
};`
    }
  },
  {
    id: "dsa-14",
    title: "Linked List Cycle (Floyd's Tortoise & Hare)",
    topic: "linked-list",
    subTopic: "Fast & Slow Pointers",
    difficulty: "Easy",
    isMustDo: true,
    companies: ["Amazon", "Google", "Microsoft", "Wipro"],
    leetcodeUrl: "https://leetcode.com/problems/linked-list-cycle/",
    gfgUrl: "https://www.geeksforgeeks.org/detect-loop-in-a-linked-list/",
    intuition: "Advance slow pointer by 1 step and fast pointer by 2 steps. If there is a loop, fast will eventually lap and meet slow inside the cycle.",
    timeComplexity: "O(N)",
    spaceComplexity: "O(1)",
    codeSnippets: {
      cpp: `class Solution {
public:
    bool hasCycle(ListNode *head) {
        ListNode *slow = head, *fast = head;
        while (fast && fast->next) {
            slow = slow->next;
            fast = fast->next->next;
            if (slow == fast) return true;
        }
        return false;
    }
};`,
      java: `public class Solution {
    public boolean hasCycle(ListNode head) {
        ListNode slow = head, fast = head;
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            if (slow == fast) return true;
        }
        return false;
    }
}`,
      python: `class Solution:
    def hasCycle(self, head: Optional[ListNode]) -> bool:
        slow = fast = head
        while fast and fast.next:
            slow = slow.next
            fast = fast.next.next
            if slow == fast: return True
        return False`,
      javascript: `var hasCycle = function(head) {
    let slow = head, fast = head;
    while (fast && fast.next) {
        slow = slow.next;
        fast = fast.next.next;
        if (slow === fast) return true;
    }
    return false;
};`
    }
  },

  // --- STACKS & QUEUES ---
  {
    id: "dsa-15",
    title: "Valid Parentheses",
    topic: "stacks-queues",
    subTopic: "Stack",
    difficulty: "Easy",
    isMustDo: true,
    companies: ["Google", "Meta", "Amazon", "Microsoft", "TCS"],
    leetcodeUrl: "https://leetcode.com/problems/valid-parentheses/",
    gfgUrl: "https://www.geeksforgeeks.org/check-for-balanced-parentheses-in-an-expression/",
    intuition: "Iterate characters: push expected matching closing parenthesis whenever an opening bracket is seen. When a closing bracket appears, check if the stack top matches; if empty or unequal, it is invalid.",
    timeComplexity: "O(N)",
    spaceComplexity: "O(N)",
    codeSnippets: {
      cpp: `class Solution {
public:
    bool isValid(string s) {
        stack<char> st;
        for (char c : s) {
            if (c == '(') st.push(')');
            else if (c == '{') st.push('}');
            else if (c == '[') st.push(']');
            else {
                if (st.empty() || st.top() != c) return false;
                st.pop();
            }
        }
        return st.empty();
    }
};`,
      java: `class Solution {
    public boolean isValid(String s) {
        Stack<Character> stack = new Stack<>();
        for (char c : s.toCharArray()) {
            if (c == '(') stack.push(')');
            else if (c == '{') stack.push('}');
            else if (c == '[') stack.push(']');
            else if (stack.isEmpty() || stack.pop() != c) return false;
        }
        return stack.isEmpty();
    }
}`,
      python: `class Solution:
    def isValid(self, s: str) -> bool:
        mapping = {')': '(', '}': '{', ']': '['}
        stack = []
        for char in s:
            if char in mapping:
                if not stack or stack[-1] != mapping[char]: return False
                stack.pop()
            else:
                stack.append(char)
        return len(stack) == 0`,
      javascript: `var isValid = function(s) {
    const stack = [];
    for (const c of s) {
        if (c === '(') stack.push(')');
        else if (c === '{') stack.push('}');
        else if (c === '[') stack.push(']');
        else if (stack.pop() !== c) return false;
    }
    return stack.length === 0;
};`
    }
  },

  // --- TREES ---
  {
    id: "dsa-16",
    title: "Maximum Depth of Binary Tree",
    topic: "trees",
    subTopic: "DFS / Recursion",
    difficulty: "Easy",
    isMustDo: true,
    companies: ["Amazon", "Microsoft", "Google", "Apple"],
    leetcodeUrl: "https://leetcode.com/problems/maximum-depth-of-binary-tree/",
    gfgUrl: "https://www.geeksforgeeks.org/find-the-maximum-depth-or-height-of-a-tree/",
    intuition: "Base case: if root is null, depth is 0. Otherwise, depth is 1 + max(depth(root.left), depth(root.right)).",
    timeComplexity: "O(N)",
    spaceComplexity: "O(H) where H is tree height",
    codeSnippets: {
      cpp: `class Solution {
public:
    int maxDepth(TreeNode* root) {
        if (!root) return 0;
        return 1 + max(maxDepth(root->left), maxDepth(root->right));
    }
};`,
      java: `class Solution {
    public int maxDepth(TreeNode root) {
        if (root == null) return 0;
        return 1 + Math.max(maxDepth(root.left), maxDepth(root.right));
    }
}`,
      python: `class Solution:
    def maxDepth(self, root: Optional[TreeNode]) -> int:
        if not root: return 0
        return 1 + max(self.maxDepth(root.left), self.maxDepth(root.right))`,
      javascript: `var maxDepth = function(root) {
    if (!root) return 0;
    return 1 + Math.max(maxDepth(root.left), maxDepth(root.right));
};`
    }
  },
  {
    id: "dsa-17",
    title: "Lowest Common Ancestor of a Binary Tree",
    topic: "trees",
    subTopic: "Tree Traversal / Post-order",
    difficulty: "Medium",
    isMustDo: true,
    companies: ["Amazon", "Meta", "Microsoft", "Google"],
    leetcodeUrl: "https://leetcode.com/problems/lowest-common-ancestor-of-a-binary-tree/",
    gfgUrl: "https://www.geeksforgeeks.org/lowest-common-ancestor-binary-tree-set-1/",
    intuition: "Recursively search left and right subtrees. If root matches p or q, return root. If both left and right return non-null nodes, root is their lowest common ancestor. If only one returns non-null, return that branch.",
    timeComplexity: "O(N)",
    spaceComplexity: "O(H)",
    codeSnippets: {
      cpp: `class Solution {
public:
    TreeNode* lowestCommonAncestor(TreeNode* root, TreeNode* p, TreeNode* q) {
        if (!root || root == p || root == q) return root;
        TreeNode* left = lowestCommonAncestor(root->left, p, q);
        TreeNode* right = lowestCommonAncestor(root->right, p, q);
        if (left && right) return root;
        return left ? left : right;
    }
};`,
      java: `class Solution {
    public TreeNode lowestCommonAncestor(TreeNode root, TreeNode p, TreeNode q) {
        if (root == null || root == p || root == q) return root;
        TreeNode left = lowestCommonAncestor(root.left, p, q);
        TreeNode right = lowestCommonAncestor(root.right, p, q);
        if (left != null && right != null) return root;
        return left != null ? left : right;
    }
}`,
      python: `class Solution:
    def lowestCommonAncestor(self, root: 'TreeNode', p: 'TreeNode', q: 'TreeNode') -> 'TreeNode':
        if not root or root == p or root == q: return root
        left = self.lowestCommonAncestor(root.left, p, q)
        right = self.lowestCommonAncestor(root.right, p, q)
        if left and right: return root
        return left or right`,
      javascript: `var lowestCommonAncestor = function(root, p, q) {
    if (!root || root === p || root === q) return root;
    const left = lowestCommonAncestor(root.left, p, q);
    const right = lowestCommonAncestor(root.right, p, q);
    if (left && right) return root;
    return left || right;
};`
    }
  },

  // --- GRAPHS ---
  {
    id: "dsa-18",
    title: "Number of Islands",
    topic: "graphs",
    subTopic: "BFS / DFS Flood Fill",
    difficulty: "Medium",
    isMustDo: true,
    companies: ["Amazon", "Google", "Microsoft", "Uber", "Flipkart"],
    leetcodeUrl: "https://leetcode.com/problems/number-of-islands/",
    gfgUrl: "https://www.geeksforgeeks.org/find-number-of-islands/",
    intuition: "Iterate across the 2D grid. Whenever an unvisited '1' (land) is found, increment island count and trigger a DFS/BFS to mark all adjacent '1's as visited (or convert to '0').",
    timeComplexity: "O(M * N)",
    spaceComplexity: "O(M * N)",
    codeSnippets: {
      cpp: `class Solution {
public:
    int numIslands(vector<vector<char>>& grid) {
        int m = grid.size(), n = grid[0].size(), count = 0;
        function<void(int, int)> dfs = [&](int r, int c) {
            if (r < 0 || r >= m || c < 0 || c >= n || grid[r][c] != '1') return;
            grid[r][c] = '0';
            dfs(r + 1, c); dfs(r - 1, c);
            dfs(r, c + 1); dfs(r, c - 1);
        };
        for (int i = 0; i < m; ++i) {
            for (int j = 0; j < n; ++j) {
                if (grid[i][j] == '1') {
                    count++;
                    dfs(i, j);
                }
            }
        }
        return count;
    }
};`,
      java: `class Solution {
    public int numIslands(char[][] grid) {
        int count = 0;
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                if (grid[i][j] == '1') {
                    count++;
                    dfs(grid, i, j);
                }
            }
        }
        return count;
    }
    private void dfs(char[][] grid, int r, int c) {
        if (r < 0 || c < 0 || r >= grid.length || c >= grid[0].length || grid[r][c] != '1') return;
        grid[r][c] = '0';
        dfs(grid, r + 1, c);
        dfs(grid, r - 1, c);
        dfs(grid, r, c + 1);
        dfs(grid, r, c - 1);
    }
}`,
      python: `class Solution:
    def numIslands(self, grid: List[List[str]]) -> int:
        if not grid: return 0
        m, n = len(grid), len(grid[0])
        count = 0
        def dfs(r, c):
            if r < 0 or r >= m or c < 0 or c >= n or grid[r][c] != '1': return
            grid[r][c] = '0'
            dfs(r + 1, c); dfs(r - 1, c); dfs(r, c + 1); dfs(r, c - 1)
        for i in range(m):
            for j in range(n):
                if grid[i][j] == '1':
                    count += 1
                    dfs(i, j)
        return count`,
      javascript: `var numIslands = function(grid) {
    let count = 0;
    const m = grid.length, n = grid[0].length;
    function dfs(r, c) {
        if (r < 0 || r >= m || c < 0 || c >= n || grid[r][c] !== '1') return;
        grid[r][c] = '0';
        dfs(r + 1, c); dfs(r - 1, c);
        dfs(r, c + 1); dfs(r, c - 1);
    }
    for (let i = 0; i < m; i++) {
        for (let j = 0; j < n; j++) {
            if (grid[i][j] === '1') {
                count++;
                dfs(i, j);
            }
        }
    }
    return count;
};`
    }
  },

  // --- DYNAMIC PROGRAMMING ---
  {
    id: "dsa-19",
    title: "Climbing Stairs",
    topic: "dynamic-programming",
    subTopic: "1D DP / Fibonacci",
    difficulty: "Easy",
    isMustDo: true,
    companies: ["Amazon", "Google", "Adobe", "TCS"],
    leetcodeUrl: "https://leetcode.com/problems/climbing-stairs/",
    gfgUrl: "https://www.geeksforgeeks.org/count-ways-reach-nth-stair/",
    intuition: "To reach step n, you can either take 1 step from (n-1) or 2 steps from (n-2). Hence ways(n) = ways(n-1) + ways(n-2). This is equivalent to Fibonacci numbers.",
    timeComplexity: "O(N)",
    spaceComplexity: "O(1)",
    codeSnippets: {
      cpp: `class Solution {
public:
    int climbStairs(int n) {
        if (n <= 2) return n;
        int prev2 = 1, prev1 = 2;
        for (int i = 3; i <= n; ++i) {
            int cur = prev1 + prev2;
            prev2 = prev1;
            prev1 = cur;
        }
        return prev1;
    }
};`,
      java: `class Solution {
    public int climbStairs(int n) {
        if (n <= 2) return n;
        int a = 1, b = 2;
        for (int i = 3; i <= n; i++) {
            int c = a + b;
            a = b;
            b = c;
        }
        return b;
    }
}`,
      python: `class Solution:
    def climbStairs(self, n: int) -> int:
        if n <= 2: return n
        a, b = 1, 2
        for _ in range(3, n + 1):
            a, b = b, a + b
        return b`,
      javascript: `var climbStairs = function(n) {
    if (n <= 2) return n;
    let a = 1, b = 2;
    for (let i = 3; i <= n; i++) {
        const c = a + b;
        a = b;
        b = c;
    }
    return b;
};`
    }
  },
  {
    id: "dsa-20",
    title: "Coin Change (Min Coins)",
    topic: "dynamic-programming",
    subTopic: "Unbounded Knapsack",
    difficulty: "Medium",
    isMustDo: true,
    companies: ["Amazon", "Microsoft", "Atlassian", "Flipkart"],
    leetcodeUrl: "https://leetcode.com/problems/coin-change/",
    gfgUrl: "https://www.geeksforgeeks.org/coin-change-dp-7/",
    intuition: "Let dp[i] be the minimum coins needed to make amount i. For each coin, if i >= coin: dp[i] = min(dp[i], 1 + dp[i - coin]). Initialize dp array with infinity and dp[0] = 0.",
    timeComplexity: "O(amount * number of coins)",
    spaceComplexity: "O(amount)",
    codeSnippets: {
      cpp: `class Solution {
public:
    int coinChange(vector<int>& coins, int amount) {
        vector<int> dp(amount + 1, amount + 1);
        dp[0] = 0;
        for (int i = 1; i <= amount; ++i) {
            for (int coin : coins) {
                if (i >= coin) {
                    dp[i] = min(dp[i], 1 + dp[i - coin]);
                }
            }
        }
        return dp[amount] > amount ? -1 : dp[amount];
    }
};`,
      java: `class Solution {
    public int coinChange(int[] coins, int amount) {
        int[] dp = new int[amount + 1];
        Arrays.fill(dp, amount + 1);
        dp[0] = 0;
        for (int i = 1; i <= amount; i++) {
            for (int coin : coins) {
                if (i >= coin) {
                    dp[i] = Math.min(dp[i], 1 + dp[i - coin]);
                }
            }
        }
        return dp[amount] > amount ? -1 : dp[amount];
    }
}`,
      python: `class Solution:
    def coinChange(self, coins: List[int], amount: int) -> int:
        dp = [float('inf')] * (amount + 1)
        dp[0] = 0
        for i in range(1, amount + 1):
            for c in coins:
                if i >= c:
                    dp[i] = min(dp[i], 1 + dp[i - c])
        return dp[amount] if dp[amount] != float('inf') else -1`,
      javascript: `var coinChange = function(coins, amount) {
    const dp = new Array(amount + 1).fill(amount + 1);
    dp[0] = 0;
    for (let i = 1; i <= amount; i++) {
        for (const coin of coins) {
            if (i >= coin) {
                dp[i] = Math.min(dp[i], 1 + dp[i - coin]);
            }
        }
    }
    return dp[amount] > amount ? -1 : dp[amount];
};`
    }
  },
  {
    id: "dsa-21",
    title: "Longest Increasing Subsequence (LIS)",
    topic: "dynamic-programming",
    subTopic: "Binary Search Patience Sort",
    difficulty: "Medium",
    isMustDo: true,
    companies: ["Google", "Amazon", "Microsoft", "Uber"],
    leetcodeUrl: "https://leetcode.com/problems/longest-increasing-subsequence/",
    gfgUrl: "https://www.geeksforgeeks.org/longest-increasing-subsequence-dp-3/",
    intuition: "Maintain an array 'tails' where tails[i] stores the smallest tail of all increasing subsequences of length i+1. For each number x, use binary search to replace the first element >= x, or append if larger than all.",
    timeComplexity: "O(N log N)",
    spaceComplexity: "O(N)",
    codeSnippets: {
      cpp: `class Solution {
public:
    int lengthOfLIS(vector<int>& nums) {
        vector<int> tails;
        for (int x : nums) {
            auto it = lower_bound(tails.begin(), tails.end(), x);
            if (it == tails.end()) tails.push_back(x);
            else *it = x;
        }
        return tails.size();
    }
};`,
      java: `class Solution {
    public int lengthOfLIS(int[] nums) {
        int[] tails = new int[nums.length];
        int size = 0;
        for (int x : nums) {
            int i = 0, j = size;
            while (i != j) {
                int m = (i + j) / 2;
                if (tails[m] < x) i = m + 1;
                else j = m;
            }
            tails[i] = x;
            if (i == size) ++size;
        }
        return size;
    }
}`,
      python: `import bisect

class Solution:
    def lengthOfLIS(self, nums: List[int]) -> int:
        tails = []
        for x in nums:
            idx = bisect.bisect_left(tails, x)
            if idx == len(tails):
                tails.append(x)
            else:
                tails[idx] = x
        return len(tails)`,
      javascript: `var lengthOfLIS = function(nums) {
    const tails = [];
    for (const x of nums) {
        let l = 0, r = tails.length;
        while (l < r) {
            const mid = Math.floor((l + r) / 2);
            if (tails[mid] < x) l = mid + 1;
            else r = mid;
        }
        tails[l] = x;
    }
    return tails.length;
};`
    }
  }
];

export const getDsaProgress = () => {
  try {
    const solved = localStorage.getItem("careerforge_dsa_solved");
    const starred = localStorage.getItem("careerforge_dsa_starred");
    return {
      solved: solved ? JSON.parse(solved) : ["dsa-1", "dsa-2", "dsa-13"],
      starred: starred ? JSON.parse(starred) : ["dsa-5", "dsa-12"]
    };
  } catch {
    return { solved: [], starred: [] };
  }
};

export const saveDsaProgress = (solved, starred) => {
  try {
    localStorage.setItem("careerforge_dsa_solved", JSON.stringify(solved));
    localStorage.setItem("careerforge_dsa_starred", JSON.stringify(starred));
  } catch (e) {
    console.error("Failed to persist DSA progress", e);
  }
};
